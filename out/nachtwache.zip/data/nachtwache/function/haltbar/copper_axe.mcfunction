scoreboard players set #hmax nw.tmp 190
