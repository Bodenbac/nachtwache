scoreboard players set #hmax nw.tmp 1561
