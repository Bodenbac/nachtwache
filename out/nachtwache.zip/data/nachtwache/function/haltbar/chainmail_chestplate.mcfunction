scoreboard players set #hmax nw.tmp 240
