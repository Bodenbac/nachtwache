scoreboard players set #hmax nw.tmp 275
