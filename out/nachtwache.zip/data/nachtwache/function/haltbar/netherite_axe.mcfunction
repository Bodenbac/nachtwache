scoreboard players set #hmax nw.tmp 2031
