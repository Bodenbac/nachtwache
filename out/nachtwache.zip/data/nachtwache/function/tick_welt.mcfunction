function nachtwache:uhr/tick
function nachtwache:schutz/tick
execute as @a[tag=nw.admin,scores={night=1..}] run function nachtwache:admin/night_trigger
execute as @a[tag=nw.admin,scores={boss=1..}] run function nachtwache:admin/boss_trigger
execute as @a[tag=nw.admin,scores={endnight=1..}] run function nachtwache:admin/endnight_trigger
function nachtwache:nacht/boss_ruf
function nachtwache:nacht/boss_tick
