execute if score #phase nw.phase matches 1 run scoreboard players set #st_start nw.tmp2 0
execute if score #phase nw.phase matches 1 run scoreboard players set #st_ziel nw.tmp2 500
execute if score #phase nw.phase matches 2 run scoreboard players set #st_start nw.tmp2 500
execute if score #phase nw.phase matches 2 run scoreboard players set #st_ziel nw.tmp2 1500
execute if score #phase nw.phase matches 3 run scoreboard players set #st_start nw.tmp2 1500
execute if score #phase nw.phase matches 3 run scoreboard players set #st_ziel nw.tmp2 3000
execute if score #phase nw.phase matches 4 run scoreboard players set #st_start nw.tmp2 3000
execute if score #phase nw.phase matches 4 run scoreboard players set #st_ziel nw.tmp2 5000
execute if score #phase nw.phase matches 5 run scoreboard players set #st_start nw.tmp2 5000
execute if score #phase nw.phase matches 5 run scoreboard players set #st_ziel nw.tmp2 8000
execute if score #phase nw.phase matches 6 run scoreboard players set #st_start nw.tmp2 8000
execute if score #phase nw.phase matches 6 run scoreboard players set #st_ziel nw.tmp2 12000
execute if score #phase nw.phase matches 7 run scoreboard players set #st_start nw.tmp2 12000
execute if score #phase nw.phase matches 7 run scoreboard players set #st_ziel nw.tmp2 0
scoreboard players operation #st_hab nw.tmp2 = #abbau nw.abbau
scoreboard players operation #st_hab nw.tmp2 -= #st_start nw.tmp2
scoreboard players operation #st_soll nw.tmp2 = #st_ziel nw.tmp2
scoreboard players operation #st_soll nw.tmp2 -= #st_start nw.tmp2
scoreboard players operation #st_pct nw.tmp2 = #st_hab nw.tmp2
scoreboard players operation #st_pct nw.tmp2 *= #100 nw.const
execute if score #st_soll nw.tmp2 matches 1.. run scoreboard players operation #st_pct nw.tmp2 /= #st_soll nw.tmp2
execute if score #st_soll nw.tmp2 matches ..0 run scoreboard players set #st_pct nw.tmp2 100
execute if score #st_pct nw.tmp2 matches 101.. run scoreboard players set #st_pct nw.tmp2 100
execute if score #st_pct nw.tmp2 matches ..-1 run scoreboard players set #st_pct nw.tmp2 0
execute if score #st_hab nw.tmp2 matches ..-1 run scoreboard players set #st_hab nw.tmp2 0
execute if score #phase nw.phase matches 1 run scoreboard players display name sb_4 nw.anzeige [{"text":" ","color":"white"},{"text":"Tier 1  ","color":"gray"},{"score":{"name":"#st_pct","objective":"nw.tmp2"},"color":"white"},{"text":"%  ","color":"white"},{"score":{"name":"#st_hab","objective":"nw.tmp2"},"color":"gray"},{"text":"/","color":"gray"},{"score":{"name":"#st_soll","objective":"nw.tmp2"},"color":"gray"}]
execute if score #phase nw.phase matches 2 run scoreboard players display name sb_4 nw.anzeige [{"text":" ","color":"white"},{"text":"Tier 2  ","color":"green"},{"score":{"name":"#st_pct","objective":"nw.tmp2"},"color":"white"},{"text":"%  ","color":"white"},{"score":{"name":"#st_hab","objective":"nw.tmp2"},"color":"gray"},{"text":"/","color":"gray"},{"score":{"name":"#st_soll","objective":"nw.tmp2"},"color":"gray"}]
execute if score #phase nw.phase matches 3 run scoreboard players display name sb_4 nw.anzeige [{"text":" ","color":"white"},{"text":"Tier 3  ","color":"blue"},{"score":{"name":"#st_pct","objective":"nw.tmp2"},"color":"white"},{"text":"%  ","color":"white"},{"score":{"name":"#st_hab","objective":"nw.tmp2"},"color":"gray"},{"text":"/","color":"gray"},{"score":{"name":"#st_soll","objective":"nw.tmp2"},"color":"gray"}]
execute if score #phase nw.phase matches 4 run scoreboard players display name sb_4 nw.anzeige [{"text":" ","color":"white"},{"text":"Tier 4  ","color":"light_purple"},{"score":{"name":"#st_pct","objective":"nw.tmp2"},"color":"white"},{"text":"%  ","color":"white"},{"score":{"name":"#st_hab","objective":"nw.tmp2"},"color":"gray"},{"text":"/","color":"gray"},{"score":{"name":"#st_soll","objective":"nw.tmp2"},"color":"gray"}]
execute if score #phase nw.phase matches 5 run scoreboard players display name sb_4 nw.anzeige [{"text":" ","color":"white"},{"text":"Tier 5  ","color":"yellow"},{"score":{"name":"#st_pct","objective":"nw.tmp2"},"color":"white"},{"text":"%  ","color":"white"},{"score":{"name":"#st_hab","objective":"nw.tmp2"},"color":"gray"},{"text":"/","color":"gray"},{"score":{"name":"#st_soll","objective":"nw.tmp2"},"color":"gray"}]
execute if score #phase nw.phase matches 6 run scoreboard players display name sb_4 nw.anzeige [{"text":" ","color":"white"},{"text":"Tier 6  ","color":"gold"},{"score":{"name":"#st_pct","objective":"nw.tmp2"},"color":"white"},{"text":"%  ","color":"white"},{"score":{"name":"#st_hab","objective":"nw.tmp2"},"color":"gray"},{"text":"/","color":"gray"},{"score":{"name":"#st_soll","objective":"nw.tmp2"},"color":"gray"}]
execute if score #phase nw.phase matches 7 run scoreboard players display name sb_4 nw.anzeige [{"text":" ","color":"white"},{"text":"Tier 7  ","color":"dark_gray"},{"text":"max","color":"white"}]
