scoreboard players set sb_5 nw.anzeige 5
scoreboard players set sb_4 nw.anzeige 4
scoreboard players set sb_3 nw.anzeige 3
scoreboard players set sb_2 nw.anzeige 2
scoreboard players set sb_1 nw.anzeige 1
scoreboard players display name sb_5 nw.anzeige [{"text":"● ","color":"white"},{"text":"Coins  ","color":"gold"},{"score":{"name":"#konto","objective":"nw.konto"},"color":"yellow","bold":true}]
function nachtwache:anzeige/stufe
scoreboard players display name sb_3 nw.anzeige [{"text":" ","color":"white"},{"text":"Night  ","color":"red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"white"}]
scoreboard players display name sb_2 nw.anzeige [{"text":" ","color":"white"},{"text":"Enemies  ","color":"dark_red"},{"score":{"name":"#gegner","objective":"nw.gegner"},"color":"white","bold":true}]
scoreboard players display name sb_1 nw.anzeige [{"text":" ","color":"white"},{"text":"Deaths  ","color":"dark_gray"},{"score":{"name":"#tode","objective":"nw.tode"},"color":"gray"}]
