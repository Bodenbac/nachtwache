scoreboard players set #wer nw.tmp 1
scoreboard players add #abbau nw.abbau 1
scoreboard players operation #splitter nw.tmp = #phase nw.phase
execute if score #phase nw.phase matches 1 run scoreboard players set #splitter nw.tmp 2
execute if score #phase nw.phase matches 2 run scoreboard players set #splitter nw.tmp 4
execute if score #phase nw.phase matches 3 run scoreboard players set #splitter nw.tmp 6
execute if score #phase nw.phase matches 4 run scoreboard players set #splitter nw.tmp 8
execute if score #phase nw.phase matches 5 run scoreboard players set #splitter nw.tmp 10
execute if score #phase nw.phase matches 6 run scoreboard players set #splitter nw.tmp 12
execute if score #phase nw.phase matches 7 run scoreboard players set #splitter nw.tmp 16
execute if score #focus nw.upgrade matches 1.. run scoreboard players operation #splitter nw.tmp *= #2 nw.const
scoreboard players operation #konto nw.konto += #splitter nw.tmp
scoreboard players operation #verdient nw.verdient += #splitter nw.tmp
playsound minecraft:block.amethyst_block.break player @a ~ ~ ~ 0.6 0.7
execute if score #phase nw.phase matches 1 if predicate nachtwache:quell_mob_1 run function nachtwache:quell/mob_1
execute if score #phase nw.phase matches 1 unless score #mobda nw.tmp matches 1 run loot give @s loot nachtwache:quell/phase1
execute if score #phase nw.phase matches 2 if predicate nachtwache:quell_mob_2 run function nachtwache:quell/mob_2
execute if score #phase nw.phase matches 2 unless score #mobda nw.tmp matches 1 run loot give @s loot nachtwache:quell/phase2
execute if score #phase nw.phase matches 3 if predicate nachtwache:quell_mob_3 run function nachtwache:quell/mob_3
execute if score #phase nw.phase matches 3 unless score #mobda nw.tmp matches 1 run loot give @s loot nachtwache:quell/phase3
execute if score #phase nw.phase matches 4 if predicate nachtwache:quell_mob_4 run function nachtwache:quell/mob_4
execute if score #phase nw.phase matches 4 unless score #mobda nw.tmp matches 1 run loot give @s loot nachtwache:quell/phase4
execute if score #phase nw.phase matches 5 if predicate nachtwache:quell_mob_5 run function nachtwache:quell/mob_5
execute if score #phase nw.phase matches 5 unless score #mobda nw.tmp matches 1 run loot give @s loot nachtwache:quell/phase5
execute if score #phase nw.phase matches 6 if predicate nachtwache:quell_mob_6 run function nachtwache:quell/mob_6
execute if score #phase nw.phase matches 6 unless score #mobda nw.tmp matches 1 run loot give @s loot nachtwache:quell/phase6
execute if score #phase nw.phase matches 7 if predicate nachtwache:quell_mob_7 run function nachtwache:quell/mob_7
execute if score #phase nw.phase matches 7 unless score #mobda nw.tmp matches 1 run loot give @s loot nachtwache:quell/phase7
scoreboard players reset #mobda nw.tmp
title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"#splitter","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"gray"},{"text":"●","color":"white"},{"text":"   mined ","color":"gray"},{"score":{"name":"#abbau","objective":"nw.abbau"},"color":"gray"}]
execute if score #abbau nw.abbau matches 500 run function nachtwache:quell/phase_wechsel {phase:2}
execute if score #abbau nw.abbau matches 1250 run function nachtwache:quell/phase_wechsel {phase:3}
execute if score #abbau nw.abbau matches 2250 run function nachtwache:quell/phase_wechsel {phase:4}
execute if score #abbau nw.abbau matches 3500 run function nachtwache:quell/phase_wechsel {phase:5}
execute if score #abbau nw.abbau matches 5000 run function nachtwache:quell/phase_wechsel {phase:6}
execute if score #abbau nw.abbau matches 6750 run function nachtwache:quell/phase_wechsel {phase:7}
