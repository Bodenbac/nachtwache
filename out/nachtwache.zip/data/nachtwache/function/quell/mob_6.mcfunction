scoreboard players set #mobda nw.tmp 1
summon minecraft:wither_skeleton 0.5 65 0.5 {Tags:["nw.welle","nw.quellmob"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{mainhand:{id:"minecraft:stone_sword",count:1}},drop_chances:{mainhand:0.05f}}
playsound minecraft:entity.evoker.prepare_summon hostile @a 0 64 0 1 0.6
tellraw @a [{"text":"Something crawled out of the Source.","color":"dark_red","italic":true}]
