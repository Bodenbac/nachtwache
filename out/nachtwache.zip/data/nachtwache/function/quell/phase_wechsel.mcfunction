$scoreboard players set #phase nw.phase $(phase)
$title @a title {"text":"Tier $(phase)","color":"dark_purple"}
title @a subtitle {"text":"The Source changes colour. New goods at the Collector.","color":"gray"}
function nachtwache:quell/setzen
playsound minecraft:block.beacon.power_select master @a ~ ~ ~ 1 0.5
function nachtwache:sammler/kaufmenue
function nachtwache:sammler/spruch/phase
