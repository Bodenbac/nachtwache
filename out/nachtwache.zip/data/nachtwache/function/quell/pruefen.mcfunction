execute if score #phase nw.phase matches 1 if block 0 64 0 minecraft:tuff run return 0
execute if score #phase nw.phase matches 2 if block 0 64 0 minecraft:green_concrete run return 0
execute if score #phase nw.phase matches 3 if block 0 64 0 minecraft:blue_concrete run return 0
execute if score #phase nw.phase matches 4 if block 0 64 0 minecraft:budding_amethyst run return 0
execute if score #phase nw.phase matches 5 if block 0 64 0 minecraft:yellow_concrete run return 0
execute if score #phase nw.phase matches 6 if block 0 64 0 minecraft:orange_concrete run return 0
execute if score #phase nw.phase matches 7 if block 0 64 0 minecraft:black_concrete run return 0
scoreboard players set #wer nw.tmp 0
execute if score #wer nw.tmp matches 0 as @a[scores={nw.mined1=1..},limit=1] run function nachtwache:quell/abbau
execute if score #wer nw.tmp matches 0 as @a[scores={nw.mined2=1..},limit=1] run function nachtwache:quell/abbau
execute if score #wer nw.tmp matches 0 as @a[scores={nw.mined3=1..},limit=1] run function nachtwache:quell/abbau
execute if score #wer nw.tmp matches 0 as @a[scores={nw.mined4=1..},limit=1] run function nachtwache:quell/abbau
execute if score #wer nw.tmp matches 0 as @a[scores={nw.mined5=1..},limit=1] run function nachtwache:quell/abbau
execute if score #wer nw.tmp matches 0 as @a[scores={nw.mined6=1..},limit=1] run function nachtwache:quell/abbau
execute if score #wer nw.tmp matches 0 as @a[scores={nw.mined7=1..},limit=1] run function nachtwache:quell/abbau
scoreboard players reset @a nw.mined1
scoreboard players reset @a nw.mined2
scoreboard players reset @a nw.mined3
scoreboard players reset @a nw.mined4
scoreboard players reset @a nw.mined5
scoreboard players reset @a nw.mined6
scoreboard players reset @a nw.mined7
function nachtwache:quell/setzen
kill @e[type=item,x=-1,y=63,z=-1,dx=2,dy=2,dz=2,nbt={Item:{id:"minecraft:tuff"}}]
kill @e[type=item,x=-1,y=63,z=-1,dx=2,dy=2,dz=2,nbt={Item:{id:"minecraft:green_concrete"}}]
kill @e[type=item,x=-1,y=63,z=-1,dx=2,dy=2,dz=2,nbt={Item:{id:"minecraft:blue_concrete"}}]
kill @e[type=item,x=-1,y=63,z=-1,dx=2,dy=2,dz=2,nbt={Item:{id:"minecraft:budding_amethyst"}}]
kill @e[type=item,x=-1,y=63,z=-1,dx=2,dy=2,dz=2,nbt={Item:{id:"minecraft:yellow_concrete"}}]
kill @e[type=item,x=-1,y=63,z=-1,dx=2,dy=2,dz=2,nbt={Item:{id:"minecraft:orange_concrete"}}]
kill @e[type=item,x=-1,y=63,z=-1,dx=2,dy=2,dz=2,nbt={Item:{id:"minecraft:black_concrete"}}]
