execute if score #phase nw.phase matches 1 run setblock 0 64 0 minecraft:tuff
execute if score #phase nw.phase matches 2 run setblock 0 64 0 minecraft:green_concrete
execute if score #phase nw.phase matches 3 run setblock 0 64 0 minecraft:blue_concrete
execute if score #phase nw.phase matches 4 run setblock 0 64 0 minecraft:budding_amethyst
execute if score #phase nw.phase matches 5 run setblock 0 64 0 minecraft:yellow_concrete
execute if score #phase nw.phase matches 6 run setblock 0 64 0 minecraft:orange_concrete
execute if score #phase nw.phase matches 7 run setblock 0 64 0 minecraft:black_concrete
