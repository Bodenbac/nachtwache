scoreboard players set #mobda nw.tmp 1
summon minecraft:skeleton 0.5 65 -6.5 {Tags:["nw.welle","nw.quellmob"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{head:{id:"minecraft:leather_helmet",count:1,components:{"minecraft:unbreakable":{},"minecraft:dyed_color":1315860}},mainhand:{id:"minecraft:bow",count:1}},drop_chances:{head:0.0f,mainhand:0.05f}}
playsound minecraft:entity.evoker.prepare_summon hostile @a 0 64 -7 1 0.6
tellraw @a [{"text":"Something crawled out of the Source.","color":"dark_red","italic":true}]
