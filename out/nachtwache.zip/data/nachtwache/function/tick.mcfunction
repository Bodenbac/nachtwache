scoreboard players add #tick nw.tick 1
scoreboard players operation #m20 nw.tmp = #tick nw.tick
scoreboard players operation #m20 nw.tmp %= #20 nw.const
execute unless score #init nw.status matches 1 run return 0
function nachtwache:quell/pruefen
function nachtwache:uhr/tick
function nachtwache:sammler/interaktion
function nachtwache:sammler/kauf_tick
scoreboard players operation #m5 nw.tmp = #tick nw.tick
scoreboard players operation #m5 nw.tmp %= #5 nw.const
execute if score #m5 nw.tmp matches 0 run function nachtwache:sammler/verkauf
execute as @a[scores={nw.hilfe=1..}] run function nachtwache:hilfe
execute as @a[scores={nw.endlos=1..}] run function nachtwache:nacht/endlos_an
execute as @a[scores={nw.tode=1..}] run function nachtwache:spieler/tod
function nachtwache:gegner/tick
function nachtwache:schutz/tick
function nachtwache:zwerg/tick
execute as @a[tag=nw.admin,scores={reset=1..}] run function nachtwache:admin/reset_trigger
execute as @a[tag=nw.admin,scores={yes=1..}] run function nachtwache:admin/yes_trigger
execute as @a[tag=nw.admin,scores={night=1..}] run function nachtwache:admin/night_trigger
execute as @a[tag=nw.admin,scores={boss=1..}] run function nachtwache:admin/boss_trigger
execute as @a[tag=nw.admin,scores={fraggle=1..}] run function nachtwache:admin/fraggle_trigger
execute if score #m20 nw.tmp matches 0 run function nachtwache:sammler/rampe
execute if score #m20 nw.tmp matches 0 run function nachtwache:schutz/sekunde
execute if score #m20 nw.tmp matches 10 run function nachtwache:anzeige/aktualisieren
execute if score #m20 nw.tmp matches 15 run function nachtwache:uhr/anzeige
execute if score #m20 nw.tmp matches 5 run function nachtwache:atmo/sekunde
function nachtwache:spieler/bett
function nachtwache:nacht/boss_tick
