kill @e[type=item,distance=..2.5,nbt={Item:{id:"minecraft:barrel"}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_gen_show:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_gen_take:1b}}}}]
scoreboard players set #wer nw.tmp 0
execute as @a[distance=..8,scores={nw.mined_gen=1..},limit=1] run function nachtwache:quell/abbau
scoreboard players reset @a nw.mined_gen
setblock ~ ~ ~ minecraft:barrel[facing=down]
function nachtwache:gen/anzeige
