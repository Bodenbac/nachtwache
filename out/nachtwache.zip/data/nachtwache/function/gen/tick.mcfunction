execute as @e[type=marker,tag=nw.gen_neu] at @s run function nachtwache:gen/neu
execute as @e[type=marker,tag=nw.gen] at @s run function nachtwache:gen/einer
execute as @e[type=block_display,tag=nw.gen_block] at @s unless entity @e[type=marker,tag=nw.gen,distance=..1] unless entity @e[type=marker,tag=nw.gen_neu,distance=..1] run kill @s
