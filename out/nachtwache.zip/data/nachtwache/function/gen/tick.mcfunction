execute as @e[type=marker,tag=nw.gen_neu] at @s run function nachtwache:gen/neu
execute as @e[type=marker,tag=nw.gen] at @s run function nachtwache:gen/einer
