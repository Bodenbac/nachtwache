tag @s remove nw.gen_neu
execute align xyz positioned ~0.5 ~0.5 ~0.5 run tp @s ~ ~ ~
execute at @s unless block ~ ~ ~ minecraft:air run return run function nachtwache:gen/zurueck
execute at @s store result score #bz nw.tmp2 run data get entity @s Pos[2]
execute if score #bz nw.tmp2 matches 9.. run tellraw @p[distance=..10] [{"text":"[Nightwatch] ","color":"dark_red"},{"text":"The road and the far island are not yours to build on. The generator comes back.","color":"gray"}]
execute if score #bz nw.tmp2 matches 9.. run return run function nachtwache:gen/zurueck
tag @s add nw.gen
execute at @s run function nachtwache:gen/aufbauen
playsound minecraft:block.amethyst_cluster.place block @a ~ ~ ~ 1 0.8
tellraw @a[distance=..12] [{"text":"A generator hums. Mine it, right-click it to look inside.","color":"light_purple"}]
