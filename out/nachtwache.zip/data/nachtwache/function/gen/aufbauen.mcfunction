setblock ~ ~ ~ minecraft:barrel[facing=down]
function nachtwache:gen/farbe
function nachtwache:gen/anzeige
