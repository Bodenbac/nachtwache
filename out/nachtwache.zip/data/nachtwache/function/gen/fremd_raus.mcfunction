$summon minecraft:item ~ ~1 ~ {Item:$(it),PickupDelay:0s}
