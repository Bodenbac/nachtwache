clear @a[distance=..8] *[custom_data~{nw_gen_take:1b}]
clear @a[distance=..8] *[custom_data~{nw_gen_show:1b}]
execute as @p[distance=..8] run give @s minecraft:budding_amethyst[item_model="nachtwache:generator",custom_name={text:"Source Generator",color:"light_purple",italic:false},custom_data={nw_gen:1b},entity_data={id:"minecraft:marker",Tags:["nw.gen_neu"]},lore=[{text:"Put it down anywhere on your island.",color:"gray",italic:false},{text:"Mine it for blocks and coins, right-click to see what it gives.",color:"gray",italic:false},{text:"Every generator counts towards the same tier.",color:"gray",italic:false}]]
kill @e[type=block_display,tag=nw.gen_block,distance=..1.2]
setblock ~ ~ ~ minecraft:air
kill @e[type=item,distance=..2.5,nbt={Item:{id:"minecraft:barrel"}}]
playsound minecraft:entity.item.pickup player @p[distance=..8] ~ ~ ~ 1 0.8
tellraw @p[distance=..8] [{"text":"The generator is in your inventory.","color":"light_purple"}]
kill @s
