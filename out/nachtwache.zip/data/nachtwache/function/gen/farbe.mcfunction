kill @e[type=block_display,tag=nw.gen_block,distance=..1.2]
execute if score #phase nw.phase matches 1 run summon minecraft:block_display ~-0.5 ~-0.5 ~-0.5 {Tags:["nw.gen_block"],brightness:{sky:15,block:15},block_state:{Name:"minecraft:tuff"}}
execute if score #phase nw.phase matches 2 run summon minecraft:block_display ~-0.5 ~-0.5 ~-0.5 {Tags:["nw.gen_block"],brightness:{sky:15,block:15},block_state:{Name:"minecraft:green_concrete"}}
execute if score #phase nw.phase matches 3 run summon minecraft:block_display ~-0.5 ~-0.5 ~-0.5 {Tags:["nw.gen_block"],brightness:{sky:15,block:15},block_state:{Name:"minecraft:blue_concrete"}}
execute if score #phase nw.phase matches 4 run summon minecraft:block_display ~-0.5 ~-0.5 ~-0.5 {Tags:["nw.gen_block"],brightness:{sky:15,block:15},block_state:{Name:"minecraft:budding_amethyst"}}
execute if score #phase nw.phase matches 5 run summon minecraft:block_display ~-0.5 ~-0.5 ~-0.5 {Tags:["nw.gen_block"],brightness:{sky:15,block:15},block_state:{Name:"minecraft:yellow_concrete"}}
execute if score #phase nw.phase matches 6 run summon minecraft:block_display ~-0.5 ~-0.5 ~-0.5 {Tags:["nw.gen_block"],brightness:{sky:15,block:15},block_state:{Name:"minecraft:orange_concrete"}}
execute if score #phase nw.phase matches 7 run summon minecraft:block_display ~-0.5 ~-0.5 ~-0.5 {Tags:["nw.gen_block"],brightness:{sky:15,block:15},block_state:{Name:"minecraft:black_concrete"}}
