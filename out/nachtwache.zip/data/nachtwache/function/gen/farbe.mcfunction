kill @e[type=block_display,tag=nw.gen_block,distance=..2.5]
