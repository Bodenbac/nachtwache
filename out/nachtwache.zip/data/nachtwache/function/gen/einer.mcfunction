execute unless block ~ ~ ~ minecraft:barrel run function nachtwache:gen/abgebaut
clear @a[distance=..8] *[custom_data~{nw_gen_show:1b}]
execute unless items block ~ ~ ~ container.26 *[custom_data~{nw_gen_take:1b}] run function nachtwache:gen/mitnehmen
execute if score #m20 nw.tmp matches 5 run function nachtwache:gen/fremd
execute if score #m20 nw.tmp matches 7 run function nachtwache:gen/anzeige
execute if score #m20 nw.tmp matches 3 unless entity @e[type=block_display,tag=nw.gen_block,distance=..0.6] run function nachtwache:gen/farbe
execute if score #m20 nw.tmp matches 3 if entity @e[type=block_display,tag=nw.gen_block,tag=!nw.genform5,distance=..0.6] run function nachtwache:gen/farbe
execute store result score #genh nw.tmp2 if entity @e[type=block_display,tag=nw.gen_block,distance=..0.6]
execute if score #m20 nw.tmp matches 3 if score #genh nw.tmp2 matches 2.. run function nachtwache:gen/farbe
