execute unless block ~ ~ ~ minecraft:barrel run function nachtwache:gen/abgebaut
clear @a[distance=..8] *[custom_data~{nw_gen_show:1b}]
execute unless items block ~ ~ ~ container.26 *[custom_data~{nw_gen_take:1b}] run function nachtwache:gen/mitnehmen
execute if score #m20 nw.tmp matches 7 run function nachtwache:gen/anzeige
