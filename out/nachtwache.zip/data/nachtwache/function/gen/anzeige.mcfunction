execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.0 with minecraft:gold_nugget[custom_data={nw_gen_show:1b},custom_name={text:"Coins",color:"white",italic:false},lore=[[{text:"+2 per block",color:"gold",italic:false}],{text:"every block pays",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.1 with minecraft:light_gray_shulker_box[item_model="nachtwache:crate_1",custom_data={nw_gen_show:1b},custom_name={text:"Crate",color:"white",italic:false},lore=[[{text:"0.20 %",color:"gold",italic:false}],{text:"a tier 1 crate",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.2 with minecraft:experience_bottle[custom_data={nw_gen_show:1b},custom_name={text:"Bottle o' Enchanting",color:"white",italic:false},lore=[[{text:"1.00 %",color:"gold",italic:false}],{text:"1 per block",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.3 with minecraft:paper[custom_data={nw_gen_show:1b},custom_name={text:"Nothing else",color:"white",italic:false},lore=[[{text:"98.80 %",color:"gold",italic:false}],{text:"the generator gives no blocks any more",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.4 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.5 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.6 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.7 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.8 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.9 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.10 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.11 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.12 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.13 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.14 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.15 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.16 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.17 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.18 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.19 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.20 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.21 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.22 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.23 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.24 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.25 with minecraft:air
execute if score #phase nw.phase matches 1 run item replace block ~ ~ ~ container.26 with minecraft:ender_eye[item_model="nachtwache:knopf_gen_take_aus",custom_data={nw_knopf:1b,nw_gen_take:1b},custom_name={text:"Take the generator",color:"yellow",italic:false},lore=[{text:"Take this and it goes back into your inventory",color:"gray",italic:false},{text:"Everything it dropped so far stays with you",color:"dark_gray",italic:false}]]
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.0 with minecraft:gold_nugget[custom_data={nw_gen_show:1b},custom_name={text:"Coins",color:"white",italic:false},lore=[[{text:"+4 per block",color:"gold",italic:false}],{text:"every block pays",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.1 with minecraft:green_shulker_box[item_model="nachtwache:crate_2",custom_data={nw_gen_show:1b},custom_name={text:"Crate",color:"white",italic:false},lore=[[{text:"0.20 %",color:"gold",italic:false}],{text:"a tier 2 crate",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.2 with minecraft:experience_bottle[custom_data={nw_gen_show:1b},custom_name={text:"Bottle o' Enchanting",color:"white",italic:false},lore=[[{text:"1.00 %",color:"gold",italic:false}],{text:"1 per block",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.3 with minecraft:paper[custom_data={nw_gen_show:1b},custom_name={text:"Nothing else",color:"white",italic:false},lore=[[{text:"98.80 %",color:"gold",italic:false}],{text:"the generator gives no blocks any more",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.4 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.5 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.6 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.7 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.8 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.9 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.10 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.11 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.12 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.13 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.14 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.15 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.16 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.17 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.18 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.19 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.20 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.21 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.22 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.23 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.24 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.25 with minecraft:air
execute if score #phase nw.phase matches 2 run item replace block ~ ~ ~ container.26 with minecraft:ender_eye[item_model="nachtwache:knopf_gen_take_aus",custom_data={nw_knopf:1b,nw_gen_take:1b},custom_name={text:"Take the generator",color:"yellow",italic:false},lore=[{text:"Take this and it goes back into your inventory",color:"gray",italic:false},{text:"Everything it dropped so far stays with you",color:"dark_gray",italic:false}]]
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.0 with minecraft:gold_nugget[custom_data={nw_gen_show:1b},custom_name={text:"Coins",color:"white",italic:false},lore=[[{text:"+6 per block",color:"gold",italic:false}],{text:"every block pays",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.1 with minecraft:blue_shulker_box[item_model="nachtwache:crate_3",custom_data={nw_gen_show:1b},custom_name={text:"Crate",color:"white",italic:false},lore=[[{text:"0.20 %",color:"gold",italic:false}],{text:"a tier 3 crate",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.2 with minecraft:experience_bottle[custom_data={nw_gen_show:1b},custom_name={text:"Bottle o' Enchanting",color:"white",italic:false},lore=[[{text:"1.00 %",color:"gold",italic:false}],{text:"1 per block",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.3 with minecraft:paper[custom_data={nw_gen_show:1b},custom_name={text:"Nothing else",color:"white",italic:false},lore=[[{text:"98.80 %",color:"gold",italic:false}],{text:"the generator gives no blocks any more",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.4 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.5 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.6 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.7 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.8 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.9 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.10 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.11 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.12 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.13 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.14 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.15 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.16 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.17 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.18 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.19 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.20 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.21 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.22 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.23 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.24 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.25 with minecraft:air
execute if score #phase nw.phase matches 3 run item replace block ~ ~ ~ container.26 with minecraft:ender_eye[item_model="nachtwache:knopf_gen_take_aus",custom_data={nw_knopf:1b,nw_gen_take:1b},custom_name={text:"Take the generator",color:"yellow",italic:false},lore=[{text:"Take this and it goes back into your inventory",color:"gray",italic:false},{text:"Everything it dropped so far stays with you",color:"dark_gray",italic:false}]]
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.0 with minecraft:gold_nugget[custom_data={nw_gen_show:1b},custom_name={text:"Coins",color:"white",italic:false},lore=[[{text:"+8 per block",color:"gold",italic:false}],{text:"every block pays",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.1 with minecraft:purple_shulker_box[item_model="nachtwache:crate_4",custom_data={nw_gen_show:1b},custom_name={text:"Crate",color:"white",italic:false},lore=[[{text:"0.20 %",color:"gold",italic:false}],{text:"a tier 4 crate",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.2 with minecraft:experience_bottle[custom_data={nw_gen_show:1b},custom_name={text:"Bottle o' Enchanting",color:"white",italic:false},lore=[[{text:"1.00 %",color:"gold",italic:false}],{text:"1 per block",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.3 with minecraft:paper[custom_data={nw_gen_show:1b},custom_name={text:"Nothing else",color:"white",italic:false},lore=[[{text:"98.80 %",color:"gold",italic:false}],{text:"the generator gives no blocks any more",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.4 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.5 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.6 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.7 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.8 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.9 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.10 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.11 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.12 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.13 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.14 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.15 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.16 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.17 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.18 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.19 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.20 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.21 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.22 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.23 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.24 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.25 with minecraft:air
execute if score #phase nw.phase matches 4 run item replace block ~ ~ ~ container.26 with minecraft:ender_eye[item_model="nachtwache:knopf_gen_take_aus",custom_data={nw_knopf:1b,nw_gen_take:1b},custom_name={text:"Take the generator",color:"yellow",italic:false},lore=[{text:"Take this and it goes back into your inventory",color:"gray",italic:false},{text:"Everything it dropped so far stays with you",color:"dark_gray",italic:false}]]
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.0 with minecraft:gold_nugget[custom_data={nw_gen_show:1b},custom_name={text:"Coins",color:"white",italic:false},lore=[[{text:"+10 per block",color:"gold",italic:false}],{text:"every block pays",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.1 with minecraft:yellow_shulker_box[item_model="nachtwache:crate_5",custom_data={nw_gen_show:1b},custom_name={text:"Crate",color:"white",italic:false},lore=[[{text:"0.20 %",color:"gold",italic:false}],{text:"a tier 5 crate",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.2 with minecraft:experience_bottle[custom_data={nw_gen_show:1b},custom_name={text:"Bottle o' Enchanting",color:"white",italic:false},lore=[[{text:"1.00 %",color:"gold",italic:false}],{text:"1 per block",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.3 with minecraft:paper[custom_data={nw_gen_show:1b},custom_name={text:"Nothing else",color:"white",italic:false},lore=[[{text:"98.80 %",color:"gold",italic:false}],{text:"the generator gives no blocks any more",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.4 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.5 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.6 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.7 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.8 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.9 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.10 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.11 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.12 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.13 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.14 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.15 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.16 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.17 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.18 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.19 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.20 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.21 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.22 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.23 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.24 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.25 with minecraft:air
execute if score #phase nw.phase matches 5 run item replace block ~ ~ ~ container.26 with minecraft:ender_eye[item_model="nachtwache:knopf_gen_take_aus",custom_data={nw_knopf:1b,nw_gen_take:1b},custom_name={text:"Take the generator",color:"yellow",italic:false},lore=[{text:"Take this and it goes back into your inventory",color:"gray",italic:false},{text:"Everything it dropped so far stays with you",color:"dark_gray",italic:false}]]
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.0 with minecraft:gold_nugget[custom_data={nw_gen_show:1b},custom_name={text:"Coins",color:"white",italic:false},lore=[[{text:"+12 per block",color:"gold",italic:false}],{text:"every block pays",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.1 with minecraft:orange_shulker_box[item_model="nachtwache:crate_6",custom_data={nw_gen_show:1b},custom_name={text:"Crate",color:"white",italic:false},lore=[[{text:"0.20 %",color:"gold",italic:false}],{text:"a tier 6 crate",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.2 with minecraft:experience_bottle[custom_data={nw_gen_show:1b},custom_name={text:"Bottle o' Enchanting",color:"white",italic:false},lore=[[{text:"1.00 %",color:"gold",italic:false}],{text:"1 per block",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.3 with minecraft:paper[custom_data={nw_gen_show:1b},custom_name={text:"Nothing else",color:"white",italic:false},lore=[[{text:"98.80 %",color:"gold",italic:false}],{text:"the generator gives no blocks any more",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.4 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.5 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.6 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.7 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.8 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.9 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.10 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.11 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.12 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.13 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.14 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.15 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.16 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.17 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.18 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.19 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.20 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.21 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.22 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.23 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.24 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.25 with minecraft:air
execute if score #phase nw.phase matches 6 run item replace block ~ ~ ~ container.26 with minecraft:ender_eye[item_model="nachtwache:knopf_gen_take_aus",custom_data={nw_knopf:1b,nw_gen_take:1b},custom_name={text:"Take the generator",color:"yellow",italic:false},lore=[{text:"Take this and it goes back into your inventory",color:"gray",italic:false},{text:"Everything it dropped so far stays with you",color:"dark_gray",italic:false}]]
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.0 with minecraft:gold_nugget[custom_data={nw_gen_show:1b},custom_name={text:"Coins",color:"white",italic:false},lore=[[{text:"+16 per block",color:"gold",italic:false}],{text:"every block pays",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.1 with minecraft:black_shulker_box[item_model="nachtwache:crate_7",custom_data={nw_gen_show:1b},custom_name={text:"Crate",color:"white",italic:false},lore=[[{text:"0.20 %",color:"gold",italic:false}],{text:"a tier 7 crate",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.2 with minecraft:experience_bottle[custom_data={nw_gen_show:1b},custom_name={text:"Bottle o' Enchanting",color:"white",italic:false},lore=[[{text:"1.00 %",color:"gold",italic:false}],{text:"1 per block",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.3 with minecraft:paper[custom_data={nw_gen_show:1b},custom_name={text:"Nothing else",color:"white",italic:false},lore=[[{text:"98.80 %",color:"gold",italic:false}],{text:"the generator gives no blocks any more",color:"gray",italic:false}]]
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.4 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.5 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.6 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.7 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.8 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.9 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.10 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.11 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.12 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.13 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.14 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.15 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.16 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.17 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.18 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.19 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.20 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.21 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.22 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.23 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.24 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.25 with minecraft:air
execute if score #phase nw.phase matches 7 run item replace block ~ ~ ~ container.26 with minecraft:ender_eye[item_model="nachtwache:knopf_gen_take_aus",custom_data={nw_knopf:1b,nw_gen_take:1b},custom_name={text:"Take the generator",color:"yellow",italic:false},lore=[{text:"Take this and it goes back into your inventory",color:"gray",italic:false},{text:"Everything it dropped so far stays with you",color:"dark_gray",italic:false}]]
execute if score #phase nw.phase matches 1 run data merge block ~ ~ ~ {CustomName:[{text:"Source Generator   ",color:"light_purple"},{text:"Tier 1",color:"gray"}]}
execute if score #phase nw.phase matches 2 run data merge block ~ ~ ~ {CustomName:[{text:"Source Generator   ",color:"light_purple"},{text:"Tier 2",color:"gray"}]}
execute if score #phase nw.phase matches 3 run data merge block ~ ~ ~ {CustomName:[{text:"Source Generator   ",color:"light_purple"},{text:"Tier 3",color:"gray"}]}
execute if score #phase nw.phase matches 4 run data merge block ~ ~ ~ {CustomName:[{text:"Source Generator   ",color:"light_purple"},{text:"Tier 4",color:"gray"}]}
execute if score #phase nw.phase matches 5 run data merge block ~ ~ ~ {CustomName:[{text:"Source Generator   ",color:"light_purple"},{text:"Tier 5",color:"gray"}]}
execute if score #phase nw.phase matches 6 run data merge block ~ ~ ~ {CustomName:[{text:"Source Generator   ",color:"light_purple"},{text:"Tier 6",color:"gray"}]}
execute if score #phase nw.phase matches 7 run data merge block ~ ~ ~ {CustomName:[{text:"Source Generator   ",color:"light_purple"},{text:"Tier 7",color:"gray"}]}
