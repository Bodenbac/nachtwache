$data modify storage nachtwache:tmp it set from block ~ ~ ~ Items[{Slot:$(slot)b}]
data remove storage nachtwache:tmp it.Slot
$item replace block ~ ~ ~ container.$(slot) with minecraft:air
function nachtwache:gen/fremd_raus with storage nachtwache:tmp
