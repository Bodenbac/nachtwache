scoreboard players reset @s nw.hilfe
scoreboard players enable @s nw.hilfe
tellraw @s [{"text":"--- NIGHTWATCH ---","color":"dark_red","bold":true}]
tellraw @s [{"text":"The Source ","color":"light_purple"},{"text":"in the middle gives blocks and coins. Mine it, everything goes straight into your inventory.","color":"gray"}]
tellraw @s [{"text":"The Collector: ","color":"dark_red"},{"text":"chest on the left of the counter = BUY (click one, shift-click a stack). Barrel on the right = SELL (put goods in, coins are credited at once, he does not take tools). Hopper outside = drop-off, sells automatically at 80%.","color":"gray"}]
tellraw @s [{"text":"At night ","color":"red"},{"text":"the wave comes over the road. The night only ends when everything is dead. Beds only work when nothing is alive. Walling up does not help, they dig.","color":"gray"}]
tellraw @s [{"text":"Building ","color":"green"},{"text":"is allowed anywhere except the enemy island and the road.","color":"gray"}]
tellraw @s [{"text":"Night 30 ","color":"dark_purple"},{"text":"is the last one. After that it is over, or ","color":"gray"},{"text":"[endless mode]","color":"yellow","click_event":{"action":"run_command","command":"trigger nw.endlos"}},{"text":".","color":"gray"}]
