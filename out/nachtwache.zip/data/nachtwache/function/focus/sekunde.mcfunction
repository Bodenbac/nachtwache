execute if score #focus nw.upgrade matches 1.. run scoreboard players remove #focus nw.upgrade 20
execute if score #focus nw.upgrade matches 1.. run particle minecraft:end_rod 0.5 65.2 0.5 0.3 0.2 0.3 0.01 3
execute if score #focus nw.upgrade matches 0 run function nachtwache:focus/ende
