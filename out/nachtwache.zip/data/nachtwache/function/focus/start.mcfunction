advancement revoke @s only nachtwache:focus_benutzt
scoreboard players set #focus nw.upgrade 12000
tellraw @a [{"text":"The Source glows. Double coins for ten minutes.","color":"light_purple"}]
playsound minecraft:block.beacon.activate master @a ~ ~ ~ 1 1.4
execute at @a run particle minecraft:witch ~ ~1 ~ 0.6 1 0.6 0.1 30
