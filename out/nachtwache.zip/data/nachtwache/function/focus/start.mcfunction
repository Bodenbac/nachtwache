advancement revoke @s only nachtwache:focus_benutzt
execute store result score #froll nw.tmp2 run random value 10..180
scoreboard players operation #froll nw.tmp2 *= #20 nw.const
execute if score #focus nw.upgrade matches 1.. run scoreboard players operation #froll nw.tmp2 += #focus nw.upgrade
scoreboard players operation #focus nw.upgrade = #froll nw.tmp2
execute store result bossbar nw:focus max run scoreboard players get #focus nw.upgrade
bossbar set nw:focus players @a
bossbar set nw:focus visible true
function nachtwache:focus/leiste
tellraw @a [{"text":"The Source glows. Double coins for ","color":"light_purple"},{"score":{"name":"#fsek","objective":"nw.tmp2"},"color":"white"},{"text":" seconds.","color":"light_purple"}]
playsound minecraft:block.beacon.activate master @a ~ ~ ~ 1 1.4
execute at @a run particle minecraft:witch ~ ~1 ~ 0.6 1 0.6 0.1 30
