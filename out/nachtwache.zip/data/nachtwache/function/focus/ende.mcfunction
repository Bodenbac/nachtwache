scoreboard players set #focus nw.upgrade -1
bossbar set nw:focus visible false
tellraw @a [{"text":"The Source dims again.","color":"gray","italic":true}]
