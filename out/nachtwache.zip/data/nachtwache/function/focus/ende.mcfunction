scoreboard players set #focus nw.upgrade -1
tellraw @a [{"text":"The Source dims again.","color":"gray","italic":true}]
