scoreboard players operation #fsek nw.tmp2 = #focus nw.upgrade
scoreboard players operation #fsek nw.tmp2 /= #20 nw.const
execute store result bossbar nw:focus value run scoreboard players get #focus nw.upgrade
execute store result storage nachtwache:tmp s int 1 run scoreboard players get #fsek nw.tmp2
function nachtwache:focus/leiste_name with storage nachtwache:tmp
