$bossbar set nw:focus name [{"text":"Source Focus  ","color":"light_purple"},{"text":"$(s)s","color":"white"}]
