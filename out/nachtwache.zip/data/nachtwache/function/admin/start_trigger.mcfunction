scoreboard players set @s start 0
scoreboard players enable @s start
function nachtwache:admin/start
