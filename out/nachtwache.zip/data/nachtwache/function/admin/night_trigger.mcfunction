scoreboard players operation #n nw.tmp = @s night
scoreboard players set @s night 0
scoreboard players enable @s night
execute unless score #n nw.tmp matches 1..30 run return run tellraw @s [{"text":"[Nightwatch] /trigger night set <1..30>","color":"yellow"}]
kill @e[tag=nw.welle]
function nachtwache:gegner/vergessen
scoreboard players set #gegner nw.gegner 0
scoreboard players set #boss nw.boss 0
bossbar set nw:boss visible false
scoreboard players set #status nw.status 0
scoreboard players set #nacht_haelt nw.status 0
scoreboard players operation #nacht nw.nacht = #n nw.tmp
scoreboard players remove #nacht nw.nacht 1
scoreboard players set #zeit nw.zeit 13000
tellraw @a [{"text":"[Nightwatch] Night ","color":"yellow"},{"score":{"name":"#n","objective":"nw.tmp"},"color":"yellow"},{"text":" starts now.","color":"yellow"}]
