scoreboard players operation #n nw.tmp = @s boss
scoreboard players set @s boss 0
scoreboard players enable @s boss
kill @e[tag=nw.boss]
scoreboard players set #boss nw.boss 0
execute if score #n nw.tmp matches 5 run return run function nachtwache:nacht/boss_5
execute if score #n nw.tmp matches 10 run return run function nachtwache:nacht/boss_10
execute if score #n nw.tmp matches 15 run return run function nachtwache:nacht/boss_15
execute if score #n nw.tmp matches 20 run return run function nachtwache:nacht/boss_20
execute if score #n nw.tmp matches 25 run return run function nachtwache:nacht/boss_25
execute if score #n nw.tmp matches 30 run return run function nachtwache:nacht/boss_30
tellraw @s [{"text":"[Nightwatch] /trigger boss set <5|10|15|20|25|30>","color":"yellow"}]
