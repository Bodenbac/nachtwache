execute unless score #pause nw.status matches 1 run tellraw @a [{"text":"[Nightwatch] The watch is already running.","color":"yellow"}]
execute unless score #pause nw.status matches 1 unless entity @s run say [Nightwatch] The watch is already running.
execute unless score #pause nw.status matches 1 run return 0
scoreboard players set #pause nw.status 0
title @a times 10 60 20
title @a title [{"text":"NIGHTWATCH","color":"dark_red","bold":true}]
title @a subtitle [{"text":"The watch begins.","color":"gray"}]
playsound minecraft:block.bell.use block @a ~ ~ ~ 1 0.8
tellraw @a [{"text":"[Nightwatch] The watch begins. The clock is running.","color":"yellow"}]
execute unless entity @s run say [Nightwatch] The watch begins. The clock is running.
