execute unless score #reset_frist nw.status >= #tick nw.tick run tellraw @a [{"text":"[Nightwatch] No reset pending. Type /trigger reset first, or function nachtwache:reset in the console.","color":"yellow"}]
execute unless score #reset_frist nw.status >= #tick nw.tick unless entity @s run say [Nightwatch] No reset pending. Run function nachtwache:reset first.
execute unless score #reset_frist nw.status >= #tick nw.tick run return 0
scoreboard players set #reset_frist nw.status 0
tellraw @a [{"text":"[Nightwatch] Resetting the world. This takes a moment.","color":"red"}]
gamemode survival @a
clear @a
experience set @a 0 points
experience set @a 0 levels
effect clear @a
kill @e[type=item]
kill @e[type=!player]
tp @a 0 66 -10
spawnpoint @a 0 64 -10
forceload add -48 -48 47 127
item replace entity @a enderchest.0 with minecraft:air
item replace entity @a enderchest.1 with minecraft:air
item replace entity @a enderchest.2 with minecraft:air
item replace entity @a enderchest.3 with minecraft:air
item replace entity @a enderchest.4 with minecraft:air
item replace entity @a enderchest.5 with minecraft:air
item replace entity @a enderchest.6 with minecraft:air
item replace entity @a enderchest.7 with minecraft:air
item replace entity @a enderchest.8 with minecraft:air
item replace entity @a enderchest.9 with minecraft:air
item replace entity @a enderchest.10 with minecraft:air
item replace entity @a enderchest.11 with minecraft:air
item replace entity @a enderchest.12 with minecraft:air
item replace entity @a enderchest.13 with minecraft:air
item replace entity @a enderchest.14 with minecraft:air
item replace entity @a enderchest.15 with minecraft:air
item replace entity @a enderchest.16 with minecraft:air
item replace entity @a enderchest.17 with minecraft:air
item replace entity @a enderchest.18 with minecraft:air
item replace entity @a enderchest.19 with minecraft:air
item replace entity @a enderchest.20 with minecraft:air
item replace entity @a enderchest.21 with minecraft:air
item replace entity @a enderchest.22 with minecraft:air
item replace entity @a enderchest.23 with minecraft:air
item replace entity @a enderchest.24 with minecraft:air
item replace entity @a enderchest.25 with minecraft:air
item replace entity @a enderchest.26 with minecraft:air
fill -48 0 -48 47 0 127 minecraft:air
fill -48 1 -48 47 1 127 minecraft:air
fill -48 2 -48 47 2 127 minecraft:air
fill -48 3 -48 47 3 127 minecraft:air
fill -48 4 -48 47 4 127 minecraft:air
fill -48 5 -48 47 5 127 minecraft:air
fill -48 6 -48 47 6 127 minecraft:air
fill -48 7 -48 47 7 127 minecraft:air
fill -48 8 -48 47 8 127 minecraft:air
fill -48 9 -48 47 9 127 minecraft:air
fill -48 10 -48 47 10 127 minecraft:air
fill -48 11 -48 47 11 127 minecraft:air
fill -48 12 -48 47 12 127 minecraft:air
fill -48 13 -48 47 13 127 minecraft:air
fill -48 14 -48 47 14 127 minecraft:air
fill -48 15 -48 47 15 127 minecraft:air
fill -48 16 -48 47 16 127 minecraft:air
fill -48 17 -48 47 17 127 minecraft:air
fill -48 18 -48 47 18 127 minecraft:air
fill -48 19 -48 47 19 127 minecraft:air
fill -48 20 -48 47 20 127 minecraft:air
fill -48 21 -48 47 21 127 minecraft:air
fill -48 22 -48 47 22 127 minecraft:air
fill -48 23 -48 47 23 127 minecraft:air
fill -48 24 -48 47 24 127 minecraft:air
fill -48 25 -48 47 25 127 minecraft:air
fill -48 26 -48 47 26 127 minecraft:air
fill -48 27 -48 47 27 127 minecraft:air
fill -48 28 -48 47 28 127 minecraft:air
fill -48 29 -48 47 29 127 minecraft:air
fill -48 30 -48 47 30 127 minecraft:air
fill -48 31 -48 47 31 127 minecraft:air
fill -48 32 -48 47 32 127 minecraft:air
fill -48 33 -48 47 33 127 minecraft:air
fill -48 34 -48 47 34 127 minecraft:air
fill -48 35 -48 47 35 127 minecraft:air
fill -48 36 -48 47 36 127 minecraft:air
fill -48 37 -48 47 37 127 minecraft:air
fill -48 38 -48 47 38 127 minecraft:air
fill -48 39 -48 47 39 127 minecraft:air
fill -48 40 -48 47 40 127 minecraft:air
fill -48 41 -48 47 41 127 minecraft:air
fill -48 42 -48 47 42 127 minecraft:air
fill -48 43 -48 47 43 127 minecraft:air
fill -48 44 -48 47 44 127 minecraft:air
fill -48 45 -48 47 45 127 minecraft:air
fill -48 46 -48 47 46 127 minecraft:air
fill -48 47 -48 47 47 127 minecraft:air
fill -48 48 -48 47 48 127 minecraft:air
fill -48 49 -48 47 49 127 minecraft:air
fill -48 50 -48 47 50 127 minecraft:air
fill -48 51 -48 47 51 127 minecraft:air
fill -48 52 -48 47 52 127 minecraft:air
fill -48 53 -48 47 53 127 minecraft:air
fill -48 54 -48 47 54 127 minecraft:air
fill -48 55 -48 47 55 127 minecraft:air
fill -48 56 -48 47 56 127 minecraft:air
fill -48 57 -48 47 57 127 minecraft:air
fill -48 58 -48 47 58 127 minecraft:air
fill -48 59 -48 47 59 127 minecraft:air
fill -48 60 -48 47 60 127 minecraft:air
fill -48 61 -48 47 61 127 minecraft:air
fill -48 62 -48 47 62 127 minecraft:air
fill -48 63 -48 47 63 127 minecraft:air
fill -48 64 -48 47 64 127 minecraft:air
fill -48 65 -48 47 65 127 minecraft:air
fill -48 66 -48 47 66 127 minecraft:air
fill -48 67 -48 47 67 127 minecraft:air
fill -48 68 -48 47 68 127 minecraft:air
fill -48 69 -48 47 69 127 minecraft:air
fill -48 70 -48 47 70 127 minecraft:air
fill -48 71 -48 47 71 127 minecraft:air
fill -48 72 -48 47 72 127 minecraft:air
fill -48 73 -48 47 73 127 minecraft:air
fill -48 74 -48 47 74 127 minecraft:air
fill -48 75 -48 47 75 127 minecraft:air
fill -48 76 -48 47 76 127 minecraft:air
fill -48 77 -48 47 77 127 minecraft:air
fill -48 78 -48 47 78 127 minecraft:air
fill -48 79 -48 47 79 127 minecraft:air
fill -48 80 -48 47 80 127 minecraft:air
fill -48 81 -48 47 81 127 minecraft:air
fill -48 82 -48 47 82 127 minecraft:air
fill -48 83 -48 47 83 127 minecraft:air
fill -48 84 -48 47 84 127 minecraft:air
fill -48 85 -48 47 85 127 minecraft:air
fill -48 86 -48 47 86 127 minecraft:air
fill -48 87 -48 47 87 127 minecraft:air
fill -48 88 -48 47 88 127 minecraft:air
fill -48 89 -48 47 89 127 minecraft:air
fill -48 90 -48 47 90 127 minecraft:air
fill -48 91 -48 47 91 127 minecraft:air
fill -48 92 -48 47 92 127 minecraft:air
fill -48 93 -48 47 93 127 minecraft:air
fill -48 94 -48 47 94 127 minecraft:air
fill -48 95 -48 47 95 127 minecraft:air
fill -48 96 -48 47 96 127 minecraft:air
fill -48 97 -48 47 97 127 minecraft:air
fill -48 98 -48 47 98 127 minecraft:air
fill -48 99 -48 47 99 127 minecraft:air
fill -48 100 -48 47 100 127 minecraft:air
fill -48 101 -48 47 101 127 minecraft:air
fill -48 102 -48 47 102 127 minecraft:air
fill -48 103 -48 47 103 127 minecraft:air
fill -48 104 -48 47 104 127 minecraft:air
fill -48 105 -48 47 105 127 minecraft:air
fill -48 106 -48 47 106 127 minecraft:air
fill -48 107 -48 47 107 127 minecraft:air
fill -48 108 -48 47 108 127 minecraft:air
fill -48 109 -48 47 109 127 minecraft:air
fill -48 110 -48 47 110 127 minecraft:air
fill -48 111 -48 47 111 127 minecraft:air
fill -48 112 -48 47 112 127 minecraft:air
fill -48 113 -48 47 113 127 minecraft:air
fill -48 114 -48 47 114 127 minecraft:air
fill -48 115 -48 47 115 127 minecraft:air
fill -48 116 -48 47 116 127 minecraft:air
fill -48 117 -48 47 117 127 minecraft:air
fill -48 118 -48 47 118 127 minecraft:air
fill -48 119 -48 47 119 127 minecraft:air
fill -48 120 -48 47 120 127 minecraft:air
fill -48 121 -48 47 121 127 minecraft:air
fill -48 122 -48 47 122 127 minecraft:air
fill -48 123 -48 47 123 127 minecraft:air
fill -48 124 -48 47 124 127 minecraft:air
fill -48 125 -48 47 125 127 minecraft:air
fill -48 126 -48 47 126 127 minecraft:air
fill -48 127 -48 47 127 127 minecraft:air
fill -48 128 -48 47 128 127 minecraft:air
fill -48 129 -48 47 129 127 minecraft:air
fill -48 130 -48 47 130 127 minecraft:air
fill -48 131 -48 47 131 127 minecraft:air
fill -48 132 -48 47 132 127 minecraft:air
fill -48 133 -48 47 133 127 minecraft:air
fill -48 134 -48 47 134 127 minecraft:air
fill -48 135 -48 47 135 127 minecraft:air
fill -48 136 -48 47 136 127 minecraft:air
fill -48 137 -48 47 137 127 minecraft:air
fill -48 138 -48 47 138 127 minecraft:air
fill -48 139 -48 47 139 127 minecraft:air
fill -48 140 -48 47 140 127 minecraft:air
fill -48 141 -48 47 141 127 minecraft:air
fill -48 142 -48 47 142 127 minecraft:air
fill -48 143 -48 47 143 127 minecraft:air
fill -48 144 -48 47 144 127 minecraft:air
fill -48 145 -48 47 145 127 minecraft:air
fill -48 146 -48 47 146 127 minecraft:air
fill -48 147 -48 47 147 127 minecraft:air
fill -48 148 -48 47 148 127 minecraft:air
fill -48 149 -48 47 149 127 minecraft:air
fill -48 150 -48 47 150 127 minecraft:air
fill -48 151 -48 47 151 127 minecraft:air
fill -48 152 -48 47 152 127 minecraft:air
fill -48 153 -48 47 153 127 minecraft:air
fill -48 154 -48 47 154 127 minecraft:air
fill -48 155 -48 47 155 127 minecraft:air
fill -48 156 -48 47 156 127 minecraft:air
fill -48 157 -48 47 157 127 minecraft:air
fill -48 158 -48 47 158 127 minecraft:air
fill -48 159 -48 47 159 127 minecraft:air
fill -48 160 -48 47 160 127 minecraft:air
kill @e[type=!player]
forceload remove -48 -48 47 127
scoreboard players reset * nw.tode
scoreboard players reset * nw.schlaf
function nachtwache:admin/neustart
scoreboard players set #pause nw.status 1
tellraw @a [{"text":"[Nightwatch] Fresh start. Day 1, tier 1, empty pockets. Nether and End are untouched.","color":"yellow"}]
tellraw @a [{"text":"[Nightwatch] The clock stands still. ","color":"yellow"},{"text":"Get ready, then start the watch with ","color":"gray"},{"text":"/trigger start","color":"yellow"},{"text":" (console: ","color":"gray"},{"text":"function nachtwache:start","color":"yellow"},{"text":").","color":"gray"}]
execute unless entity @s run say [Nightwatch] Fresh start, the clock stands still. Begin with: function nachtwache:start
