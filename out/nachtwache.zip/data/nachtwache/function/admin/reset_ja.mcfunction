execute unless score #reset_frist nw.status >= #tick nw.tick run tellraw @a [{"text":"[Nightwatch] No reset pending. Type /trigger reset first, or function nachtwache:reset in the console.","color":"yellow"}]
execute unless score #reset_frist nw.status >= #tick nw.tick unless entity @s run say [Nightwatch] No reset pending. Run function nachtwache:reset first.
execute unless score #reset_frist nw.status >= #tick nw.tick run return 0
scoreboard players set #reset_frist nw.status 0
tellraw @a [{"text":"[Nightwatch] Resetting the world. This takes a moment.","color":"red"}]
gamemode survival @a
clear @a
experience set @a 0 points
experience set @a 0 levels
effect clear @a
effect give @a minecraft:instant_health 1 20 true
effect give @a minecraft:saturation 1 20 true
kill @e[type=item]
kill @e[type=!player]
tp @a 0 66 -10
spawnpoint @a 0 64 -10
forceload add -48 -48 47 127
item replace entity @a enderchest.0 with minecraft:air
item replace entity @a enderchest.1 with minecraft:air
item replace entity @a enderchest.2 with minecraft:air
item replace entity @a enderchest.3 with minecraft:air
item replace entity @a enderchest.4 with minecraft:air
item replace entity @a enderchest.5 with minecraft:air
item replace entity @a enderchest.6 with minecraft:air
item replace entity @a enderchest.7 with minecraft:air
item replace entity @a enderchest.8 with minecraft:air
item replace entity @a enderchest.9 with minecraft:air
item replace entity @a enderchest.10 with minecraft:air
item replace entity @a enderchest.11 with minecraft:air
item replace entity @a enderchest.12 with minecraft:air
item replace entity @a enderchest.13 with minecraft:air
item replace entity @a enderchest.14 with minecraft:air
item replace entity @a enderchest.15 with minecraft:air
item replace entity @a enderchest.16 with minecraft:air
item replace entity @a enderchest.17 with minecraft:air
item replace entity @a enderchest.18 with minecraft:air
item replace entity @a enderchest.19 with minecraft:air
item replace entity @a enderchest.20 with minecraft:air
item replace entity @a enderchest.21 with minecraft:air
item replace entity @a enderchest.22 with minecraft:air
item replace entity @a enderchest.23 with minecraft:air
item replace entity @a enderchest.24 with minecraft:air
item replace entity @a enderchest.25 with minecraft:air
item replace entity @a enderchest.26 with minecraft:air
fill -48 0 -48 47 0 127 minecraft:air
fill -48 1 -48 47 1 127 minecraft:air
fill -48 2 -48 47 2 127 minecraft:air
fill -48 3 -48 47 3 127 minecraft:air
fill -48 4 -48 47 4 127 minecraft:air
fill -48 5 -48 47 5 127 minecraft:air
fill -48 6 -48 47 6 127 minecraft:air
fill -48 7 -48 47 7 127 minecraft:air
fill -48 8 -48 47 8 127 minecraft:air
fill -48 9 -48 47 9 127 minecraft:air
fill -48 10 -48 47 10 127 minecraft:air
fill -48 11 -48 47 11 127 minecraft:air
fill -48 12 -48 47 12 127 minecraft:air
fill -48 13 -48 47 13 127 minecraft:air
fill -48 14 -48 47 14 127 minecraft:air
fill -48 15 -48 47 15 127 minecraft:air
fill -48 16 -48 47 16 127 minecraft:air
fill -48 17 -48 47 17 127 minecraft:air
fill -48 18 -48 47 18 127 minecraft:air
fill -48 19 -48 47 19 127 minecraft:air
fill -48 20 -48 47 20 127 minecraft:air
fill -48 21 -48 47 21 127 minecraft:air
fill -48 22 -48 47 22 127 minecraft:air
fill -48 23 -48 47 23 127 minecraft:air
fill -48 24 -48 47 24 127 minecraft:air
fill -48 25 -48 47 25 127 minecraft:air
fill -48 26 -48 47 26 127 minecraft:air
fill -48 27 -48 47 27 127 minecraft:air
fill -48 28 -48 47 28 127 minecraft:air
fill -48 29 -48 47 29 127 minecraft:air
fill -48 30 -48 47 30 127 minecraft:air
fill -48 31 -48 47 31 127 minecraft:air
fill -48 32 -48 47 32 127 minecraft:air
fill -48 33 -48 47 33 127 minecraft:air
fill -48 34 -48 47 34 127 minecraft:air
fill -48 35 -48 47 35 127 minecraft:air
fill -48 36 -48 47 36 127 minecraft:air
fill -48 37 -48 47 37 127 minecraft:air
fill -48 38 -48 47 38 127 minecraft:air
fill -48 39 -48 47 39 127 minecraft:air
fill -48 40 -48 47 40 127 minecraft:air
fill -48 41 -48 47 41 127 minecraft:air
fill -48 42 -48 47 42 127 minecraft:air
fill -48 43 -48 47 43 127 minecraft:air
fill -48 44 -48 47 44 127 minecraft:air
fill -48 45 -48 47 45 127 minecraft:air
fill -48 46 -48 47 46 127 minecraft:air
fill -48 47 -48 47 47 127 minecraft:air
fill -48 48 -48 47 48 127 minecraft:air
fill -48 49 -48 47 49 127 minecraft:air
fill -48 50 -48 47 50 127 minecraft:air
fill -48 51 -48 47 51 127 minecraft:air
fill -48 52 -48 47 52 127 minecraft:air
fill -48 53 -48 47 53 127 minecraft:air
fill -48 54 -48 47 54 127 minecraft:air
fill -48 55 -48 47 55 127 minecraft:air
fill -48 56 -48 47 56 127 minecraft:air
fill -48 57 -48 47 57 127 minecraft:air
fill -48 58 -48 47 58 127 minecraft:air
fill -48 59 -48 47 59 127 minecraft:air
fill -48 60 -48 47 60 127 minecraft:air
fill -48 61 -48 47 61 127 minecraft:air
fill -48 62 -48 47 62 127 minecraft:air
fill -48 63 -48 47 63 127 minecraft:air
fill -48 64 -48 47 64 127 minecraft:air
fill -48 65 -48 47 65 127 minecraft:air
fill -48 66 -48 47 66 127 minecraft:air
fill -48 67 -48 47 67 127 minecraft:air
fill -48 68 -48 47 68 127 minecraft:air
fill -48 69 -48 47 69 127 minecraft:air
fill -48 70 -48 47 70 127 minecraft:air
fill -48 71 -48 47 71 127 minecraft:air
fill -48 72 -48 47 72 127 minecraft:air
fill -48 73 -48 47 73 127 minecraft:air
fill -48 74 -48 47 74 127 minecraft:air
fill -48 75 -48 47 75 127 minecraft:air
fill -48 76 -48 47 76 127 minecraft:air
fill -48 77 -48 47 77 127 minecraft:air
fill -48 78 -48 47 78 127 minecraft:air
fill -48 79 -48 47 79 127 minecraft:air
fill -48 80 -48 47 80 127 minecraft:air
fill -48 81 -48 47 81 127 minecraft:air
fill -48 82 -48 47 82 127 minecraft:air
fill -48 83 -48 47 83 127 minecraft:air
fill -48 84 -48 47 84 127 minecraft:air
fill -48 85 -48 47 85 127 minecraft:air
fill -48 86 -48 47 86 127 minecraft:air
fill -48 87 -48 47 87 127 minecraft:air
fill -48 88 -48 47 88 127 minecraft:air
fill -48 89 -48 47 89 127 minecraft:air
fill -48 90 -48 47 90 127 minecraft:air
fill -48 91 -48 47 91 127 minecraft:air
fill -48 92 -48 47 92 127 minecraft:air
fill -48 93 -48 47 93 127 minecraft:air
fill -48 94 -48 47 94 127 minecraft:air
fill -48 95 -48 47 95 127 minecraft:air
fill -48 96 -48 47 96 127 minecraft:air
fill -48 97 -48 47 97 127 minecraft:air
fill -48 98 -48 47 98 127 minecraft:air
fill -48 99 -48 47 99 127 minecraft:air
fill -48 100 -48 47 100 127 minecraft:air
fill -48 101 -48 47 101 127 minecraft:air
fill -48 102 -48 47 102 127 minecraft:air
fill -48 103 -48 47 103 127 minecraft:air
fill -48 104 -48 47 104 127 minecraft:air
fill -48 105 -48 47 105 127 minecraft:air
fill -48 106 -48 47 106 127 minecraft:air
fill -48 107 -48 47 107 127 minecraft:air
fill -48 108 -48 47 108 127 minecraft:air
fill -48 109 -48 47 109 127 minecraft:air
fill -48 110 -48 47 110 127 minecraft:air
fill -48 111 -48 47 111 127 minecraft:air
fill -48 112 -48 47 112 127 minecraft:air
fill -48 113 -48 47 113 127 minecraft:air
fill -48 114 -48 47 114 127 minecraft:air
fill -48 115 -48 47 115 127 minecraft:air
fill -48 116 -48 47 116 127 minecraft:air
fill -48 117 -48 47 117 127 minecraft:air
fill -48 118 -48 47 118 127 minecraft:air
fill -48 119 -48 47 119 127 minecraft:air
fill -48 120 -48 47 120 127 minecraft:air
fill -48 121 -48 47 121 127 minecraft:air
fill -48 122 -48 47 122 127 minecraft:air
fill -48 123 -48 47 123 127 minecraft:air
fill -48 124 -48 47 124 127 minecraft:air
fill -48 125 -48 47 125 127 minecraft:air
fill -48 126 -48 47 126 127 minecraft:air
fill -48 127 -48 47 127 127 minecraft:air
fill -48 128 -48 47 128 127 minecraft:air
fill -48 129 -48 47 129 127 minecraft:air
fill -48 130 -48 47 130 127 minecraft:air
fill -48 131 -48 47 131 127 minecraft:air
fill -48 132 -48 47 132 127 minecraft:air
fill -48 133 -48 47 133 127 minecraft:air
fill -48 134 -48 47 134 127 minecraft:air
fill -48 135 -48 47 135 127 minecraft:air
fill -48 136 -48 47 136 127 minecraft:air
fill -48 137 -48 47 137 127 minecraft:air
fill -48 138 -48 47 138 127 minecraft:air
fill -48 139 -48 47 139 127 minecraft:air
fill -48 140 -48 47 140 127 minecraft:air
fill -48 141 -48 47 141 127 minecraft:air
fill -48 142 -48 47 142 127 minecraft:air
fill -48 143 -48 47 143 127 minecraft:air
fill -48 144 -48 47 144 127 minecraft:air
fill -48 145 -48 47 145 127 minecraft:air
fill -48 146 -48 47 146 127 minecraft:air
fill -48 147 -48 47 147 127 minecraft:air
fill -48 148 -48 47 148 127 minecraft:air
fill -48 149 -48 47 149 127 minecraft:air
fill -48 150 -48 47 150 127 minecraft:air
fill -48 151 -48 47 151 127 minecraft:air
fill -48 152 -48 47 152 127 minecraft:air
fill -48 153 -48 47 153 127 minecraft:air
fill -48 154 -48 47 154 127 minecraft:air
fill -48 155 -48 47 155 127 minecraft:air
fill -48 156 -48 47 156 127 minecraft:air
fill -48 157 -48 47 157 127 minecraft:air
fill -48 158 -48 47 158 127 minecraft:air
fill -48 159 -48 47 159 127 minecraft:air
fill -48 160 -48 47 160 127 minecraft:air
kill @e[type=!player]
execute in minecraft:the_nether run fill -32 0 -32 31 0 111 minecraft:air
execute in minecraft:the_nether run fill -32 1 -32 31 1 111 minecraft:air
execute in minecraft:the_nether run fill -32 2 -32 31 2 111 minecraft:air
execute in minecraft:the_nether run fill -32 3 -32 31 3 111 minecraft:air
execute in minecraft:the_nether run fill -32 4 -32 31 4 111 minecraft:air
execute in minecraft:the_nether run fill -32 5 -32 31 5 111 minecraft:air
execute in minecraft:the_nether run fill -32 6 -32 31 6 111 minecraft:air
execute in minecraft:the_nether run fill -32 7 -32 31 7 111 minecraft:air
execute in minecraft:the_nether run fill -32 8 -32 31 8 111 minecraft:air
execute in minecraft:the_nether run fill -32 9 -32 31 9 111 minecraft:air
execute in minecraft:the_nether run fill -32 10 -32 31 10 111 minecraft:air
execute in minecraft:the_nether run fill -32 11 -32 31 11 111 minecraft:air
execute in minecraft:the_nether run fill -32 12 -32 31 12 111 minecraft:air
execute in minecraft:the_nether run fill -32 13 -32 31 13 111 minecraft:air
execute in minecraft:the_nether run fill -32 14 -32 31 14 111 minecraft:air
execute in minecraft:the_nether run fill -32 15 -32 31 15 111 minecraft:air
execute in minecraft:the_nether run fill -32 16 -32 31 16 111 minecraft:air
execute in minecraft:the_nether run fill -32 17 -32 31 17 111 minecraft:air
execute in minecraft:the_nether run fill -32 18 -32 31 18 111 minecraft:air
execute in minecraft:the_nether run fill -32 19 -32 31 19 111 minecraft:air
execute in minecraft:the_nether run fill -32 20 -32 31 20 111 minecraft:air
execute in minecraft:the_nether run fill -32 21 -32 31 21 111 minecraft:air
execute in minecraft:the_nether run fill -32 22 -32 31 22 111 minecraft:air
execute in minecraft:the_nether run fill -32 23 -32 31 23 111 minecraft:air
execute in minecraft:the_nether run fill -32 24 -32 31 24 111 minecraft:air
execute in minecraft:the_nether run fill -32 25 -32 31 25 111 minecraft:air
execute in minecraft:the_nether run fill -32 26 -32 31 26 111 minecraft:air
execute in minecraft:the_nether run fill -32 27 -32 31 27 111 minecraft:air
execute in minecraft:the_nether run fill -32 28 -32 31 28 111 minecraft:air
execute in minecraft:the_nether run fill -32 29 -32 31 29 111 minecraft:air
execute in minecraft:the_nether run fill -32 30 -32 31 30 111 minecraft:air
execute in minecraft:the_nether run fill -32 31 -32 31 31 111 minecraft:air
execute in minecraft:the_nether run fill -32 32 -32 31 32 111 minecraft:air
execute in minecraft:the_nether run fill -32 33 -32 31 33 111 minecraft:air
execute in minecraft:the_nether run fill -32 34 -32 31 34 111 minecraft:air
execute in minecraft:the_nether run fill -32 35 -32 31 35 111 minecraft:air
execute in minecraft:the_nether run fill -32 36 -32 31 36 111 minecraft:air
execute in minecraft:the_nether run fill -32 37 -32 31 37 111 minecraft:air
execute in minecraft:the_nether run fill -32 38 -32 31 38 111 minecraft:air
execute in minecraft:the_nether run fill -32 39 -32 31 39 111 minecraft:air
execute in minecraft:the_nether run fill -32 40 -32 31 40 111 minecraft:air
execute in minecraft:the_nether run fill -32 41 -32 31 41 111 minecraft:air
execute in minecraft:the_nether run fill -32 42 -32 31 42 111 minecraft:air
execute in minecraft:the_nether run fill -32 43 -32 31 43 111 minecraft:air
execute in minecraft:the_nether run fill -32 44 -32 31 44 111 minecraft:air
execute in minecraft:the_nether run fill -32 45 -32 31 45 111 minecraft:air
execute in minecraft:the_nether run fill -32 46 -32 31 46 111 minecraft:air
execute in minecraft:the_nether run fill -32 47 -32 31 47 111 minecraft:air
execute in minecraft:the_nether run fill -32 48 -32 31 48 111 minecraft:air
execute in minecraft:the_nether run fill -32 49 -32 31 49 111 minecraft:air
execute in minecraft:the_nether run fill -32 50 -32 31 50 111 minecraft:air
execute in minecraft:the_nether run fill -32 51 -32 31 51 111 minecraft:air
execute in minecraft:the_nether run fill -32 52 -32 31 52 111 minecraft:air
execute in minecraft:the_nether run fill -32 53 -32 31 53 111 minecraft:air
execute in minecraft:the_nether run fill -32 54 -32 31 54 111 minecraft:air
execute in minecraft:the_nether run fill -32 55 -32 31 55 111 minecraft:air
execute in minecraft:the_nether run fill -32 56 -32 31 56 111 minecraft:air
execute in minecraft:the_nether run fill -32 57 -32 31 57 111 minecraft:air
execute in minecraft:the_nether run fill -32 58 -32 31 58 111 minecraft:air
execute in minecraft:the_nether run fill -32 59 -32 31 59 111 minecraft:air
execute in minecraft:the_nether run fill -32 60 -32 31 60 111 minecraft:air
execute in minecraft:the_nether run fill -32 61 -32 31 61 111 minecraft:air
execute in minecraft:the_nether run fill -32 62 -32 31 62 111 minecraft:air
execute in minecraft:the_nether run fill -32 63 -32 31 63 111 minecraft:air
execute in minecraft:the_nether run fill -32 64 -32 31 64 111 minecraft:air
execute in minecraft:the_nether run fill -32 65 -32 31 65 111 minecraft:air
execute in minecraft:the_nether run fill -32 66 -32 31 66 111 minecraft:air
execute in minecraft:the_nether run fill -32 67 -32 31 67 111 minecraft:air
execute in minecraft:the_nether run fill -32 68 -32 31 68 111 minecraft:air
execute in minecraft:the_nether run fill -32 69 -32 31 69 111 minecraft:air
execute in minecraft:the_nether run fill -32 70 -32 31 70 111 minecraft:air
execute in minecraft:the_nether run fill -32 71 -32 31 71 111 minecraft:air
execute in minecraft:the_nether run fill -32 72 -32 31 72 111 minecraft:air
execute in minecraft:the_nether run fill -32 73 -32 31 73 111 minecraft:air
execute in minecraft:the_nether run fill -32 74 -32 31 74 111 minecraft:air
execute in minecraft:the_nether run fill -32 75 -32 31 75 111 minecraft:air
execute in minecraft:the_nether run fill -32 76 -32 31 76 111 minecraft:air
execute in minecraft:the_nether run fill -32 77 -32 31 77 111 minecraft:air
execute in minecraft:the_nether run fill -32 78 -32 31 78 111 minecraft:air
execute in minecraft:the_nether run fill -32 79 -32 31 79 111 minecraft:air
execute in minecraft:the_nether run fill -32 80 -32 31 80 111 minecraft:air
execute in minecraft:the_nether run fill -32 81 -32 31 81 111 minecraft:air
execute in minecraft:the_nether run fill -32 82 -32 31 82 111 minecraft:air
execute in minecraft:the_nether run fill -32 83 -32 31 83 111 minecraft:air
execute in minecraft:the_nether run fill -32 84 -32 31 84 111 minecraft:air
execute in minecraft:the_nether run fill -32 85 -32 31 85 111 minecraft:air
execute in minecraft:the_nether run fill -32 86 -32 31 86 111 minecraft:air
execute in minecraft:the_nether run fill -32 87 -32 31 87 111 minecraft:air
execute in minecraft:the_nether run fill -32 88 -32 31 88 111 minecraft:air
execute in minecraft:the_nether run fill -32 89 -32 31 89 111 minecraft:air
execute in minecraft:the_nether run fill -32 90 -32 31 90 111 minecraft:air
execute in minecraft:the_nether run fill -32 91 -32 31 91 111 minecraft:air
execute in minecraft:the_nether run fill -32 92 -32 31 92 111 minecraft:air
execute in minecraft:the_nether run fill -32 93 -32 31 93 111 minecraft:air
execute in minecraft:the_nether run fill -32 94 -32 31 94 111 minecraft:air
execute in minecraft:the_nether run fill -32 95 -32 31 95 111 minecraft:air
execute in minecraft:the_nether run fill -32 96 -32 31 96 111 minecraft:air
execute in minecraft:the_nether run fill -32 97 -32 31 97 111 minecraft:air
execute in minecraft:the_nether run fill -32 98 -32 31 98 111 minecraft:air
execute in minecraft:the_nether run fill -32 99 -32 31 99 111 minecraft:air
execute in minecraft:the_nether run fill -32 100 -32 31 100 111 minecraft:air
execute in minecraft:the_nether run fill -32 101 -32 31 101 111 minecraft:air
execute in minecraft:the_nether run fill -32 102 -32 31 102 111 minecraft:air
execute in minecraft:the_nether run fill -32 103 -32 31 103 111 minecraft:air
execute in minecraft:the_nether run fill -32 104 -32 31 104 111 minecraft:air
execute in minecraft:the_nether run fill -32 105 -32 31 105 111 minecraft:air
execute in minecraft:the_nether run fill -32 106 -32 31 106 111 minecraft:air
execute in minecraft:the_nether run fill -32 107 -32 31 107 111 minecraft:air
execute in minecraft:the_nether run fill -32 108 -32 31 108 111 minecraft:air
execute in minecraft:the_nether run fill -32 109 -32 31 109 111 minecraft:air
execute in minecraft:the_nether run fill -32 110 -32 31 110 111 minecraft:air
execute in minecraft:the_nether run fill -32 111 -32 31 111 111 minecraft:air
execute in minecraft:the_nether run fill -32 112 -32 31 112 111 minecraft:air
execute in minecraft:the_nether run fill -32 113 -32 31 113 111 minecraft:air
execute in minecraft:the_nether run fill -32 114 -32 31 114 111 minecraft:air
execute in minecraft:the_nether run fill -32 115 -32 31 115 111 minecraft:air
execute in minecraft:the_nether run fill -32 116 -32 31 116 111 minecraft:air
execute in minecraft:the_nether run fill -32 117 -32 31 117 111 minecraft:air
execute in minecraft:the_nether run fill -32 118 -32 31 118 111 minecraft:air
execute in minecraft:the_nether run fill -32 119 -32 31 119 111 minecraft:air
execute in minecraft:the_nether run fill -32 120 -32 31 120 111 minecraft:air
execute in minecraft:the_nether run fill -32 121 -32 31 121 111 minecraft:air
execute in minecraft:the_nether run fill -32 122 -32 31 122 111 minecraft:air
execute in minecraft:the_nether run fill -32 123 -32 31 123 111 minecraft:air
execute in minecraft:the_nether run fill -32 124 -32 31 124 111 minecraft:air
execute in minecraft:the_nether run fill -32 125 -32 31 125 111 minecraft:air
execute in minecraft:the_nether run fill -32 126 -32 31 126 111 minecraft:air
execute in minecraft:the_nether run fill -32 127 -32 31 127 111 minecraft:air
execute in minecraft:the_nether run fill -32 128 -32 31 128 111 minecraft:air
execute in minecraft:the_nether run fill -32 129 -32 31 129 111 minecraft:air
execute in minecraft:the_nether run fill -32 130 -32 31 130 111 minecraft:air
execute in minecraft:the_nether run fill -32 131 -32 31 131 111 minecraft:air
execute in minecraft:the_nether run fill -32 132 -32 31 132 111 minecraft:air
execute in minecraft:the_nether run fill -32 133 -32 31 133 111 minecraft:air
execute in minecraft:the_nether run fill -32 134 -32 31 134 111 minecraft:air
execute in minecraft:the_nether run fill -32 135 -32 31 135 111 minecraft:air
execute in minecraft:the_nether run fill -32 136 -32 31 136 111 minecraft:air
execute in minecraft:the_nether run fill -32 137 -32 31 137 111 minecraft:air
execute in minecraft:the_nether run fill -32 138 -32 31 138 111 minecraft:air
execute in minecraft:the_nether run fill -32 139 -32 31 139 111 minecraft:air
execute in minecraft:the_nether run fill -32 140 -32 31 140 111 minecraft:air
execute in minecraft:the_nether run fill -32 141 -32 31 141 111 minecraft:air
execute in minecraft:the_nether run fill -32 142 -32 31 142 111 minecraft:air
execute in minecraft:the_nether run fill -32 143 -32 31 143 111 minecraft:air
execute in minecraft:the_nether run fill -32 144 -32 31 144 111 minecraft:air
execute in minecraft:the_nether run fill -32 145 -32 31 145 111 minecraft:air
execute in minecraft:the_nether run fill -32 146 -32 31 146 111 minecraft:air
execute in minecraft:the_nether run fill -32 147 -32 31 147 111 minecraft:air
execute in minecraft:the_nether run fill -32 148 -32 31 148 111 minecraft:air
execute in minecraft:the_nether run fill -32 149 -32 31 149 111 minecraft:air
execute in minecraft:the_nether run fill -32 150 -32 31 150 111 minecraft:air
execute in minecraft:the_nether run fill -32 151 -32 31 151 111 minecraft:air
execute in minecraft:the_nether run fill -32 152 -32 31 152 111 minecraft:air
execute in minecraft:the_nether run fill -32 153 -32 31 153 111 minecraft:air
execute in minecraft:the_nether run fill -32 154 -32 31 154 111 minecraft:air
execute in minecraft:the_nether run fill -32 155 -32 31 155 111 minecraft:air
execute in minecraft:the_nether run fill -32 156 -32 31 156 111 minecraft:air
execute in minecraft:the_nether run fill -32 157 -32 31 157 111 minecraft:air
execute in minecraft:the_nether run fill -32 158 -32 31 158 111 minecraft:air
execute in minecraft:the_nether run fill -32 159 -32 31 159 111 minecraft:air
execute in minecraft:the_nether run fill -32 160 -32 31 160 111 minecraft:air
scoreboard players set #n_gebaut nw.status 0
scoreboard players set #n_fertig nw.status 0
forceload remove -48 -48 47 127
scoreboard players reset * nw.tode
scoreboard players reset * nw.schlaf
function nachtwache:admin/neustart
scoreboard players set #pause nw.status 1
tellraw @a [{"text":"[Nightwatch] Fresh start. Day 1, tier 1, empty pockets. The Nether starts over too, the End is untouched.","color":"yellow"}]
tellraw @a [{"text":"[Nightwatch] The clock stands still. ","color":"yellow"},{"text":"Get ready, then start the watch with ","color":"gray"},{"text":"/trigger start","color":"yellow"},{"text":" (console: ","color":"gray"},{"text":"function nachtwache:start","color":"yellow"},{"text":").","color":"gray"}]
execute unless entity @s run say [Nightwatch] Fresh start, the clock stands still. Begin with: function nachtwache:start
