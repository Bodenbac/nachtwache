scoreboard players operation #reset_frist nw.status = #tick nw.tick
scoreboard players add #reset_frist nw.status 1200
tellraw @a [{"text":"[Nightwatch] FULL RESET requested: every block in the play area, all inventories, coins, night, tier. ","color":"red"},{"text":"Type ","color":"gray"},{"text":"/trigger yes","color":"yellow"},{"text":" within 60 seconds to confirm.","color":"gray"}]
