scoreboard players operation #reset_frist nw.status = #tick nw.tick
scoreboard players add #reset_frist nw.status 1200
tellraw @a [{"text":"[Nightwatch] FULL RESET requested: every block in the play area, all inventories, coins, night, tier. ","color":"red"},{"text":"Confirm within 60 seconds: ","color":"gray"},{"text":"/trigger yes","color":"yellow"},{"text":" in game, ","color":"gray"},{"text":"function nachtwache:yes","color":"yellow"},{"text":" in the server console.","color":"gray"}]
execute unless entity @s run say [Nightwatch] FULL RESET requested. Confirm within 60 seconds: function nachtwache:yes
