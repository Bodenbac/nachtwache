scoreboard players set @s endnight 0
scoreboard players enable @s endnight
kill @e[tag=nw.welle]
function nachtwache:gegner/vergessen
scoreboard players set #gegner nw.gegner 0
scoreboard players set #boss nw.boss 0
bossbar set nw:boss visible false
scoreboard players set #zeit nw.zeit 23500
scoreboard players set #stumm nw.status 1
execute if score #status nw.status matches 1 run function nachtwache:nacht/ende
scoreboard players set #stumm nw.status 0
tellraw @a [{"text":"[Nightwatch] Night ended by an admin.","color":"yellow"}]
