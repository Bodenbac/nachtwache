scoreboard players set @s reset 0
scoreboard players enable @s reset
function nachtwache:admin/reset
