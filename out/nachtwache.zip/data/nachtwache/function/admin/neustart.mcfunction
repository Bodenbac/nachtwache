kill @e[tag=nw.welle]
kill @e[tag=nw.villager]
kill @e[tag=nw.sammler]
function nachtwache:strasse/entfernen
scoreboard players set #init nw.status 0
bossbar set nw:welle visible false
bossbar set nw:boss visible false
function nachtwache:init
tellraw @a [{"text":"[Nightwatch] Restart. All values reset, islands rebuilt (your own builds stay).","color":"yellow"}]
