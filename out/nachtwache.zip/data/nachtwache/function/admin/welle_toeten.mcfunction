execute as @e[type=minecraft:magma_cube,tag=nw.welle] run data merge entity @s {Size:0}
kill @e[tag=nw.welle]
function nachtwache:gegner/vergessen
tellraw @a [{"text":"[Nightwatch] Wave removed.","color":"yellow"}]
