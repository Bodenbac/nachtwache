kill @e[tag=nw.welle]
tellraw @a [{"text":"[Nightwatch] Wave removed.","color":"yellow"}]
