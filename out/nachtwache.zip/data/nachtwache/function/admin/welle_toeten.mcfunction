kill @e[tag=nw.welle]
function nachtwache:gegner/vergessen
tellraw @a [{"text":"[Nightwatch] Wave removed.","color":"yellow"}]
