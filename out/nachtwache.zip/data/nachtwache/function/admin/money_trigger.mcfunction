scoreboard players operation #n nw.tmp = @s money
scoreboard players set @s money 0
scoreboard players enable @s money
scoreboard players operation #konto nw.konto += #n nw.tmp
execute if score #konto nw.konto matches ..-1 run scoreboard players set #konto nw.konto 0
tellraw @a [{"text":"[Nightwatch] Account changed by ","color":"yellow"},{"score":{"name":"#n","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"yellow"},{"text":"●","color":"white"},{"text":" (admin).","color":"yellow"}]
