scoreboard players set #zeit nw.zeit 23450
tellraw @a [{"text":"[Nightwatch] Day is coming.","color":"yellow"}]
