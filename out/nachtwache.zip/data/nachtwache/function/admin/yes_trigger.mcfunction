scoreboard players set @s yes 0
scoreboard players enable @s yes
function nachtwache:admin/reset_ja
