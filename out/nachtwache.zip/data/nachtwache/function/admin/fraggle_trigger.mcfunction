scoreboard players operation #zoff nw.status = @s fraggle
scoreboard players set @s fraggle 0
scoreboard players enable @s fraggle
execute if score #zoff nw.status matches 1 run scoreboard players set #zoff nw.status 0
execute as @e[type=marker,tag=nw.zwerg] at @s run function nachtwache:zwerg/zeichnen
tellraw @s [{"text":"[Nightwatch] Fraggle turned by ","color":"yellow"},{"score":{"name":"#zoff","objective":"nw.status"},"color":"yellow"},{"text":" degrees (all dwarves redrawn).","color":"yellow"}]
