scoreboard players operation #zoff nw.status = @s fraggle
scoreboard players set @s fraggle 0
scoreboard players enable @s fraggle
execute if score #zoff nw.status matches 1 run scoreboard players set #zoff nw.status 0
scoreboard players set #zoff nw.status 0
execute as @e[type=marker,tag=nw.zwerg] at @s run function nachtwache:zwerg/migrieren
function nachtwache:zwerg/altlast
execute if block 2 64 2 minecraft:chest run setblock 2 64 2 minecraft:air destroy
fill -1 64 4 1 64 6 minecraft:air replace minecraft:cobblestone_wall
fill -1 65 4 1 65 6 minecraft:air replace minecraft:oak_fence
setblock 0 66 5 minecraft:air
fill -1 63 4 1 63 6 minecraft:grass_block replace minecraft:cobblestone
fill -1 63 4 1 63 6 minecraft:grass_block replace minecraft:water
tellraw @s [{"text":"[Nightwatch] Fraggle turned by ","color":"yellow"},{"score":{"name":"#zoff","objective":"nw.status"},"color":"yellow"},{"text":" degrees (all dwarves redrawn).","color":"yellow"}]
