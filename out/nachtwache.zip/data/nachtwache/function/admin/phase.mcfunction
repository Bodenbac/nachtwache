$function nachtwache:quell/phase_wechsel {phase:$(p)}
execute if score #phase nw.phase matches 2 if score #abbau nw.abbau matches ..499 run scoreboard players set #abbau nw.abbau 500
execute if score #phase nw.phase matches 3 if score #abbau nw.abbau matches ..1299 run scoreboard players set #abbau nw.abbau 1300
execute if score #phase nw.phase matches 4 if score #abbau nw.abbau matches ..2499 run scoreboard players set #abbau nw.abbau 2500
execute if score #phase nw.phase matches 5 if score #abbau nw.abbau matches ..4199 run scoreboard players set #abbau nw.abbau 4200
execute if score #phase nw.phase matches 6 if score #abbau nw.abbau matches ..6499 run scoreboard players set #abbau nw.abbau 6500
execute if score #phase nw.phase matches 7 if score #abbau nw.abbau matches ..9499 run scoreboard players set #abbau nw.abbau 9500
function nachtwache:anzeige/aktualisieren
