$function nachtwache:quell/phase_wechsel {phase:$(p)}
execute if score #phase nw.phase matches 2 if score #abbau nw.abbau matches ..499 run scoreboard players set #abbau nw.abbau 500
execute if score #phase nw.phase matches 3 if score #abbau nw.abbau matches ..1249 run scoreboard players set #abbau nw.abbau 1250
execute if score #phase nw.phase matches 4 if score #abbau nw.abbau matches ..2249 run scoreboard players set #abbau nw.abbau 2250
execute if score #phase nw.phase matches 5 if score #abbau nw.abbau matches ..3499 run scoreboard players set #abbau nw.abbau 3500
execute if score #phase nw.phase matches 6 if score #abbau nw.abbau matches ..4999 run scoreboard players set #abbau nw.abbau 5000
execute if score #phase nw.phase matches 7 if score #abbau nw.abbau matches ..6749 run scoreboard players set #abbau nw.abbau 6750
function nachtwache:anzeige/aktualisieren
