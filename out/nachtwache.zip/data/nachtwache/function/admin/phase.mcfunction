$function nachtwache:quell/phase_wechsel {phase:$(p)}
