$function nachtwache:quell/phase_wechsel {phase:$(p)}
execute if score #phase nw.phase matches 2 if score #abbau nw.abbau matches ..499 run scoreboard players set #abbau nw.abbau 500
execute if score #phase nw.phase matches 3 if score #abbau nw.abbau matches ..1499 run scoreboard players set #abbau nw.abbau 1500
execute if score #phase nw.phase matches 4 if score #abbau nw.abbau matches ..2999 run scoreboard players set #abbau nw.abbau 3000
execute if score #phase nw.phase matches 5 if score #abbau nw.abbau matches ..4999 run scoreboard players set #abbau nw.abbau 5000
execute if score #phase nw.phase matches 6 if score #abbau nw.abbau matches ..7999 run scoreboard players set #abbau nw.abbau 8000
execute if score #phase nw.phase matches 7 if score #abbau nw.abbau matches ..11999 run scoreboard players set #abbau nw.abbau 12000
function nachtwache:anzeige/aktualisieren
