scoreboard players set #zeit nw.zeit 12950
tellraw @a [{"text":"[Nightwatch] Night is coming.","color":"yellow"}]
