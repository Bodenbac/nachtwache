$scoreboard players add #konto nw.konto $(n)
tellraw @a [{"text":"[Nightwatch] Coins credited.","color":"yellow"}]
