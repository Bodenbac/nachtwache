execute store result score #r nw.tmp2 run random value 1..45
execute if score #r nw.tmp2 matches 1 as @a at @s run playsound minecraft:ambient.cave ambient @s ~ ~ ~ 1 0.5
execute if score #r nw.tmp2 matches 2 if score #nacht nw.nacht matches 8.. as @a at @s run playsound minecraft:entity.warden.heartbeat hostile @s ~ ~ ~ 0.7 0.6
execute if score #r nw.tmp2 matches 3 if score #nacht nw.nacht matches 16.. as @a at @s run playsound minecraft:entity.warden.nearby_closer hostile @s ~ ~ ~ 0.5 0.7
execute if score #r nw.tmp2 matches 4 if score #status nw.status matches 1 as @a at @s run playsound minecraft:ambient.basalt_deltas.mood ambient @s ~ ~ ~ 1 0.5
execute if score #r nw.tmp2 matches 5 if score #nacht nw.nacht matches 20.. as @a at @s run effect give @s minecraft:darkness 2 0 true
