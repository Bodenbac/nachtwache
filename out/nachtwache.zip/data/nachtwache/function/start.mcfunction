function nachtwache:admin/start
