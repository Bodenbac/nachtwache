fill 0 63 -7 0 63 -7 minecraft:grass_block
fill -3 63 -6 3 63 -6 minecraft:grass_block
fill -4 63 -5 4 63 -5 minecraft:grass_block
fill -5 63 -4 5 63 -4 minecraft:grass_block
fill -6 63 -3 6 63 -3 minecraft:grass_block
fill -6 63 -2 6 63 -2 minecraft:grass_block
fill -6 63 -1 6 63 -1 minecraft:grass_block
fill -7 63 0 7 63 0 minecraft:grass_block
fill -6 63 1 6 63 1 minecraft:grass_block
fill -6 63 2 6 63 2 minecraft:grass_block
fill -6 63 3 6 63 3 minecraft:grass_block
fill -5 63 4 5 63 4 minecraft:grass_block
fill -4 63 5 4 63 5 minecraft:grass_block
fill -3 63 6 3 63 6 minecraft:grass_block
fill 0 63 7 0 63 7 minecraft:grass_block
fill 0 60 -7 0 62 -7 minecraft:dirt
fill -3 60 -6 3 62 -6 minecraft:dirt
fill -4 60 -5 4 62 -5 minecraft:dirt
fill -5 60 -4 5 62 -4 minecraft:dirt
fill -6 60 -3 6 62 -3 minecraft:dirt
fill -6 60 -2 6 62 -2 minecraft:dirt
fill -6 60 -1 6 62 -1 minecraft:dirt
fill -7 60 0 7 62 0 minecraft:dirt
fill -6 60 1 6 62 1 minecraft:dirt
fill -6 60 2 6 62 2 minecraft:dirt
fill -6 60 3 6 62 3 minecraft:dirt
fill -5 60 4 5 62 4 minecraft:dirt
fill -4 60 5 4 62 5 minecraft:dirt
fill -3 60 6 3 62 6 minecraft:dirt
fill 0 60 7 0 62 7 minecraft:dirt
fill 0 57 -6 0 59 -6 minecraft:deepslate
fill -3 57 -5 3 59 -5 minecraft:deepslate
fill -4 57 -4 4 59 -4 minecraft:deepslate
fill -5 57 -3 5 59 -3 minecraft:deepslate
fill -5 57 -2 5 59 -2 minecraft:deepslate
fill -5 57 -1 5 59 -1 minecraft:deepslate
fill -6 57 0 6 59 0 minecraft:deepslate
fill -5 57 1 5 59 1 minecraft:deepslate
fill -5 57 2 5 59 2 minecraft:deepslate
fill -5 57 3 5 59 3 minecraft:deepslate
fill -4 57 4 4 59 4 minecraft:deepslate
fill -3 57 5 3 59 5 minecraft:deepslate
fill 0 57 6 0 59 6 minecraft:deepslate
fill 0 55 -4 0 56 -4 minecraft:deepslate
fill -2 55 -3 2 56 -3 minecraft:deepslate
fill -3 55 -2 3 56 -2 minecraft:deepslate
fill -3 55 -1 3 56 -1 minecraft:deepslate
fill -4 55 0 4 56 0 minecraft:deepslate
fill -3 55 1 3 56 1 minecraft:deepslate
fill -3 55 2 3 56 2 minecraft:deepslate
fill -2 55 3 2 56 3 minecraft:deepslate
fill 0 55 4 0 56 4 minecraft:deepslate
fill 0 54 -2 0 54 -2 minecraft:deepslate
fill -1 54 -1 1 54 -1 minecraft:deepslate
fill -2 54 0 2 54 0 minecraft:deepslate
fill -1 54 1 1 54 1 minecraft:deepslate
fill 0 54 2 0 54 2 minecraft:deepslate
fill -1 63 6 1 63 8 minecraft:polished_deepslate
fill -1 64 6 1 65 8 minecraft:air
fill -4 64 -1 -4 68 -1 minecraft:stripped_dark_oak_log
setblock -4 69 -1 minecraft:stripped_dark_oak_log
setblock -5 68 -1 minecraft:stripped_dark_oak_log[axis=x]
setblock -3 67 -1 minecraft:stripped_dark_oak_log[axis=x]
setblock -3 67 0 minecraft:stripped_dark_oak_log[axis=z]
setblock -4 70 -1 minecraft:dark_oak_leaves[persistent=true]
fill -1 63 4 1 63 6 minecraft:cobblestone
setblock 0 63 5 minecraft:water
fill -1 64 4 1 64 6 minecraft:cobblestone_wall
setblock 0 64 5 minecraft:air
setblock 0 66 5 minecraft:oak_slab
setblock -1 65 4 minecraft:oak_fence
setblock 1 65 6 minecraft:oak_fence
setblock 5 64 3 minecraft:soul_lantern
setblock -5 64 4 minecraft:soul_lantern
setblock 3 64 -6 minecraft:air
setblock 2 64 2 minecraft:chest[facing=west]{Items:[{Slot:0b,id:"minecraft:water_bucket",count:1},{Slot:1b,id:"minecraft:lava_bucket",count:1},{Slot:2b,id:"minecraft:oak_sapling",count:1},{Slot:3b,id:"minecraft:bone_meal",count:4},{Slot:4b,id:"minecraft:bread",count:4},{Slot:5b,id:"minecraft:torch",count:8},{Slot:6b,id:"minecraft:wooden_pickaxe",count:1}]}
