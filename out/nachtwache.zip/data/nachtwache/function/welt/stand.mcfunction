fill -8 63 -12 -4 63 -10 minecraft:polished_deepslate
fill -8 64 -12 -4 65 -12 minecraft:deepslate_bricks
fill -8 64 -11 -8 65 -10 minecraft:deepslate_bricks
fill -4 64 -11 -4 65 -10 minecraft:deepslate_bricks
fill -7 64 -11 -5 65 -11 minecraft:air
fill -7 65 -10 -5 65 -10 minecraft:air
fill -8 66 -12 -4 66 -10 minecraft:crimson_slab[type=bottom]
execute unless block -8 67 -10 minecraft:soul_lantern run setblock -8 67 -10 minecraft:soul_lantern
execute unless block -4 67 -10 minecraft:soul_lantern run setblock -4 67 -10 minecraft:soul_lantern
execute unless block -8 65 -9 minecraft:crimson_wall_sign run setblock -8 65 -9 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:["",{text:"THE",color:"dark_red"},{text:"COLLECTOR",color:"dark_red"},""]}}
function nachtwache:sammler/tresen
kill @e[type=item,x=-8,y=62,z=-12,dx=5,dy=6,dz=4,nbt={Item:{id:"minecraft:polished_deepslate"}}]
kill @e[type=item,x=-8,y=62,z=-12,dx=5,dy=6,dz=4,nbt={Item:{id:"minecraft:deepslate_bricks"}}]
kill @e[type=item,x=-8,y=62,z=-12,dx=5,dy=6,dz=4,nbt={Item:{id:"minecraft:crimson_slab"}}]
kill @e[type=item,x=-8,y=62,z=-12,dx=5,dy=6,dz=4,nbt={Item:{id:"minecraft:soul_lantern"}}]
kill @e[type=item,x=-8,y=62,z=-12,dx=5,dy=6,dz=4,nbt={Item:{id:"minecraft:crimson_wall_sign"}}]
kill @e[type=item,x=-8,y=62,z=-12,dx=5,dy=6,dz=4,nbt={Item:{id:"minecraft:chest"}}]
kill @e[type=item,x=-8,y=62,z=-12,dx=5,dy=6,dz=4,nbt={Item:{id:"minecraft:barrel"}}]
