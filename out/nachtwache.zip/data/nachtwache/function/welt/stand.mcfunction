fill -2 63 -8 2 63 -4 minecraft:polished_deepslate
fill -2 64 -8 2 66 -8 minecraft:deepslate_bricks
fill -2 64 -7 -2 66 -5 minecraft:deepslate_bricks
fill 2 64 -7 2 66 -5 minecraft:deepslate_bricks
fill -1 64 -7 1 66 -6 minecraft:air
fill -1 65 -5 1 66 -5 minecraft:air
fill -2 67 -8 2 67 -4 minecraft:crimson_slab[type=bottom]
fill -1 67 -4 1 67 -4 minecraft:crimson_stairs[facing=south,half=top]
setblock -2 67 -4 minecraft:crimson_planks
setblock 2 67 -4 minecraft:crimson_planks
setblock -2 66 -4 minecraft:soul_lantern[hanging=true]
setblock 2 66 -4 minecraft:soul_lantern[hanging=true]
setblock -1 66 -8 minecraft:redstone_torch[lit=true]
setblock 1 66 -8 minecraft:redstone_torch[lit=true]
setblock 0 66 -7 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:["",{text:"THE",color:"dark_red"},{text:"COLLECTOR",color:"dark_red"},""]}}
setblock 0 64 -8 minecraft:barrel[facing=up]
setblock -1 64 -7 minecraft:candle[candles=3,lit=true]
setblock 3 65 -6 minecraft:air
setblock 4 64 -6 minecraft:crimson_planks
setblock 4 65 -6 minecraft:soul_lantern
setblock 4 64 -5 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:["",{text:"Drop-off",color:"dark_red"},{text:"sells at 80%",color:"gray"},""]}}
execute unless block 3 64 -6 minecraft:hopper run setblock 3 64 -6 minecraft:hopper[facing=down]
setblock 3 63 -6 minecraft:deepslate_bricks
