fill -12 64 60 12 75 84 minecraft:air
fill 0 63 61 0 63 61 minecraft:blackstone
fill -4 63 62 4 63 62 minecraft:blackstone
fill -6 63 63 6 63 63 minecraft:blackstone
fill -7 63 64 7 63 64 minecraft:blackstone
fill -8 63 65 8 63 65 minecraft:blackstone
fill -9 63 66 9 63 66 minecraft:blackstone
fill -9 63 67 9 63 67 minecraft:blackstone
fill -10 63 68 10 63 68 minecraft:blackstone
fill -10 63 69 10 63 69 minecraft:blackstone
fill -10 63 70 10 63 70 minecraft:blackstone
fill -10 63 71 10 63 71 minecraft:blackstone
fill -11 63 72 11 63 72 minecraft:blackstone
fill -10 63 73 10 63 73 minecraft:blackstone
fill -10 63 74 10 63 74 minecraft:blackstone
fill -10 63 75 10 63 75 minecraft:blackstone
fill -10 63 76 10 63 76 minecraft:blackstone
fill -9 63 77 9 63 77 minecraft:blackstone
fill -9 63 78 9 63 78 minecraft:blackstone
fill -8 63 79 8 63 79 minecraft:blackstone
fill -7 63 80 7 63 80 minecraft:blackstone
fill -6 63 81 6 63 81 minecraft:blackstone
fill -4 63 82 4 63 82 minecraft:blackstone
fill 0 63 83 0 63 83 minecraft:blackstone
fill 0 60 61 0 62 61 minecraft:deepslate
fill -4 60 62 4 62 62 minecraft:deepslate
fill -6 60 63 6 62 63 minecraft:deepslate
fill -7 60 64 7 62 64 minecraft:deepslate
fill -8 60 65 8 62 65 minecraft:deepslate
fill -9 60 66 9 62 66 minecraft:deepslate
fill -9 60 67 9 62 67 minecraft:deepslate
fill -10 60 68 10 62 68 minecraft:deepslate
fill -10 60 69 10 62 69 minecraft:deepslate
fill -10 60 70 10 62 70 minecraft:deepslate
fill -10 60 71 10 62 71 minecraft:deepslate
fill -11 60 72 11 62 72 minecraft:deepslate
fill -10 60 73 10 62 73 minecraft:deepslate
fill -10 60 74 10 62 74 minecraft:deepslate
fill -10 60 75 10 62 75 minecraft:deepslate
fill -10 60 76 10 62 76 minecraft:deepslate
fill -9 60 77 9 62 77 minecraft:deepslate
fill -9 60 78 9 62 78 minecraft:deepslate
fill -8 60 79 8 62 79 minecraft:deepslate
fill -7 60 80 7 62 80 minecraft:deepslate
fill -6 60 81 6 62 81 minecraft:deepslate
fill -4 60 82 4 62 82 minecraft:deepslate
fill 0 60 83 0 62 83 minecraft:deepslate
fill 0 57 63 0 59 63 minecraft:deepslate
fill -4 57 64 4 59 64 minecraft:deepslate
fill -5 57 65 5 59 65 minecraft:deepslate
fill -6 57 66 6 59 66 minecraft:deepslate
fill -7 57 67 7 59 67 minecraft:deepslate
fill -8 57 68 8 59 68 minecraft:deepslate
fill -8 57 69 8 59 69 minecraft:deepslate
fill -8 57 70 8 59 70 minecraft:deepslate
fill -8 57 71 8 59 71 minecraft:deepslate
fill -9 57 72 9 59 72 minecraft:deepslate
fill -8 57 73 8 59 73 minecraft:deepslate
fill -8 57 74 8 59 74 minecraft:deepslate
fill -8 57 75 8 59 75 minecraft:deepslate
fill -8 57 76 8 59 76 minecraft:deepslate
fill -7 57 77 7 59 77 minecraft:deepslate
fill -6 57 78 6 59 78 minecraft:deepslate
fill -5 57 79 5 59 79 minecraft:deepslate
fill -4 57 80 4 59 80 minecraft:deepslate
fill 0 57 81 0 59 81 minecraft:deepslate
fill 0 55 66 0 56 66 minecraft:deepslate
fill -3 55 67 3 56 67 minecraft:deepslate
fill -4 55 68 4 56 68 minecraft:deepslate
fill -5 55 69 5 56 69 minecraft:deepslate
fill -5 55 70 5 56 70 minecraft:deepslate
fill -5 55 71 5 56 71 minecraft:deepslate
fill -6 55 72 6 56 72 minecraft:deepslate
fill -5 55 73 5 56 73 minecraft:deepslate
fill -5 55 74 5 56 74 minecraft:deepslate
fill -5 55 75 5 56 75 minecraft:deepslate
fill -4 55 76 4 56 76 minecraft:deepslate
fill -3 55 77 3 56 77 minecraft:deepslate
fill 0 55 78 0 56 78 minecraft:deepslate
fill 0 63 69 0 63 69 minecraft:soul_soil
fill -2 63 70 2 63 70 minecraft:soul_soil
fill -2 63 71 2 63 71 minecraft:soul_soil
fill -3 63 72 3 63 72 minecraft:soul_soil
fill -2 63 73 2 63 73 minecraft:soul_soil
fill -2 63 74 2 63 74 minecraft:soul_soil
fill 0 63 75 0 63 75 minecraft:soul_soil
setblock 0 64 72 minecraft:soul_fire
setblock 4 63 75 minecraft:soul_soil
setblock 4 64 75 minecraft:soul_fire
setblock -5 63 70 minecraft:soul_soil
setblock -5 64 70 minecraft:soul_fire
fill -3 63 77 -1 63 79 minecraft:netherrack
fill 5 63 66 7 63 68 minecraft:netherrack
fill -7 63 73 -5 63 75 minecraft:soul_sand
fill 6 64 77 6 68 77 minecraft:crimson_stem
setblock 7 67 77 minecraft:crimson_stem[axis=x]
fill -7 64 67 -7 67 67 minecraft:crimson_stem
setblock -7 66 66 minecraft:crimson_stem[axis=z]
fill 0 64 81 0 66 81 minecraft:crimson_stem
setblock 3 64 64 minecraft:shroomlight
setblock -3 64 64 minecraft:shroomlight
setblock 8 64 72 minecraft:crying_obsidian
setblock -8 64 72 minecraft:crying_obsidian
setblock 0 64 82 minecraft:crying_obsidian
fill -1 63 60 1 63 62 minecraft:blackstone
fill -1 64 61 1 64 61 minecraft:air
setblock -2 64 61 minecraft:crying_obsidian
setblock 2 64 61 minecraft:crying_obsidian
setblock -2 65 61 minecraft:shroomlight
setblock 2 65 61 minecraft:shroomlight
