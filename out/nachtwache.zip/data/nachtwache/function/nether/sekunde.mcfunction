execute unless score #n_gebaut nw.status matches 1 in minecraft:the_nether run function nachtwache:nether/aufbauen
execute if score #welt nw.status matches 1 in minecraft:the_nether run function nachtwache:nether/pflege
execute as @e[type=#nachtwache:feuerball] at @s unless entity @a[distance=..72] run kill @s
execute if score #welt nw.status matches 1 as @a at @s if dimension minecraft:overworld in minecraft:the_nether run tp @s 0.5 64 -9.5
execute unless score #welt nw.status matches 1 as @a at @s if dimension minecraft:the_nether in minecraft:overworld run tp @s 0.5 64 -10.5
