tag @s add nw.leine
data merge entity @s {NoAI:1b}
