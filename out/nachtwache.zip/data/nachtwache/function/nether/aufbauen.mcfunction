forceload add -20 -20 20 100
execute unless score #n_gebaut nw.status matches 1 run function nachtwache:nether/insel_neu
