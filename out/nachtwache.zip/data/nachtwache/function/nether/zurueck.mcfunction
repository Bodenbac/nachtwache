function nachtwache:nether/tausch
scoreboard players set #welt nw.status 0
execute in minecraft:overworld run tp @a 0.5 64 -10.5
execute in minecraft:overworld run function nachtwache:sammler/kaufmenue
execute in minecraft:overworld run function nachtwache:sammler2/kaufmenue
title @a times 10 40 20
title @a title [{"text":"BACK ABOVE","color":"gold","bold":true}]
title @a subtitle [{"text":"The day up here waited for you.","color":"gray"}]
playsound minecraft:block.portal.travel master @a ~ ~ ~ 0.4 1.2
