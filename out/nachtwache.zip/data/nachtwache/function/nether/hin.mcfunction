function nachtwache:nether/tausch
scoreboard players set #welt nw.status 1
execute in minecraft:the_nether run function nachtwache:nether/aufbauen
execute in minecraft:the_nether run tp @a 0.5 64 -9.5
title @a times 10 60 20
title @a title [{"text":"THE NETHER","color":"dark_red","bold":true}]
title @a subtitle [{"text":"Same watch, new island. No shop down here.","color":"gray"}]
tellraw @a [{"text":"[Nightwatch] ","color":"dark_red"},{"text":"The lives are shared with the world above. The generator here pays no coins, only crates with Eyes of Ender. Back through the portal, by day, all together.","color":"gray"}]
playsound minecraft:block.portal.travel master @a ~ ~ ~ 0.4 0.8
