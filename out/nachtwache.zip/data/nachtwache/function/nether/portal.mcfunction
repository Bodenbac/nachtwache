execute if score #ende nw.status matches 1 run return 0
execute store result score #pa nw.tmp2 if entity @a
scoreboard players set #pok nw.tmp2 1
execute unless score #pp nw.tmp2 = #pa nw.tmp2 run scoreboard players set #pok nw.tmp2 2
execute unless score #welt nw.status matches 1 unless score #phase nw.phase matches 4.. run scoreboard players set #pok nw.tmp2 3
execute if score #gegner nw.gegner matches 1.. run scoreboard players set #pok nw.tmp2 4
execute if score #status nw.status matches 1 run scoreboard players set #pok nw.tmp2 5
execute unless score #n_gebaut nw.status matches 1 run scoreboard players set #pok nw.tmp2 6
execute if score #pok nw.tmp2 matches 2 run title @a actionbar [{"text":"Everyone has to stand in the portal.","color":"light_purple"}]
execute if score #pok nw.tmp2 matches 3 run title @a actionbar [{"text":"The Source must reach tier 4 first.","color":"light_purple"}]
execute if score #pok nw.tmp2 matches 4 run title @a actionbar [{"text":"Not while something is alive.","color":"light_purple"}]
execute if score #pok nw.tmp2 matches 5 run title @a actionbar [{"text":"Not at night.","color":"light_purple"}]
execute if score #pok nw.tmp2 matches 6 run title @a actionbar [{"text":"The Nether is not ready yet. Try again in a moment.","color":"light_purple"}]
execute unless score #pok nw.tmp2 matches 1 run return run scoreboard players set #portalzeit nw.tmp2 0
scoreboard players add #portalzeit nw.tmp2 1
execute if score #portalzeit nw.tmp2 matches 1 run playsound minecraft:block.portal.trigger master @a ~ ~ ~ 0.5 1
execute unless score #portalzeit nw.tmp2 matches 40.. run return 0
execute if score #welt nw.status matches 1 run return run function nachtwache:nether/zurueck
function nachtwache:nether/hin
