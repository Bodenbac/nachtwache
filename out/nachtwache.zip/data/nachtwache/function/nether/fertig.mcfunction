scoreboard players set #n_fertig nw.status 1
title @a times 20 100 40
title @a title [{"text":"THE NETHER IS BROKEN","color":"gold","bold":true}]
title @a subtitle [{"text":"No more bosses down here. The nights go on.","color":"gray"}]
playsound minecraft:entity.ender_dragon.death master @a ~ ~ ~ 0.4 1.3
