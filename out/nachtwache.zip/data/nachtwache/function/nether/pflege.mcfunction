fill -7 63 -12 -7 63 -9 minecraft:obsidian
fill -7 67 -12 -7 67 -9 minecraft:obsidian
fill -7 64 -12 -7 66 -12 minecraft:obsidian
fill -7 64 -9 -7 66 -9 minecraft:obsidian
fill -7 64 -11 -7 66 -10 minecraft:nether_portal[axis=z] replace minecraft:air
kill @e[type=item,x=-9,y=62,z=-14,dx=4,dy=8,dz=7,nbt={Item:{id:"minecraft:obsidian"}}]
function nachtwache:beacon/aufbauen
