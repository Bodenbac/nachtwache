scoreboard players set #x_zeit nw.zeit 1000
scoreboard players set #x_nacht nw.nacht 0
scoreboard players set #x_phase nw.phase 1
scoreboard players set #x_abbau nw.abbau 0
scoreboard players set #x_modus nw.status 0
scoreboard players set #x_finale nw.status 0
scoreboard players set #n_fertig nw.status 0
