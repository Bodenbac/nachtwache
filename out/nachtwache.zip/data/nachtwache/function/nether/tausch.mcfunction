scoreboard players operation #tsch nw.tmp = #zeit nw.zeit
scoreboard players operation #zeit nw.zeit = #x_zeit nw.zeit
scoreboard players operation #x_zeit nw.zeit = #tsch nw.tmp
scoreboard players operation #tsch nw.tmp = #nacht nw.nacht
scoreboard players operation #nacht nw.nacht = #x_nacht nw.nacht
scoreboard players operation #x_nacht nw.nacht = #tsch nw.tmp
scoreboard players operation #tsch nw.tmp = #phase nw.phase
scoreboard players operation #phase nw.phase = #x_phase nw.phase
scoreboard players operation #x_phase nw.phase = #tsch nw.tmp
scoreboard players operation #tsch nw.tmp = #abbau nw.abbau
scoreboard players operation #abbau nw.abbau = #x_abbau nw.abbau
scoreboard players operation #x_abbau nw.abbau = #tsch nw.tmp
scoreboard players operation #tsch nw.tmp = #modus nw.status
scoreboard players operation #modus nw.status = #x_modus nw.status
scoreboard players operation #x_modus nw.status = #tsch nw.tmp
scoreboard players operation #tsch nw.tmp = #finale nw.status
scoreboard players operation #finale nw.status = #x_finale nw.status
scoreboard players operation #x_finale nw.status = #tsch nw.tmp
execute as @e[type=marker,tag=nw.gen] at @s run function nachtwache:gen/farbe
execute as @e[type=marker,tag=nw.gen] at @s run function nachtwache:gen/anzeige
execute store result storage nachtwache:tmp t int 1 run scoreboard players get #zeit nw.zeit
function nachtwache:uhr/setzen with storage nachtwache:tmp
scoreboard players set #uhr_akku nw.tmp2 0
scoreboard players set #portalzeit nw.tmp2 -100
