team join nw_gegner @s
execute store result score @s nw.py run data get entity @s Pos[1]
execute if entity @s[type=minecraft:ghast] if score @s nw.py matches ..72 at @s run tp @s ~ ~0.4 ~
execute if entity @s[tag=nw.boss_heuler] if score @s nw.py matches ..73 at @s run tp @s ~ ~0.4 ~
execute if score @s nw.py matches ..61 at @s run tp @s ~ ~0.6 ~
execute if entity @a[gamemode=!spectator,distance=..22] run return run function nachtwache:nether/leine_los
execute unless entity @p[gamemode=!spectator] run return 0
execute unless entity @s[tag=nw.leine] run function nachtwache:nether/leine_an
execute if score @s nw.py matches ..72 at @s run tp @s ~ ~0.4 ~
execute at @s facing entity @p[gamemode=!spectator] eyes rotated ~ 0 run tp @s ^ ^ ^0.3
