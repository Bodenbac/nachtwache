execute unless entity @s[tag=nw.leine] run return 0
tag @s remove nw.leine
data merge entity @s {NoAI:0b}
