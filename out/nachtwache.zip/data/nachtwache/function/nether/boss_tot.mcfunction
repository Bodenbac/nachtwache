execute if score #bossart nw.boss matches 104 run give @p minecraft:ender_eye 2
execute if score #bossart nw.boss matches 107 run give @p minecraft:ender_eye 3
execute if score #bossart nw.boss matches 110 run give @p minecraft:ender_eye 4
tellraw @a [{"text":"The boss is dead. ","color":"dark_purple"},{"text":"It was carrying Eyes of Ender.","color":"gray"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.8
execute if score #bossart nw.boss matches 110 run function nachtwache:nether/fertig
scoreboard players set #bossart nw.boss 0
