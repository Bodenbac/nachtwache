execute if score #welt nw.status matches 1 in minecraft:the_nether run tag @e[type=minecraft:magma_cube,tag=!nw.welle,distance=0..] add nw.a_magma
execute if score #welt nw.status matches 1 in minecraft:the_nether run tag @e[type=minecraft:magma_cube,tag=!nw.welle,distance=0..] add nw.welle
execute if score #m20 nw.tmp matches 7 run function nachtwache:nether/sekunde
execute if score #portalzeit nw.tmp2 matches ..-1 run return run scoreboard players add #portalzeit nw.tmp2 1
scoreboard players set #pp nw.tmp2 0
execute as @a at @s if block ~ ~ ~ minecraft:nether_portal run scoreboard players add #pp nw.tmp2 1
execute if score #pp nw.tmp2 matches 0 run return run scoreboard players set #portalzeit nw.tmp2 0
function nachtwache:nether/portal
