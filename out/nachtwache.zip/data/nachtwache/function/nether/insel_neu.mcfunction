execute unless loaded 0 64 0 run return 0
execute unless loaded 0 64 72 run return 0
function nachtwache:welt/startinsel
fill -10 54 -23 10 63 9 minecraft:crimson_nylium replace minecraft:grass_block
fill -10 54 -23 10 63 9 minecraft:netherrack replace minecraft:dirt
function nachtwache:welt/gegnerinsel
function nachtwache:strasse/entfernen
function nachtwache:quell/setzen
function nachtwache:nether/pflege
scoreboard players set #n_gebaut nw.status 1
