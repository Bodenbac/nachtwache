execute unless entity @p[gamemode=!spectator,gamemode=!creative,distance=..30] run return 0
scoreboard players set #sicht nw.tmp 30
execute store result score #frei nw.tmp2 positioned ~ ~1.4 ~ facing entity @p[gamemode=!spectator,gamemode=!creative] eyes run function nachtwache:gegner/sicht
execute unless score #frei nw.tmp2 matches 1 run return 0
scoreboard players set #spur nw.tmp 60
execute positioned ~ ~1.4 ~ facing entity @p[gamemode=!spectator,gamemode=!creative] eyes run function nachtwache:bogi/spur
execute as @p[gamemode=!spectator,gamemode=!creative,distance=..30] at @s run particle minecraft:flame ~ ~1 ~ 0.3 0.5 0.3 0.02 20
execute as @p[gamemode=!spectator,gamemode=!creative,distance=..30] run damage @s 5 minecraft:in_fire
playsound minecraft:entity.blaze.shoot hostile @a[distance=..40] ~ ~ ~ 1 0.7
