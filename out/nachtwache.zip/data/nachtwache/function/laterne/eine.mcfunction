execute unless block ~ ~ ~ minecraft:soul_lantern run return run kill @s
effect give @e[tag=nw.welle,distance=..8] minecraft:slowness 2 1 true
particle minecraft:soul ~ ~0.2 ~ 0.2 0.2 0.2 0.01 3
