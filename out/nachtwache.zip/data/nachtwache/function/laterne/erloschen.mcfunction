setblock ~ ~ ~ minecraft:air
execute if entity @s[x=-3,y=63,z=9,dx=6,dy=3,dz=50] run setblock ~ ~-1 ~ minecraft:air
particle minecraft:large_smoke ~ ~ ~ 0.2 0.2 0.2 0.02 15
playsound minecraft:block.fire.extinguish block @a ~ ~ ~ 1 0.8
tellraw @a [{"text":"A Collector Lantern has burned out.","color":"gray","italic":true}]
kill @s
