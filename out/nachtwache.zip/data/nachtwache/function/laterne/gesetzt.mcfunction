advancement revoke @s only nachtwache:laterne_gesetzt
scoreboard players set #strahl nw.tmp2 28
execute at @s anchored eyes positioned ^ ^ ^ run function nachtwache:laterne/strahl
