execute unless block ~ ~-1 ~ minecraft:crimson_planks run setblock ~ ~-1 ~ minecraft:crimson_planks
execute unless block ~ ~ ~ minecraft:soul_lantern run setblock ~ ~ ~ minecraft:soul_lantern
