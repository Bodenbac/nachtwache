execute as @e[type=marker,tag=nw.laterne] at @s run function nachtwache:laterne/eine
