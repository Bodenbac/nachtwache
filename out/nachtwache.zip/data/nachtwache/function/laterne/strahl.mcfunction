execute if block ~ ~ ~ minecraft:soul_lantern unless entity @e[type=marker,tag=nw.laterne,distance=..0.9] run return run function nachtwache:laterne/markieren
scoreboard players remove #strahl nw.tmp2 1
execute if score #strahl nw.tmp2 matches 1.. positioned ^ ^ ^0.25 run function nachtwache:laterne/strahl
