execute align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["nw.laterne"]}
execute align xyz positioned ~0.5 ~0.5 ~0.5 run scoreboard players set @e[type=marker,tag=nw.laterne,distance=..0.9] nw.laterne 0
execute align xyz positioned ~0.5 ~0.5 ~0.5 run particle minecraft:soul ~ ~ ~ 0.3 0.3 0.3 0.02 20
playsound minecraft:block.respawn_anchor.charge block @s ~ ~ ~ 1 0.7
tellraw @s [{"text":"The lantern burns. Enemies near it slow down. Three nights.","color":"aqua"}]
