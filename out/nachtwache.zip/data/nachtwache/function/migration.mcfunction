scoreboard players set #version nw.status 22
scoreboard players set #migrieren nw.status 0
kill @e[tag=nw.kasse]
fill -4 64 -6 -3 65 -5 minecraft:air
fill -1 64 -5 1 64 -5 minecraft:air
function nachtwache:welt/stand
function nachtwache:sammler/erscheinen
function nachtwache:strasse/entfernen
function nachtwache:welt/gegnerinsel
fill -1 63 6 1 63 8 minecraft:polished_deepslate
execute unless score #phase nw.phase matches 1.. run scoreboard players set #phase nw.phase 1
setblock 0 64 0 minecraft:air
function nachtwache:quell/setzen
function nachtwache:sammler/kaufmenue
clear @a minecraft:echo_shard[custom_data~{nw_splitter:1b}]
clear @a minecraft:prismarine_crystals[custom_data~{nw_buendel:1b}]
kill @e[type=item,x=-6,y=60,z=-10,dx=12,dy=10,dz=8]
tellraw @a [{"text":"[Nightwatch] Stall and Collector updated to the current version.","color":"yellow"}]
