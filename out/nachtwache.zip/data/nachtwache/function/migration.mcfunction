scoreboard players set #version nw.status 68
scoreboard players set #migrieren nw.status 0
kill @e[tag=nw.kasse]
fill -4 64 -6 -3 65 -5 minecraft:air
fill -1 64 -5 1 64 -5 minecraft:air
function nachtwache:welt/stand
function nachtwache:sammler/erscheinen
function nachtwache:strasse/entfernen
function nachtwache:welt/gegnerinsel
fill -1 63 6 1 63 8 minecraft:polished_deepslate
execute unless score #phase nw.phase matches 1.. run scoreboard players set #phase nw.phase 1
setblock 0 64 -7 minecraft:air
function nachtwache:quell/setzen
kill @e[type=item,x=-2,y=62,z=-2,dx=4,dy=4,dz=4,nbt={Item:{id:"minecraft:budding_amethyst"}}]
function nachtwache:sammler/kaufmenue
kill @e[tag=nw.herz_text]
function nachtwache:beacon/aufbauen
function nachtwache:beacon/anzeige
scoreboard players set #zoff nw.status 0
execute as @e[type=marker,tag=nw.zwerg] at @s run function nachtwache:zwerg/migrieren
function nachtwache:zwerg/altlast
execute if block 2 64 2 minecraft:chest run setblock 2 64 2 minecraft:air destroy
fill -1 64 4 1 64 6 minecraft:air replace minecraft:cobblestone_wall
fill -1 65 4 1 65 6 minecraft:air replace minecraft:oak_fence
setblock 0 66 5 minecraft:air
fill -1 63 4 1 63 6 minecraft:grass_block replace minecraft:cobblestone
fill -1 63 4 1 63 6 minecraft:grass_block replace minecraft:water
clear @a minecraft:echo_shard[custom_data~{nw_splitter:1b}]
clear @a minecraft:prismarine_crystals[custom_data~{nw_buendel:1b}]
kill @e[type=item,x=-6,y=60,z=-10,dx=12,dy=10,dz=8]
fill -3 64 -9 3 68 -3 minecraft:air
fill -3 63 -9 3 63 -3 minecraft:grass_block replace minecraft:polished_deepslate
fill -2 64 2 2 67 6 minecraft:air
fill -2 63 2 2 63 6 minecraft:grass_block replace minecraft:iron_block
fill -6 64 -3 -2 71 1 minecraft:air
setblock 5 64 3 minecraft:air
setblock -5 64 4 minecraft:air
kill @e[type=item,x=-8,y=60,z=-12,dx=16,dy=14,dz=20,nbt={Item:{id:"minecraft:iron_block"}}]
kill @e[type=item,x=-8,y=60,z=-12,dx=16,dy=14,dz=20,nbt={Item:{id:"minecraft:beacon"}}]
kill @e[type=item,x=-8,y=60,z=-12,dx=16,dy=14,dz=20,nbt={Item:{id:"minecraft:deepslate_bricks"}}]
kill @e[type=item,x=-8,y=60,z=-12,dx=16,dy=14,dz=20,nbt={Item:{id:"minecraft:hopper"}}]
kill @e[type=marker,tag=nw.gen,x=0,y=64,z=0,dx=0,dy=0,dz=0]
kill @e[type=marker,tag=nw.gen_neu,x=0,y=64,z=0,dx=0,dy=0,dz=0]
kill @e[type=block_display,tag=nw.gen_block,x=-1,y=63,z=-1,dx=2,dy=2,dz=2]
setblock 0 64 0 minecraft:air
function nachtwache:welt/startinsel
function nachtwache:welt/stand
function nachtwache:sammler/erscheinen
function nachtwache:sammler/kaufmenue
function nachtwache:beacon/aufbauen
kill @e[tag=nw.herz]
kill @e[tag=nw.herz_text]
kill @e[type=block_display,tag=nw.gen_block]
execute as @e[tag=nw.welle] run attribute @s minecraft:follow_range base set 128
spawnpoint @a 0 64 -10
setworldspawn 0 64 -10
tellraw @a [{"text":"[Nightwatch] The island has been rebuilt: longer, the beacon at the far end, the stall off to the side.","color":"yellow"}]
