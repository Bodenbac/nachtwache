scoreboard players operation #alt nw.status = #version nw.status
scoreboard players set #version nw.status 84
scoreboard players set #migrieren nw.status 0
execute if score #alt nw.status matches ..74 run kill @e[tag=nw.kasse]
execute if score #alt nw.status matches ..74 run fill -4 64 -6 -3 65 -5 minecraft:air
execute if score #alt nw.status matches ..74 run fill -1 64 -5 1 64 -5 minecraft:air
function nachtwache:welt/stand
function nachtwache:sammler/erscheinen
function nachtwache:strasse/entfernen
function nachtwache:welt/gegnerinsel
execute if score #alt nw.status matches ..74 run fill -1 63 6 1 63 8 minecraft:polished_deepslate
execute unless score #phase nw.phase matches 1.. run scoreboard players set #phase nw.phase 1
execute if score #alt nw.status matches ..74 run setblock 0 64 -7 minecraft:air
function nachtwache:quell/setzen
execute if score #alt nw.status matches ..74 run kill @e[type=item,x=-2,y=62,z=-2,dx=4,dy=4,dz=4,nbt={Item:{id:"minecraft:budding_amethyst"}}]
function nachtwache:sammler/kaufmenue
kill @e[tag=nw.herz_text]
function nachtwache:beacon/aufbauen
function nachtwache:beacon/anzeige
scoreboard players set #zoff nw.status 0
execute if score #alt nw.status matches ..74 run execute as @e[type=marker,tag=nw.zwerg] at @s run function nachtwache:zwerg/migrieren
execute if score #alt nw.status matches ..74 run function nachtwache:zwerg/altlast
execute as @e[type=marker,tag=nw.zwerg] at @s run function nachtwache:zwerg/knoepfe_raeumen
execute as @e[type=marker,tag=nw.bogi] at @s run function nachtwache:bogi/knoepfe_raeumen
execute if score #alt nw.status matches ..74 run execute if block 2 64 2 minecraft:chest run setblock 2 64 2 minecraft:air destroy
execute if score #alt nw.status matches ..74 run fill -1 64 4 1 64 6 minecraft:air replace minecraft:cobblestone_wall
execute if score #alt nw.status matches ..74 run fill -1 65 4 1 65 6 minecraft:air replace minecraft:oak_fence
execute if score #alt nw.status matches ..74 run setblock 0 66 5 minecraft:air
execute if score #alt nw.status matches ..74 run fill -1 63 4 1 63 6 minecraft:grass_block replace minecraft:cobblestone
execute if score #alt nw.status matches ..74 run fill -1 63 4 1 63 6 minecraft:grass_block replace minecraft:water
execute if score #alt nw.status matches ..74 run clear @a minecraft:echo_shard[custom_data~{nw_splitter:1b}]
execute if score #alt nw.status matches ..74 run clear @a minecraft:prismarine_crystals[custom_data~{nw_buendel:1b}]
execute if score #alt nw.status matches ..74 run kill @e[type=item,x=-6,y=60,z=-10,dx=12,dy=10,dz=8]
execute if score #alt nw.status matches ..74 run fill -3 64 -9 3 68 -3 minecraft:air
execute if score #alt nw.status matches ..74 run fill -3 63 -9 3 63 -3 minecraft:grass_block replace minecraft:polished_deepslate
execute if score #alt nw.status matches ..74 run fill -2 64 2 2 67 6 minecraft:air
execute if score #alt nw.status matches ..74 run fill -2 63 2 2 63 6 minecraft:grass_block replace minecraft:iron_block
execute if score #alt nw.status matches ..74 run fill -6 64 -3 -2 71 1 minecraft:air
execute if score #alt nw.status matches ..74 run setblock 5 64 3 minecraft:air
execute if score #alt nw.status matches ..74 run setblock -5 64 4 minecraft:air
execute if score #alt nw.status matches ..74 run kill @e[type=item,x=-8,y=60,z=-12,dx=16,dy=14,dz=20,nbt={Item:{id:"minecraft:iron_block"}}]
execute if score #alt nw.status matches ..74 run kill @e[type=item,x=-8,y=60,z=-12,dx=16,dy=14,dz=20,nbt={Item:{id:"minecraft:beacon"}}]
execute if score #alt nw.status matches ..74 run kill @e[type=item,x=-8,y=60,z=-12,dx=16,dy=14,dz=20,nbt={Item:{id:"minecraft:deepslate_bricks"}}]
execute if score #alt nw.status matches ..74 run kill @e[type=item,x=-8,y=60,z=-12,dx=16,dy=14,dz=20,nbt={Item:{id:"minecraft:hopper"}}]
execute if score #alt nw.status matches ..74 run kill @e[type=marker,tag=nw.gen,x=0,y=64,z=0,dx=0,dy=0,dz=0]
execute if score #alt nw.status matches ..74 run kill @e[type=marker,tag=nw.gen_neu,x=0,y=64,z=0,dx=0,dy=0,dz=0]
execute if score #alt nw.status matches ..74 run kill @e[type=block_display,tag=nw.gen_block,x=-1,y=63,z=-1,dx=2,dy=2,dz=2]
execute if score #alt nw.status matches ..74 run setblock 0 64 0 minecraft:air
execute if score #alt nw.status matches ..74 run function nachtwache:welt/startinsel
function nachtwache:welt/stand
function nachtwache:sammler/erscheinen
function nachtwache:sammler/kaufmenue
function nachtwache:beacon/aufbauen
kill @e[tag=nw.herz]
kill @e[tag=nw.herz_text]
execute if score #alt nw.status matches ..74 run kill @e[type=block_display,tag=nw.gen_block]
execute as @e[tag=nw.welle] run attribute @s minecraft:follow_range base set 128
spawnpoint @a 0 64 -10
setworldspawn 0 64 -10
execute if score #alt nw.status matches ..74 run tellraw @a [{"text":"[Nightwatch] The island has been rebuilt: longer, the beacon at the far end, the stall off to the side.","color":"yellow"}]
