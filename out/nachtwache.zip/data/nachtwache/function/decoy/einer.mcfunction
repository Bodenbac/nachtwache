execute at @s run particle minecraft:smoke ~ ~1.2 ~ 0.2 0.2 0.2 0.01 2
execute unless entity @e[tag=nw.decoy_stand,distance=..1.5] run kill @s
