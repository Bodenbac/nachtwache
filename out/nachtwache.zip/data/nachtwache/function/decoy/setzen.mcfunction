advancement revoke @s only nachtwache:decoy_benutzt
execute at @s align xyz positioned ~0.5 ~ ~0.5 run function nachtwache:decoy/bauen
