summon minecraft:armor_stand ~ ~ ~ {Tags:["nw.decoy_stand"],Invulnerable:1b,NoGravity:1b,NoBasePlate:1b,ShowArms:1b,PersistenceRequired:1b,CustomName:{"text":"Decoy","color":"gold"},CustomNameVisible:1b,equipment:{head:{id:"minecraft:carved_pumpkin",count:1},chest:{id:"minecraft:leather_chestplate",count:1,components:{"minecraft:dyed_color":9127187}},mainhand:{id:"minecraft:stick",count:1}},DisabledSlots:4144959}
summon minecraft:iron_golem ~ ~ ~ {Tags:["nw.decoy"],NoAI:1b,Silent:1b,Invisible:1b,PersistenceRequired:1b,NoGravity:1b,attributes:[{id:"minecraft:max_health",base:60d}],Health:60f}
playsound minecraft:block.wood.place block @a ~ ~ ~ 1 0.8
tellraw @a[distance=..20] [{"text":"A decoy stands. It will hold them for a while.","color":"gold"}]
