execute unless entity @e[tag=nw.decoy] run return 0
execute as @e[tag=nw.decoy] at @s run function nachtwache:decoy/einer
execute as @e[tag=nw.decoy_stand] at @s unless entity @e[tag=nw.decoy,distance=..1.5] run function nachtwache:decoy/zerbricht
