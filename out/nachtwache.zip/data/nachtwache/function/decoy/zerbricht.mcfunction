playsound minecraft:entity.item.break block @a ~ ~ ~ 1 0.7
particle minecraft:block{block_state:"minecraft:carved_pumpkin"} ~ ~1 ~ 0.3 0.6 0.3 0.1 30
tellraw @a[distance=..20] [{"text":"The decoy is torn apart.","color":"gray","italic":true}]
kill @s
