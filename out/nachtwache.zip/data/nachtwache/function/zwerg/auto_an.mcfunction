scoreboard players set @s nw.zwerg_a 2
playsound minecraft:block.lever.click block @a[distance=..8] ~ ~ ~ 1 1.4
tellraw @p[distance=..8] [{"text":"[Fraggle] ","color":"aqua"},{"text":"I sell as I go.","color":"gray"}]
function nachtwache:zwerg/symbol
