kill @e[type=item_display,tag=nw.zwerg_k,distance=..0.1]
kill @e[type=item_display,tag=nw.zwerg_a,distance=..0.1]
execute unless score #zoff nw.status matches -1000.. run scoreboard players set #zoff nw.status 0
scoreboard players set #yaw nw.tmp2 0
execute if score @s nw.zwerg_d matches 0 run scoreboard players set #yaw nw.tmp2 180
execute if score @s nw.zwerg_d matches 1 run scoreboard players set #yaw nw.tmp2 270
execute if score @s nw.zwerg_d matches 2 run scoreboard players set #yaw nw.tmp2 0
execute if score @s nw.zwerg_d matches 3 run scoreboard players set #yaw nw.tmp2 90
scoreboard players operation #yaw nw.tmp2 += #zoff nw.status
scoreboard players add #yaw nw.tmp2 720
scoreboard players operation #yaw nw.tmp2 %= #360 nw.const
execute store result storage nachtwache:tmp yaw int 1 run scoreboard players get #yaw nw.tmp2
function nachtwache:zwerg/displays with storage nachtwache:tmp
