execute unless block ~ ~ ~ minecraft:trapped_chest run return run function nachtwache:zwerg/kaputt_ganz
scoreboard players add @s nw.zwerg_t 1
scoreboard players operation #iv nw.tmp2 = @s nw.zwerg
scoreboard players operation #iv nw.tmp2 *= #20 nw.const
scoreboard players set #takt nw.tmp2 300
scoreboard players operation #takt nw.tmp2 -= #iv nw.tmp2
execute if score @s nw.zwerg_t >= #takt nw.tmp2 run function nachtwache:zwerg/schlag
execute if score @s nw.zwerg_t matches 6 as @e[type=item_display,tag=nw.zwerg_a,distance=..0.1] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{left_rotation:[0.0f,0f,0f,1.0f],translation:[0f,0.0f,0.0f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
function nachtwache:zwerg/knopf
clear @a[distance=..8] *[custom_data~{nw_zwerg_lock:1b}]
execute if score #m20 nw.tmp matches 11 run function nachtwache:zwerg/symbol
