execute unless block ~ ~ ~ minecraft:trapped_chest run return run function nachtwache:zwerg/kaputt
scoreboard players add @s nw.zwerg_t 1
scoreboard players operation #iv nw.tmp2 = @s nw.zwerg
scoreboard players operation #iv nw.tmp2 *= #20 nw.const
scoreboard players set #takt nw.tmp2 300
scoreboard players operation #takt nw.tmp2 -= #iv nw.tmp2
execute if score @s nw.zwerg_t >= #takt nw.tmp2 run function nachtwache:zwerg/schlag
execute if score @s nw.zwerg_t matches 6 as @e[type=item_display,tag=nw.zwerg_a,distance=..0.1] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{left_rotation:[0.0f,0f,0f,1.0f],translation:[0f,0.0f,0.0f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
execute if score @s nw.zwerg_b matches 0 unless items block ~ ~ ~ container.5 *[custom_data~{nw_zwerg_auto:1b}] run function nachtwache:zwerg/auto_klick
execute if score @s nw.zwerg_b matches 0 unless items block ~ ~ ~ container.6 *[custom_data~{nw_zwerg_sell:1b}] run function nachtwache:zwerg/verkauf_alles
execute if score @s nw.zwerg_b matches 0 unless items block ~ ~ ~ container.7 *[custom_data~{nw_zwerg_bp:1b}] run function nachtwache:zwerg/rucksack
execute if score @s nw.zwerg_b matches 0 unless items block ~ ~ ~ container.8 *[custom_data~{nw_zwerg_up:1b}] run function nachtwache:zwerg/upgrade
execute if score @s nw.zwerg_b matches 1 unless items block ~ ~ ~ container.14 *[custom_data~{nw_zwerg_auto:1b}] run function nachtwache:zwerg/auto_klick
execute if score @s nw.zwerg_b matches 1 unless items block ~ ~ ~ container.15 *[custom_data~{nw_zwerg_sell:1b}] run function nachtwache:zwerg/verkauf_alles
execute if score @s nw.zwerg_b matches 1 unless items block ~ ~ ~ container.16 *[custom_data~{nw_zwerg_bp:1b}] run function nachtwache:zwerg/rucksack
execute if score @s nw.zwerg_b matches 1 unless items block ~ ~ ~ container.17 *[custom_data~{nw_zwerg_up:1b}] run function nachtwache:zwerg/upgrade
execute if score @s nw.zwerg_b matches 2 unless items block ~ ~ ~ container.23 *[custom_data~{nw_zwerg_auto:1b}] run function nachtwache:zwerg/auto_klick
execute if score @s nw.zwerg_b matches 2 unless items block ~ ~ ~ container.24 *[custom_data~{nw_zwerg_sell:1b}] run function nachtwache:zwerg/verkauf_alles
execute if score @s nw.zwerg_b matches 2 unless items block ~ ~ ~ container.25 *[custom_data~{nw_zwerg_bp:1b}] run function nachtwache:zwerg/rucksack
execute if score @s nw.zwerg_b matches 2 unless items block ~ ~ ~ container.26 *[custom_data~{nw_zwerg_up:1b}] run function nachtwache:zwerg/upgrade
clear @a[distance=..8] *[custom_data~{nw_zwerg_auto:1b}]
scoreboard players operation #m100 nw.tmp2 = #tick nw.tick
scoreboard players operation #m100 nw.tmp2 %= #100 nw.const
execute if score @s nw.zwerg_a matches 2 if score #m100 nw.tmp2 matches 0 run function nachtwache:zwerg/auto_verkauf
clear @a[distance=..8] *[custom_data~{nw_zwerg_lock:1b}]
execute if score #m20 nw.tmp matches 11 run function nachtwache:zwerg/symbol
execute if score #m20 nw.tmp matches 13 run function nachtwache:zwerg/merken
