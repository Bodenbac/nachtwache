execute as @e[type=marker,tag=nw.zwerg_neu] at @s run function nachtwache:zwerg/neu
execute as @e[type=marker,tag=nw.zwerg] at @s run function nachtwache:zwerg/einer
