setblock -2 64 -1 minecraft:air destroy
