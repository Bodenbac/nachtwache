setblock 2 64 0 minecraft:air destroy
