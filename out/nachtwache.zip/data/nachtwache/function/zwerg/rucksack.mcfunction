scoreboard players operation #bp nw.tmp2 = @s nw.zwerg_b
execute if score #bp nw.tmp2 matches 0 run scoreboard players set #bpp nw.tmp2 1500
execute if score #bp nw.tmp2 matches 1 run scoreboard players set #bpp nw.tmp2 4000
execute as @a[distance=..8] store result score @s nw.tmp run clear @s *[custom_data~{nw_zwerg_bp:1b}] 0
execute as @a[distance=..8,scores={nw.tmp=1..}] run function nachtwache:zwerg/rucksack_kauf
scoreboard players operation @s nw.zwerg_b = #bp nw.tmp2
function nachtwache:zwerg/symbol
