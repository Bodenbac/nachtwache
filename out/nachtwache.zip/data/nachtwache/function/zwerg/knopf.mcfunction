execute if score @s nw.zwerg_d matches 0 run function nachtwache:zwerg/knopf_0
execute if score @s nw.zwerg_d matches 1 run function nachtwache:zwerg/knopf_1
execute if score @s nw.zwerg_d matches 2 run function nachtwache:zwerg/knopf_2
execute if score @s nw.zwerg_d matches 3 run function nachtwache:zwerg/knopf_3
execute if score @s nw.zwerg_d matches 4 run function nachtwache:zwerg/knopf_4
execute if score @s nw.zwerg_d matches 5 run function nachtwache:zwerg/knopf_5
execute if score @s nw.zwerg_d matches 6 run function nachtwache:zwerg/knopf_6
execute if score @s nw.zwerg_d matches 7 run function nachtwache:zwerg/knopf_7
