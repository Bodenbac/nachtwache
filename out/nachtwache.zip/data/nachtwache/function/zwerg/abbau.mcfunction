scoreboard players set #wer nw.tmp 2
scoreboard players add #abbau nw.abbau 1
scoreboard players operation #splitter nw.tmp = #phase nw.phase
execute if score #phase nw.phase matches 1 run scoreboard players set #splitter nw.tmp 1
execute if score #phase nw.phase matches 2 run scoreboard players set #splitter nw.tmp 2
execute if score #phase nw.phase matches 3 run scoreboard players set #splitter nw.tmp 3
execute if score #phase nw.phase matches 4 run scoreboard players set #splitter nw.tmp 4
execute if score #phase nw.phase matches 5 run scoreboard players set #splitter nw.tmp 5
execute if score #phase nw.phase matches 6 run scoreboard players set #splitter nw.tmp 6
execute if score #phase nw.phase matches 7 run scoreboard players set #splitter nw.tmp 8
scoreboard players operation #konto nw.konto += #splitter nw.tmp
scoreboard players operation #verdient nw.verdient += #splitter nw.tmp
playsound minecraft:block.amethyst_block.break player @a ~ ~ ~ 0.6 0.7
execute if score #phase nw.phase matches 1 if predicate nachtwache:quell_mob_1 run function nachtwache:quell/mob_1
execute if score #phase nw.phase matches 1 unless score #mobda nw.tmp matches 1 run loot insert ~ ~ ~ loot nachtwache:quell/phase1
execute if score #phase nw.phase matches 2 if predicate nachtwache:quell_mob_2 run function nachtwache:quell/mob_2
execute if score #phase nw.phase matches 2 unless score #mobda nw.tmp matches 1 run loot insert ~ ~ ~ loot nachtwache:quell/phase2
execute if score #phase nw.phase matches 3 if predicate nachtwache:quell_mob_3 run function nachtwache:quell/mob_3
execute if score #phase nw.phase matches 3 unless score #mobda nw.tmp matches 1 run loot insert ~ ~ ~ loot nachtwache:quell/phase3
execute if score #phase nw.phase matches 4 if predicate nachtwache:quell_mob_4 run function nachtwache:quell/mob_4
execute if score #phase nw.phase matches 4 unless score #mobda nw.tmp matches 1 run loot insert ~ ~ ~ loot nachtwache:quell/phase4
execute if score #phase nw.phase matches 5 if predicate nachtwache:quell_mob_5 run function nachtwache:quell/mob_5
execute if score #phase nw.phase matches 5 unless score #mobda nw.tmp matches 1 run loot insert ~ ~ ~ loot nachtwache:quell/phase5
execute if score #phase nw.phase matches 6 if predicate nachtwache:quell_mob_6 run function nachtwache:quell/mob_6
execute if score #phase nw.phase matches 6 unless score #mobda nw.tmp matches 1 run loot insert ~ ~ ~ loot nachtwache:quell/phase6
execute if score #phase nw.phase matches 7 if predicate nachtwache:quell_mob_7 run function nachtwache:quell/mob_7
execute if score #phase nw.phase matches 7 unless score #mobda nw.tmp matches 1 run loot insert ~ ~ ~ loot nachtwache:quell/phase7
scoreboard players reset #mobda nw.tmp
execute if score #abbau nw.abbau matches 500 run function nachtwache:quell/phase_wechsel {phase:2}
execute if score #abbau nw.abbau matches 1500 run function nachtwache:quell/phase_wechsel {phase:3}
execute if score #abbau nw.abbau matches 3000 run function nachtwache:quell/phase_wechsel {phase:4}
execute if score #abbau nw.abbau matches 5000 run function nachtwache:quell/phase_wechsel {phase:5}
execute if score #abbau nw.abbau matches 8000 run function nachtwache:quell/phase_wechsel {phase:6}
execute if score #abbau nw.abbau matches 12000 run function nachtwache:quell/phase_wechsel {phase:7}
