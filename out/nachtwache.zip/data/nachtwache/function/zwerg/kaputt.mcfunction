kill @e[type=item_display,tag=nw.zwerg_k,distance=..0.1]
kill @e[type=item_display,tag=nw.zwerg_a,distance=..0.1]
kill @e[type=item,distance=..2.5,nbt={Item:{id:"minecraft:trapped_chest"}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_zwerg_up:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_zwerg_bp:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_zwerg_sell:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_zwerg_lock:1b}}}}]
kill @e[type=item,distance=..2.0]
data modify storage nachtwache:tmp inv set value []
execute if data entity @s data.inv run data modify storage nachtwache:tmp inv set from entity @s data.inv
execute if score @s nw.zwerg matches 0 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_0_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 0 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_0_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 0 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_0_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 1 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_1_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 1 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_1_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 1 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_1_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 2 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_2_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 2 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_2_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 2 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_2_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 3 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_3_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 3 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_3_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 3 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_3_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 4 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_4_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 4 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_4_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 4 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_4_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 5 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_5_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 5 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_5_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 5 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_5_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 6 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_6_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 6 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_6_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 6 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_6_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 7 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_7_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 7 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_7_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 7 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_7_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 8 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_8_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 8 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_8_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 8 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_8_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 9 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_9_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 9 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_9_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 9 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_9_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 10 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_10_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 10 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_10_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 10 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_10_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 11 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_11_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 11 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_11_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 11 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_11_2 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 12 if score @s nw.zwerg_b matches 0 as @p[distance=..10] run function nachtwache:zwerg/geben_12_0 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 12 if score @s nw.zwerg_b matches 1 as @p[distance=..10] run function nachtwache:zwerg/geben_12_1 with storage nachtwache:tmp
execute if score @s nw.zwerg matches 12 if score @s nw.zwerg_b matches 2 as @p[distance=..10] run function nachtwache:zwerg/geben_12_2 with storage nachtwache:tmp
tellraw @p[distance=..10] [{"text":"[Fraggle] ","color":"aqua"},{"text":"Packing up. I am in your inventory.","color":"gray"}]
playsound minecraft:entity.item.pickup player @p[distance=..10] ~ ~ ~ 1 0.8
kill @s
