data modify storage nachtwache:tmp inv set value []
execute if data entity @s data.inv run data modify storage nachtwache:tmp inv set from entity @s data.inv
execute if entity @s[tag=nw.lvl0] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_0_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl0] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_0_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl0] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_0_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl1] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_1_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl1] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_1_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl1] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_1_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl2] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_2_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl2] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_2_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl2] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_2_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl3] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_3_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl3] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_3_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl3] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_3_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl4] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_4_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl4] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_4_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl4] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_4_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl5] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_5_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl5] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_5_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl5] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_5_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl6] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_6_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl6] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_6_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl6] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_6_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl7] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_7_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl7] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_7_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl7] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_7_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl8] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_8_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl8] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_8_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl8] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_8_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl9] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_9_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl9] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_9_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl9] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_9_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl10] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_10_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl10] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_10_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl10] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_10_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl11] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_11_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl11] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_11_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl11] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_11_2 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl12] if entity @s[tag=nw.bp0] as @p[distance=..10] run function nachtwache:zwerg/geben_12_0 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl12] if entity @s[tag=nw.bp1] as @p[distance=..10] run function nachtwache:zwerg/geben_12_1 with storage nachtwache:tmp
execute if entity @s[tag=nw.lvl12] if entity @s[tag=nw.bp2] as @p[distance=..10] run function nachtwache:zwerg/geben_12_2 with storage nachtwache:tmp
tellraw @p[distance=..10] [{"text":"[Fraggle] ","color":"aqua"},{"text":"Put me on the ground next to a Source Generator, not on the generator itself. Sneak-click works too.","color":"gray"}]
kill @s
