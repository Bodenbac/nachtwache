clear @s *[custom_data~{nw_zwerg_up:1b}]
execute if score #lvl nw.tmp2 matches 12.. run return run tellraw @s [{"text":"[Dwarf] ","color":"aqua"},{"text":"Faster than this I will not go.","color":"gray"}]
execute if score #konto nw.konto < #up nw.tmp2 run tellraw @s [{"text":"[Dwarf] ","color":"aqua"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#up","objective":"nw.tmp2"},"color":"gold"},{"text":" needed.","color":"gray"}]
execute if score #konto nw.konto < #up nw.tmp2 run return run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
scoreboard players operation #konto nw.konto -= #up nw.tmp2
scoreboard players add #lvl nw.tmp2 1
playsound minecraft:block.anvil.use block @s ~ ~ ~ 0.6 1.2
tellraw @s [{"text":"[Dwarf] ","color":"aqua"},{"text":"Sharper. Level ","color":"gray"},{"score":{"name":"#lvl","objective":"nw.tmp2"},"color":"aqua"},{"text":".","color":"gray"}]
