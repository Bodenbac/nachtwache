clear @s *[custom_data~{nw_zwerg_bp:1b}]
execute if score #bp nw.tmp2 matches 2.. run return run tellraw @s [{"text":"[Fraggle] ","color":"aqua"},{"text":"The pack holds no more.","color":"gray"}]
execute if score #konto nw.konto < #bpp nw.tmp2 run tellraw @s [{"text":"[Fraggle] ","color":"aqua"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#bpp","objective":"nw.tmp2"},"color":"gold"},{"text":" needed.","color":"gray"}]
execute if score #konto nw.konto < #bpp nw.tmp2 run return run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
scoreboard players operation #konto nw.konto -= #bpp nw.tmp2
scoreboard players add #bp nw.tmp2 1
playsound minecraft:block.wool.place block @s ~ ~ ~ 0.8 1.2
tellraw @s [{"text":"[Fraggle] ","color":"aqua"},{"text":"More room. Pack level ","color":"gray"},{"score":{"name":"#bp","objective":"nw.tmp2"},"color":"aqua"},{"text":".","color":"gray"}]
