scoreboard players set @s nw.zwerg_t 0
scoreboard players set #gen nw.tmp2 0
execute if score @s nw.zwerg_d matches 0 positioned ~0 ~ ~-1 if entity @e[type=marker,tag=nw.gen,distance=..0.2] run scoreboard players set #gen nw.tmp2 1
execute if score @s nw.zwerg_d matches 0 if block ~0 ~ ~-1 minecraft:barrel[facing=down] run scoreboard players set #gen nw.tmp2 1
execute if score @s nw.zwerg_d matches 1 positioned ~1 ~ ~0 if entity @e[type=marker,tag=nw.gen,distance=..0.2] run scoreboard players set #gen nw.tmp2 1
execute if score @s nw.zwerg_d matches 1 if block ~1 ~ ~0 minecraft:barrel[facing=down] run scoreboard players set #gen nw.tmp2 1
execute if score @s nw.zwerg_d matches 2 positioned ~0 ~ ~1 if entity @e[type=marker,tag=nw.gen,distance=..0.2] run scoreboard players set #gen nw.tmp2 1
execute if score @s nw.zwerg_d matches 2 if block ~0 ~ ~1 minecraft:barrel[facing=down] run scoreboard players set #gen nw.tmp2 1
execute if score @s nw.zwerg_d matches 3 positioned ~-1 ~ ~0 if entity @e[type=marker,tag=nw.gen,distance=..0.2] run scoreboard players set #gen nw.tmp2 1
execute if score @s nw.zwerg_d matches 3 if block ~-1 ~ ~0 minecraft:barrel[facing=down] run scoreboard players set #gen nw.tmp2 1
execute if score #gen nw.tmp2 matches 0 run return 0
execute store result score #voll nw.tmp2 run data get block ~ ~ ~ Items
execute if score #voll nw.tmp2 matches 27.. run return run title @a[distance=..8] actionbar [{"text":"Fraggle's pack is full. Sell it or buy a bigger one.","color":"red"}]
execute as @e[type=item_display,tag=nw.zwerg_a,distance=..0.1] run data merge entity @s {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[-0.60876f,0f,0f,0.79335f],translation:[0f,0.07651f,0.03721f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
execute if score @s nw.zwerg_d matches 0 positioned ~0 ~ ~-1 run playsound minecraft:block.stone.hit block @a ~ ~ ~ 1 0.8
execute if score @s nw.zwerg_d matches 0 if score #phase nw.phase matches 1 positioned ~0 ~ ~-1 run particle minecraft:block{block_state:"minecraft:tuff"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 0 if score #phase nw.phase matches 2 positioned ~0 ~ ~-1 run particle minecraft:block{block_state:"minecraft:green_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 0 if score #phase nw.phase matches 3 positioned ~0 ~ ~-1 run particle minecraft:block{block_state:"minecraft:blue_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 0 if score #phase nw.phase matches 4 positioned ~0 ~ ~-1 run particle minecraft:block{block_state:"minecraft:budding_amethyst"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 0 if score #phase nw.phase matches 5 positioned ~0 ~ ~-1 run particle minecraft:block{block_state:"minecraft:yellow_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 0 if score #phase nw.phase matches 6 positioned ~0 ~ ~-1 run particle minecraft:block{block_state:"minecraft:orange_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 0 if score #phase nw.phase matches 7 positioned ~0 ~ ~-1 run particle minecraft:block{block_state:"minecraft:black_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 1 positioned ~1 ~ ~0 run playsound minecraft:block.stone.hit block @a ~ ~ ~ 1 0.8
execute if score @s nw.zwerg_d matches 1 if score #phase nw.phase matches 1 positioned ~1 ~ ~0 run particle minecraft:block{block_state:"minecraft:tuff"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 1 if score #phase nw.phase matches 2 positioned ~1 ~ ~0 run particle minecraft:block{block_state:"minecraft:green_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 1 if score #phase nw.phase matches 3 positioned ~1 ~ ~0 run particle minecraft:block{block_state:"minecraft:blue_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 1 if score #phase nw.phase matches 4 positioned ~1 ~ ~0 run particle minecraft:block{block_state:"minecraft:budding_amethyst"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 1 if score #phase nw.phase matches 5 positioned ~1 ~ ~0 run particle minecraft:block{block_state:"minecraft:yellow_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 1 if score #phase nw.phase matches 6 positioned ~1 ~ ~0 run particle minecraft:block{block_state:"minecraft:orange_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 1 if score #phase nw.phase matches 7 positioned ~1 ~ ~0 run particle minecraft:block{block_state:"minecraft:black_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 2 positioned ~0 ~ ~1 run playsound minecraft:block.stone.hit block @a ~ ~ ~ 1 0.8
execute if score @s nw.zwerg_d matches 2 if score #phase nw.phase matches 1 positioned ~0 ~ ~1 run particle minecraft:block{block_state:"minecraft:tuff"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 2 if score #phase nw.phase matches 2 positioned ~0 ~ ~1 run particle minecraft:block{block_state:"minecraft:green_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 2 if score #phase nw.phase matches 3 positioned ~0 ~ ~1 run particle minecraft:block{block_state:"minecraft:blue_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 2 if score #phase nw.phase matches 4 positioned ~0 ~ ~1 run particle minecraft:block{block_state:"minecraft:budding_amethyst"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 2 if score #phase nw.phase matches 5 positioned ~0 ~ ~1 run particle minecraft:block{block_state:"minecraft:yellow_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 2 if score #phase nw.phase matches 6 positioned ~0 ~ ~1 run particle minecraft:block{block_state:"minecraft:orange_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 2 if score #phase nw.phase matches 7 positioned ~0 ~ ~1 run particle minecraft:block{block_state:"minecraft:black_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 3 positioned ~-1 ~ ~0 run playsound minecraft:block.stone.hit block @a ~ ~ ~ 1 0.8
execute if score @s nw.zwerg_d matches 3 if score #phase nw.phase matches 1 positioned ~-1 ~ ~0 run particle minecraft:block{block_state:"minecraft:tuff"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 3 if score #phase nw.phase matches 2 positioned ~-1 ~ ~0 run particle minecraft:block{block_state:"minecraft:green_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 3 if score #phase nw.phase matches 3 positioned ~-1 ~ ~0 run particle minecraft:block{block_state:"minecraft:blue_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 3 if score #phase nw.phase matches 4 positioned ~-1 ~ ~0 run particle minecraft:block{block_state:"minecraft:budding_amethyst"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 3 if score #phase nw.phase matches 5 positioned ~-1 ~ ~0 run particle minecraft:block{block_state:"minecraft:yellow_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 3 if score #phase nw.phase matches 6 positioned ~-1 ~ ~0 run particle minecraft:block{block_state:"minecraft:orange_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
execute if score @s nw.zwerg_d matches 3 if score #phase nw.phase matches 7 positioned ~-1 ~ ~0 run particle minecraft:block{block_state:"minecraft:black_concrete"} ~ ~ ~ 0.3 0.3 0.3 0 12
function nachtwache:zwerg/abbau
