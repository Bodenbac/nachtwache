scoreboard players set @s nw.zwerg_t 0
execute unless block 0 64 0 #nachtwache:quell run return 0
execute store result score #voll nw.tmp2 run data get block ~ ~ ~ Items
execute if score #voll nw.tmp2 matches 27.. run return run title @a[distance=..8] actionbar [{"text":"Fraggle's pack is full.","color":"red"}]
execute as @e[type=item_display,tag=nw.zwerg_a,distance=..0.1] run data merge entity @s {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[-0.60876f,0f,0f,0.79335f],translation:[0f,0.07651f,0.03721f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
playsound minecraft:block.stone.hit block @a 0 64 0 1 0.8
execute if score #phase nw.phase matches 1 run particle minecraft:block{block_state:"minecraft:tuff"} 0.5 64.5 0.5 0.3 0.3 0.3 0 12
execute if score #phase nw.phase matches 2 run particle minecraft:block{block_state:"minecraft:green_concrete"} 0.5 64.5 0.5 0.3 0.3 0.3 0 12
execute if score #phase nw.phase matches 3 run particle minecraft:block{block_state:"minecraft:blue_concrete"} 0.5 64.5 0.5 0.3 0.3 0.3 0 12
execute if score #phase nw.phase matches 4 run particle minecraft:block{block_state:"minecraft:budding_amethyst"} 0.5 64.5 0.5 0.3 0.3 0.3 0 12
execute if score #phase nw.phase matches 5 run particle minecraft:block{block_state:"minecraft:yellow_concrete"} 0.5 64.5 0.5 0.3 0.3 0.3 0 12
execute if score #phase nw.phase matches 6 run particle minecraft:block{block_state:"minecraft:orange_concrete"} 0.5 64.5 0.5 0.3 0.3 0.3 0 12
execute if score #phase nw.phase matches 7 run particle minecraft:block{block_state:"minecraft:black_concrete"} 0.5 64.5 0.5 0.3 0.3 0.3 0 12
function nachtwache:zwerg/abbau
