execute store result score #voll nw.tmp2 run data get block 0 64 1 Items
execute if score #voll nw.tmp2 matches ..26 positioned 0.5 64.5 1.5 run return run function nachtwache:zwerg/abbau
execute store result score #voll2 nw.tmp2 run data get block 0 64 2 Items
execute if score #voll2 nw.tmp2 matches ..26 positioned 0.5 64.5 2.5 run return run function nachtwache:zwerg/abbau
title @a[distance=..8] actionbar [{"text":"Fraggle's pack is full. Sell it or buy a bigger one.","color":"red"}]
