tag @s add nw.zwerg
scoreboard players set @s nw.zwerg 0
scoreboard players set @s nw.zwerg_t 0
scoreboard players set @s nw.zwerg_b 0
scoreboard players set @s nw.zwerg_d 4
execute if entity @s[tag=nw.lvl1] run scoreboard players set @s nw.zwerg 1
execute if entity @s[tag=nw.lvl2] run scoreboard players set @s nw.zwerg 2
execute if entity @s[tag=nw.lvl3] run scoreboard players set @s nw.zwerg 3
execute if entity @s[tag=nw.lvl4] run scoreboard players set @s nw.zwerg 4
execute if entity @s[tag=nw.lvl5] run scoreboard players set @s nw.zwerg 5
execute if entity @s[tag=nw.lvl6] run scoreboard players set @s nw.zwerg 6
execute if entity @s[tag=nw.lvl7] run scoreboard players set @s nw.zwerg 7
execute if entity @s[tag=nw.lvl8] run scoreboard players set @s nw.zwerg 8
execute if entity @s[tag=nw.lvl9] run scoreboard players set @s nw.zwerg 9
execute if entity @s[tag=nw.lvl10] run scoreboard players set @s nw.zwerg 10
execute if entity @s[tag=nw.lvl11] run scoreboard players set @s nw.zwerg 11
execute if entity @s[tag=nw.lvl12] run scoreboard players set @s nw.zwerg 12
execute if entity @s[tag=nw.bp1] run scoreboard players set @s nw.zwerg_b 1
execute if entity @s[tag=nw.bp2] run scoreboard players set @s nw.zwerg_b 2
execute if entity @s[tag=nw.bp3] run scoreboard players set @s nw.zwerg_b 3
setblock 0 64 1 minecraft:trapped_chest[facing=west,type=right]
setblock 0 64 2 minecraft:trapped_chest[facing=west,type=left]
function nachtwache:zwerg/zeichnen
function nachtwache:zwerg/symbol
playsound minecraft:entity.villager.work_toolsmith neutral @a ~ ~ ~ 1 0.8
tellraw @a[distance=..12] [{"text":"Fraggle takes his place at the Source. Right-click him for his pack.","color":"aqua"}]
