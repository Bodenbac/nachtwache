setblock 0 64 -2 minecraft:air destroy
