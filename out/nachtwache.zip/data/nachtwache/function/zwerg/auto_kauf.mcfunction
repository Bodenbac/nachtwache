execute if score #konto nw.konto < #2000 nw.const run playsound minecraft:entity.villager.no neutral @p[distance=..8] ~ ~ ~ 1 1
execute if score #konto nw.konto < #2000 nw.const run return run tellraw @p[distance=..8] [{"text":"[Fraggle] ","color":"aqua"},{"text":"Not enough coins. 2000 needed.","color":"gray"}]
scoreboard players operation #konto nw.konto -= #2000 nw.const
scoreboard players set @s nw.zwerg_a 2
playsound minecraft:block.anvil.use block @a[distance=..8] ~ ~ ~ 0.6 1.2
tellraw @p[distance=..8] [{"text":"[Fraggle] ","color":"aqua"},{"text":"From now on I sell it myself.","color":"gray"}]
function nachtwache:zwerg/symbol
