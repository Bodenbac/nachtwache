tag @s remove nw.zwerg_neu
execute align xyz positioned ~0.5 ~0.5 ~0.5 run tp @s ~ ~ ~
execute positioned 0.5 64.5 0.5 unless entity @s[distance=..1.9] run return run function nachtwache:zwerg/zurueck
execute unless block ~ ~ ~ minecraft:air run return run function nachtwache:zwerg/zurueck
execute positioned -0.5 64.5 -0.5 if entity @s[distance=..0.01] unless block -2 64 -1 minecraft:air run return run function nachtwache:zwerg/kein_platz
execute positioned -0.5 64.5 -0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen_0
execute positioned -0.5 64.5 0.5 if entity @s[distance=..0.01] unless block -2 64 0 minecraft:air run return run function nachtwache:zwerg/kein_platz
execute positioned -0.5 64.5 0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen_1
execute positioned -0.5 64.5 1.5 if entity @s[distance=..0.01] unless block -2 64 1 minecraft:air run return run function nachtwache:zwerg/kein_platz
execute positioned -0.5 64.5 1.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen_2
execute positioned 0.5 64.5 -0.5 if entity @s[distance=..0.01] unless block 0 64 -2 minecraft:air run return run function nachtwache:zwerg/kein_platz
execute positioned 0.5 64.5 -0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen_3
execute positioned 0.5 64.5 1.5 if entity @s[distance=..0.01] unless block 0 64 2 minecraft:air run return run function nachtwache:zwerg/kein_platz
execute positioned 0.5 64.5 1.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen_4
execute positioned 1.5 64.5 -0.5 if entity @s[distance=..0.01] unless block 2 64 -1 minecraft:air run return run function nachtwache:zwerg/kein_platz
execute positioned 1.5 64.5 -0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen_5
execute positioned 1.5 64.5 0.5 if entity @s[distance=..0.01] unless block 2 64 0 minecraft:air run return run function nachtwache:zwerg/kein_platz
execute positioned 1.5 64.5 0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen_6
execute positioned 1.5 64.5 1.5 if entity @s[distance=..0.01] unless block 2 64 1 minecraft:air run return run function nachtwache:zwerg/kein_platz
execute positioned 1.5 64.5 1.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen_7
execute unless entity @s[tag=nw.zwerg] run function nachtwache:zwerg/zurueck
