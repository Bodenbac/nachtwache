tag @s remove nw.zwerg_neu
execute align xyz positioned ~0.5 ~0.5 ~0.5 run tp @s ~ ~ ~
execute at @s unless block ~ ~ ~ minecraft:air run return run function nachtwache:zwerg/zurueck
execute at @s if block ~ ~-1 ~ minecraft:air run return run function nachtwache:zwerg/zurueck
scoreboard players set @s nw.zwerg_d -1
execute at @s positioned ~0 ~ ~-1 if entity @e[type=marker,tag=nw.gen,distance=..0.2] run scoreboard players set @s nw.zwerg_d 0
execute at @s if block ~0 ~ ~-1 minecraft:barrel[facing=down] run scoreboard players set @s nw.zwerg_d 0
execute at @s positioned ~1 ~ ~0 if entity @e[type=marker,tag=nw.gen,distance=..0.2] run scoreboard players set @s nw.zwerg_d 1
execute at @s if block ~1 ~ ~0 minecraft:barrel[facing=down] run scoreboard players set @s nw.zwerg_d 1
execute at @s positioned ~0 ~ ~1 if entity @e[type=marker,tag=nw.gen,distance=..0.2] run scoreboard players set @s nw.zwerg_d 2
execute at @s if block ~0 ~ ~1 minecraft:barrel[facing=down] run scoreboard players set @s nw.zwerg_d 2
execute at @s positioned ~-1 ~ ~0 if entity @e[type=marker,tag=nw.gen,distance=..0.2] run scoreboard players set @s nw.zwerg_d 3
execute at @s if block ~-1 ~ ~0 minecraft:barrel[facing=down] run scoreboard players set @s nw.zwerg_d 3
execute if score @s nw.zwerg_d matches -1 run return run function nachtwache:zwerg/zurueck
execute at @s run function nachtwache:zwerg/setzen
