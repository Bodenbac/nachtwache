tag @s remove nw.zwerg_neu
execute align xyz positioned ~0.5 ~0.5 ~0.5 run tp @s ~ ~ ~
execute positioned 0.5 64.5 0.5 unless entity @s[distance=..1.9] run return run function nachtwache:zwerg/zurueck
execute unless block ~ ~ ~ minecraft:air run return run function nachtwache:zwerg/zurueck
execute positioned -0.5 64.5 -0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen
execute positioned -0.5 64.5 0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen
execute positioned -0.5 64.5 1.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen
execute positioned 0.5 64.5 -0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen
execute positioned 0.5 64.5 1.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen
execute positioned 1.5 64.5 -0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen
execute positioned 1.5 64.5 0.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen
execute positioned 1.5 64.5 1.5 if entity @s[distance=..0.01] run function nachtwache:zwerg/setzen
execute unless entity @s[tag=nw.zwerg] run function nachtwache:zwerg/zurueck
