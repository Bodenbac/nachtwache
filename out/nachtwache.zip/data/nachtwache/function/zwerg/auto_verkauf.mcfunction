function nachtwache:zwerg/verkauf_kern
execute if score #erloes nw.tmp2 matches 1.. run playsound minecraft:entity.villager.trade neutral @a[distance=..8] ~ ~ ~ 0.4 1.2
execute if score #erloes nw.tmp2 matches 1.. run particle minecraft:happy_villager ~ ~1 ~ 0.3 0.3 0.3 0 5
