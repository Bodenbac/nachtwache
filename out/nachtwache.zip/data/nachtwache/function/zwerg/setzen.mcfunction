tag @s add nw.zwerg
scoreboard players set @s nw.zwerg 0
scoreboard players set @s nw.zwerg_t 0
scoreboard players set @s nw.zwerg_b 0
execute if entity @s[tag=nw.lvl1] run scoreboard players set @s nw.zwerg 1
execute if entity @s[tag=nw.lvl2] run scoreboard players set @s nw.zwerg 2
execute if entity @s[tag=nw.lvl3] run scoreboard players set @s nw.zwerg 3
execute if entity @s[tag=nw.lvl4] run scoreboard players set @s nw.zwerg 4
execute if entity @s[tag=nw.lvl5] run scoreboard players set @s nw.zwerg 5
execute if entity @s[tag=nw.lvl6] run scoreboard players set @s nw.zwerg 6
execute if entity @s[tag=nw.lvl7] run scoreboard players set @s nw.zwerg 7
execute if entity @s[tag=nw.lvl8] run scoreboard players set @s nw.zwerg 8
execute if entity @s[tag=nw.lvl9] run scoreboard players set @s nw.zwerg 9
execute if entity @s[tag=nw.lvl10] run scoreboard players set @s nw.zwerg 10
execute if entity @s[tag=nw.lvl11] run scoreboard players set @s nw.zwerg 11
execute if entity @s[tag=nw.lvl12] run scoreboard players set @s nw.zwerg 12
execute if entity @s[tag=nw.bp1] run scoreboard players set @s nw.zwerg_b 1
execute if entity @s[tag=nw.bp2] run scoreboard players set @s nw.zwerg_b 2
execute store result score #cx nw.tmp2 run data get entity @s Pos[0] 2
execute store result score #cz nw.tmp2 run data get entity @s Pos[2] 2
scoreboard players remove #cx nw.tmp2 1
scoreboard players remove #cz nw.tmp2 1
scoreboard players operation #cx nw.tmp2 /= #2 nw.const
scoreboard players operation #cz nw.tmp2 /= #2 nw.const
scoreboard players operation #cx nw.tmp2 += #cz nw.tmp2
scoreboard players operation #cx nw.tmp2 %= #2 nw.const
execute if score #cx nw.tmp2 matches 0 run setblock ~ ~ ~ minecraft:trapped_chest[facing=north,type=single]
execute if score #cx nw.tmp2 matches 1 run setblock ~ ~ ~ minecraft:trapped_chest[facing=east,type=single]
function nachtwache:zwerg/zeichnen
function nachtwache:zwerg/symbol
playsound minecraft:entity.villager.work_toolsmith neutral @a ~ ~ ~ 1 0.8
tellraw @a[distance=..12] [{"text":"Fraggle takes his place at the generator. Right-click him for his pack.","color":"aqua"}]
