tag @s add nw.zwerg
scoreboard players set @s nw.zwerg 0
scoreboard players set @s nw.zwerg_t 0
execute if entity @s[tag=nw.lvl1] run scoreboard players set @s nw.zwerg 1
execute if entity @s[tag=nw.lvl2] run scoreboard players set @s nw.zwerg 2
execute if entity @s[tag=nw.lvl3] run scoreboard players set @s nw.zwerg 3
execute if entity @s[tag=nw.lvl4] run scoreboard players set @s nw.zwerg 4
execute if entity @s[tag=nw.lvl5] run scoreboard players set @s nw.zwerg 5
execute if entity @s[tag=nw.lvl6] run scoreboard players set @s nw.zwerg 6
execute if entity @s[tag=nw.lvl7] run scoreboard players set @s nw.zwerg 7
execute if entity @s[tag=nw.lvl8] run scoreboard players set @s nw.zwerg 8
execute if entity @s[tag=nw.lvl9] run scoreboard players set @s nw.zwerg 9
execute if entity @s[tag=nw.lvl10] run scoreboard players set @s nw.zwerg 10
execute if entity @s[tag=nw.lvl11] run scoreboard players set @s nw.zwerg 11
execute if entity @s[tag=nw.lvl12] run scoreboard players set @s nw.zwerg 12
setblock ~ ~ ~ minecraft:barrel[facing=down]
$summon minecraft:item_display ~ ~ ~ {Tags:["nw.zwerg_k"],Rotation:[$(yaw)f,0f],item_display:"none",interpolation_duration:2,item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"nachtwache:dwarf_body"}}}
$summon minecraft:item_display ~ ~ ~ {Tags:["nw.zwerg_a"],Rotation:[$(yaw)f,0f],item_display:"none",interpolation_duration:2,item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"nachtwache:dwarf_arm"}}}
function nachtwache:zwerg/symbol
playsound minecraft:entity.villager.work_toolsmith neutral @a ~ ~ ~ 1 0.8
tellraw @a[distance=..12] [{"text":"Fraggle takes his place at the Source. Right-click him for his pack.","color":"aqua"}]
