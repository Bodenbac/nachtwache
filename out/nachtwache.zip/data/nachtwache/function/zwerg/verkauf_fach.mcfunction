$execute store result score #n nw.tmp run data get block ~ ~ ~ Items[{Slot:$(slot)b}].count
$data modify storage nachtwache:tmp id set string block ~ ~ ~ Items[{Slot:$(slot)b}].id 10
scoreboard players set #w nw.tmp2 0
function nachtwache:sammler/preis with storage nachtwache:tmp
execute if score #w nw.tmp2 matches ..0 run return 0
scoreboard players operation #gain nw.tmp = #n nw.tmp
scoreboard players operation #gain nw.tmp *= #w nw.tmp2
execute if score #gain nw.tmp matches ..0 run return 0
scoreboard players operation #konto nw.konto += #gain nw.tmp
scoreboard players operation #verdient nw.verdient += #gain nw.tmp
scoreboard players operation #erloes nw.tmp2 += #gain nw.tmp
$item replace block ~ ~ ~ container.$(slot) with minecraft:air
