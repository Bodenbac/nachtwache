kill @e[type=item_display,tag=nw.zwerg_k,distance=..0.1]
kill @e[type=item_display,tag=nw.zwerg_a,distance=..0.1]
execute if score @s nw.zwerg_d matches 0..7 run function nachtwache:zwerg/kaputt
setblock ~ ~ ~ minecraft:air destroy
kill @e[type=item,distance=..3.5,nbt={Item:{id:"minecraft:trapped_chest"}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_zwerg_lock:1b}}}}]
tag @s remove nw.bp1
tag @s remove nw.bp2
tag @s remove nw.bp3
tag @s add nw.bp0
scoreboard players set @s nw.zwerg_b 0
tag @s remove nw.zwerg
tag @s add nw.zwerg_neu
