clear @a[distance=..8] *[custom_data~{nw_zwerg_sell:1b}]
scoreboard players set #erloes nw.tmp2 0
execute if items block ~ ~ ~ container.0 * unless items block ~ ~ ~ container.0 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:0}
execute if items block ~ ~ ~ container.1 * unless items block ~ ~ ~ container.1 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:1}
execute if items block ~ ~ ~ container.2 * unless items block ~ ~ ~ container.2 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:2}
execute if items block ~ ~ ~ container.3 * unless items block ~ ~ ~ container.3 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:3}
execute if items block ~ ~ ~ container.4 * unless items block ~ ~ ~ container.4 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:4}
execute if items block ~ ~ ~ container.5 * unless items block ~ ~ ~ container.5 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:5}
execute if items block ~ ~ ~ container.6 * unless items block ~ ~ ~ container.6 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:6}
execute if items block ~ ~ ~ container.7 * unless items block ~ ~ ~ container.7 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:7}
execute if items block ~ ~ ~ container.8 * unless items block ~ ~ ~ container.8 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:8}
execute if items block ~ ~ ~ container.9 * unless items block ~ ~ ~ container.9 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:9}
execute if items block ~ ~ ~ container.10 * unless items block ~ ~ ~ container.10 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:10}
execute if items block ~ ~ ~ container.11 * unless items block ~ ~ ~ container.11 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:11}
execute if items block ~ ~ ~ container.12 * unless items block ~ ~ ~ container.12 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:12}
execute if items block ~ ~ ~ container.13 * unless items block ~ ~ ~ container.13 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:13}
execute if items block ~ ~ ~ container.14 * unless items block ~ ~ ~ container.14 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:14}
execute if items block ~ ~ ~ container.15 * unless items block ~ ~ ~ container.15 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:15}
execute if items block ~ ~ ~ container.16 * unless items block ~ ~ ~ container.16 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:16}
execute if items block ~ ~ ~ container.17 * unless items block ~ ~ ~ container.17 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:17}
execute if items block ~ ~ ~ container.18 * unless items block ~ ~ ~ container.18 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:18}
execute if items block ~ ~ ~ container.19 * unless items block ~ ~ ~ container.19 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:19}
execute if items block ~ ~ ~ container.20 * unless items block ~ ~ ~ container.20 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:20}
execute if items block ~ ~ ~ container.21 * unless items block ~ ~ ~ container.21 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:21}
execute if items block ~ ~ ~ container.22 * unless items block ~ ~ ~ container.22 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:22}
execute if items block ~ ~ ~ container.23 * unless items block ~ ~ ~ container.23 *[custom_data~{nw_zwerg_lock:1b}] run function nachtwache:zwerg/verkauf_fach {slot:23}
execute if score #erloes nw.tmp2 matches 1.. run playsound minecraft:entity.villager.trade neutral @a[distance=..12] ~ ~ ~ 0.8 1
execute if score #erloes nw.tmp2 matches 1.. run tellraw @a[distance=..12] [{"text":"[Fraggle] ","color":"aqua"},{"text":"Pack sold: +","color":"gray"},{"score":{"name":"#erloes","objective":"nw.tmp2"},"color":"gold"},{"text":" ","color":"gray"},{"text":"●","color":"white"}]
execute if score #erloes nw.tmp2 matches ..0 run tellraw @a[distance=..12] [{"text":"[Fraggle] ","color":"aqua"},{"text":"Nothing worth selling in here.","color":"gray"}]
function nachtwache:zwerg/symbol
