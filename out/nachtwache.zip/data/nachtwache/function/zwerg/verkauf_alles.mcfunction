clear @a[distance=..8] *[custom_data~{nw_zwerg_sell:1b}]
function nachtwache:zwerg/verkauf_kern
execute if score #erloes nw.tmp2 matches 1.. run playsound minecraft:entity.villager.trade neutral @a[distance=..12] ~ ~ ~ 0.8 1
execute if score #erloes nw.tmp2 matches 1.. run tellraw @a[distance=..12] [{"text":"[Fraggle] ","color":"aqua"},{"text":"Pack sold: +","color":"gray"},{"score":{"name":"#erloes","objective":"nw.tmp2"},"color":"gold"},{"text":" ","color":"gray"},{"text":"●","color":"white"}]
execute if score #erloes nw.tmp2 matches ..0 run tellraw @a[distance=..12] [{"text":"[Fraggle] ","color":"aqua"},{"text":"Nothing worth selling in here.","color":"gray"}]
function nachtwache:zwerg/symbol
