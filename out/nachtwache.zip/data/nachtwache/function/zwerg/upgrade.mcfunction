scoreboard players operation #lvl nw.tmp2 = @s nw.zwerg
scoreboard players operation #up nw.tmp2 = #lvl nw.tmp2
scoreboard players add #up nw.tmp2 1
scoreboard players operation #up nw.tmp2 *= #250 nw.const
execute as @a[distance=..8] store result score @s nw.tmp run clear @s *[custom_data~{nw_zwerg_up:1b}] 0
execute as @a[distance=..8,scores={nw.tmp=1..}] run function nachtwache:zwerg/upgrade_kauf
scoreboard players operation @s nw.zwerg = #lvl nw.tmp2
function nachtwache:zwerg/symbol
