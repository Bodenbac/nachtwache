scoreboard objectives add nw.mined1 minecraft.mined:minecraft.tuff
scoreboard objectives add nw.mined2 minecraft.mined:minecraft.green_concrete
scoreboard objectives add nw.mined3 minecraft.mined:minecraft.blue_concrete
scoreboard objectives add nw.mined4 minecraft.mined:minecraft.budding_amethyst
scoreboard objectives add nw.mined5 minecraft.mined:minecraft.yellow_concrete
scoreboard objectives add nw.mined6 minecraft.mined:minecraft.orange_concrete
scoreboard objectives add nw.mined7 minecraft.mined:minecraft.black_concrete
scoreboard objectives add nw.konto dummy
scoreboard objectives add nw.abbau dummy
scoreboard objectives add nw.phase dummy
scoreboard objectives add nw.nacht dummy
scoreboard objectives add nw.gegner dummy
scoreboard objectives add nw.tmp dummy
scoreboard objectives add nw.tmp2 dummy
scoreboard objectives add nw.zeit dummy
scoreboard objectives add nw.tick dummy
scoreboard objectives add nw.status dummy
scoreboard objectives add nw.kauf trigger
scoreboard objectives add nw.endlos trigger
scoreboard objectives add nw.hilfe trigger
scoreboard objectives add nw.tode deathCount
scoreboard objectives add nw.px dummy
scoreboard objectives add nw.py dummy
scoreboard objectives add nw.pz dummy
scoreboard objectives add nw.qx dummy
scoreboard objectives add nw.qy dummy
scoreboard objectives add nw.qz dummy
scoreboard objectives add nw.still dummy
scoreboard objectives add nw.kills dummy
scoreboard objectives add nw.verdient dummy
scoreboard objectives add nw.anzeige dummy
scoreboard objectives add nw.const dummy
scoreboard objectives add nw.boss dummy
scoreboard objectives add nw.upgrade dummy
scoreboard objectives add nw.laterne dummy
scoreboard objectives add nw.schlaf dummy
scoreboard objectives add nw.fest dummy
scoreboard objectives add nw.dmin dummy
scoreboard objectives modify nw.anzeige numberformat blank
scoreboard objectives modify nw.anzeige displayname {"text":"NIGHTWATCH","color":"dark_red","bold":true}
scoreboard objectives setdisplay sidebar nw.anzeige
bossbar add nw:welle "Night"
bossbar set nw:welle color red
bossbar set nw:welle style notched_10
bossbar set nw:welle visible false
bossbar add nw:uhr "Day"
bossbar set nw:uhr color green
bossbar set nw:uhr style notched_6
bossbar set nw:uhr max 13500
bossbar add nw:boss "Boss"
bossbar set nw:boss color purple
bossbar set nw:boss style progress
bossbar set nw:boss visible false
scoreboard players set #-1 nw.const -1
scoreboard players set #2 nw.const 2
scoreboard players set #3 nw.const 3
scoreboard players set #4 nw.const 4
scoreboard players set #5 nw.const 5
scoreboard players set #7 nw.const 7
scoreboard players set #10 nw.const 10
scoreboard players set #16 nw.const 16
scoreboard players set #20 nw.const 20
scoreboard players set #100 nw.const 100
scoreboard players set #200 nw.const 200
scoreboard players set #1000 nw.const 1000
scoreboard players set #6000 nw.const 6000
execute unless score #init nw.status matches 1 run function nachtwache:init
execute if score #init nw.status matches 1 unless score #version nw.status matches 10 run scoreboard players set #migrieren nw.status 1
scoreboard players set #tick nw.tick 0
scoreboard players enable @a nw.kauf
scoreboard players enable @a nw.endlos
scoreboard players enable @a nw.hilfe
tellraw @a [{"text":"[Nightwatch] ","color":"dark_red"},{"text":"Datapack loaded. ","color":"gray"},{"text":"/trigger nw.hilfe","color":"yellow","click_event":{"action":"run_command","command":"trigger nw.hilfe"}},{"text":" shows the help.","color":"gray"}]
