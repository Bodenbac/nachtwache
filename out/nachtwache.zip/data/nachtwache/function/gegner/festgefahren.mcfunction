scoreboard players set @s nw.still 0
scoreboard players set @s nw.fest 0
scoreboard players set @s nw.dmin 9999
tp @s 2.5 64 6.5
execute if entity @p run function nachtwache:gegner/zum_spieler
playsound minecraft:entity.enderman.teleport hostile @a ~ ~ ~ 0.8 0.5
