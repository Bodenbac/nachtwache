execute if score @s nw.pz matches 9.. run return run function nachtwache:gegner/zurueck_gegnerinsel
execute if entity @a run return run function nachtwache:gegner/zum_spieler
function nachtwache:gegner/zurueck_gegnerinsel
