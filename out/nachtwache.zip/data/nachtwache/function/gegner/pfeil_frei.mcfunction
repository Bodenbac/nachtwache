execute if data entity @s {inGround:1b} run return 0
execute if data entity @s {in_ground:1b} run return 0
execute unless entity @e[tag=nw.welle,distance=..5] run return 0
scoreboard players set #pj nw.tmp 0
execute if score #pj nw.tmp matches 0 positioned ^ ^ ^0.5 positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[tag=nw.welle,dx=0,dy=0,dz=0] run scoreboard players set #pj nw.tmp 1
execute if score #pj nw.tmp matches 0 positioned ^ ^ ^1.0 positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[tag=nw.welle,dx=0,dy=0,dz=0] run scoreboard players set #pj nw.tmp 2
execute if score #pj nw.tmp matches 0 positioned ^ ^ ^1.5 positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[tag=nw.welle,dx=0,dy=0,dz=0] run scoreboard players set #pj nw.tmp 3
execute if score #pj nw.tmp matches 0 positioned ^ ^ ^2.0 positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[tag=nw.welle,dx=0,dy=0,dz=0] run scoreboard players set #pj nw.tmp 4
execute if score #pj nw.tmp matches 0 positioned ^ ^ ^2.5 positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[tag=nw.welle,dx=0,dy=0,dz=0] run scoreboard players set #pj nw.tmp 5
execute if score #pj nw.tmp matches 0 positioned ^ ^ ^3.0 positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[tag=nw.welle,dx=0,dy=0,dz=0] run scoreboard players set #pj nw.tmp 6
execute if score #pj nw.tmp matches 0 run return 0
execute if score #pj nw.tmp matches 1 run return run function nachtwache:gegner/pfeil_sprung_1
execute if score #pj nw.tmp matches 2 run return run function nachtwache:gegner/pfeil_sprung_2
execute if score #pj nw.tmp matches 3 run return run function nachtwache:gegner/pfeil_sprung_3
execute if score #pj nw.tmp matches 4 run return run function nachtwache:gegner/pfeil_sprung_4
execute if score #pj nw.tmp matches 5 run return run function nachtwache:gegner/pfeil_sprung_5
execute if score #pj nw.tmp matches 6 run return run function nachtwache:gegner/pfeil_sprung_6
