execute if data entity @s {inGround:1b} run return 0
execute if data entity @s {in_ground:1b} run return 0
execute unless entity @e[tag=nw.welle,distance=..2.2] run return 0
execute if entity @a[distance=..3] run return 0
tp @s ^ ^ ^2.6
