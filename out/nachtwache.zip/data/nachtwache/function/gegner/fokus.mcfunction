scoreboard players set #bk nw.tmp2 0
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..128] run scoreboard players set #bk nw.tmp2 128
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..110] run scoreboard players set #bk nw.tmp2 110
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..88] run scoreboard players set #bk nw.tmp2 88
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..70] run scoreboard players set #bk nw.tmp2 70
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..56] run scoreboard players set #bk nw.tmp2 56
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..45] run scoreboard players set #bk nw.tmp2 45
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..36] run scoreboard players set #bk nw.tmp2 36
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..29] run scoreboard players set #bk nw.tmp2 29
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..23] run scoreboard players set #bk nw.tmp2 23
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..18] run scoreboard players set #bk nw.tmp2 18
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..14] run scoreboard players set #bk nw.tmp2 14
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..11] run scoreboard players set #bk nw.tmp2 11
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..8] run scoreboard players set #bk nw.tmp2 8
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..6] run scoreboard players set #bk nw.tmp2 6
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..4] run scoreboard players set #bk nw.tmp2 4
scoreboard players set @s nw.ziel 0
execute if score #bk nw.tmp2 matches 4 unless entity @a[distance=..5,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 5
execute if score #bk nw.tmp2 matches 4 if entity @a[distance=..5,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 4 if entity @a[distance=..5,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 6 unless entity @a[distance=..7,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 7
execute if score #bk nw.tmp2 matches 6 if entity @a[distance=..7,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 6 if entity @a[distance=..7,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 8 unless entity @a[distance=..9,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 9
execute if score #bk nw.tmp2 matches 8 if entity @a[distance=..9,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 8 if entity @a[distance=..9,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 11 unless entity @a[distance=..12,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 12
execute if score #bk nw.tmp2 matches 11 if entity @a[distance=..12,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 11 if entity @a[distance=..12,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 14 unless entity @a[distance=..15,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 15
execute if score #bk nw.tmp2 matches 14 if entity @a[distance=..15,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 14 if entity @a[distance=..15,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 18 unless entity @a[distance=..19,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 19
execute if score #bk nw.tmp2 matches 18 if entity @a[distance=..19,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 18 if entity @a[distance=..19,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 23 unless entity @a[distance=..24,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 24
execute if score #bk nw.tmp2 matches 23 if entity @a[distance=..24,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 23 if entity @a[distance=..24,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 29 unless entity @a[distance=..30,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 30
execute if score #bk nw.tmp2 matches 29 if entity @a[distance=..30,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 29 if entity @a[distance=..30,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 36 unless entity @a[distance=..37,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 37
execute if score #bk nw.tmp2 matches 36 if entity @a[distance=..37,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 36 if entity @a[distance=..37,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 45 unless entity @a[distance=..46,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 46
execute if score #bk nw.tmp2 matches 45 if entity @a[distance=..46,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 45 if entity @a[distance=..46,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 56 unless entity @a[distance=..57,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 57
execute if score #bk nw.tmp2 matches 56 if entity @a[distance=..57,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 56 if entity @a[distance=..57,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 70 unless entity @a[distance=..71,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 71
execute if score #bk nw.tmp2 matches 70 if entity @a[distance=..71,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 70 if entity @a[distance=..71,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 88 unless entity @a[distance=..89,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 89
execute if score #bk nw.tmp2 matches 88 if entity @a[distance=..89,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 88 if entity @a[distance=..89,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 110 unless entity @a[distance=..111,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 111
execute if score #bk nw.tmp2 matches 110 if entity @a[distance=..111,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 110 if entity @a[distance=..111,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 128 unless entity @a[distance=..129,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 129
execute if score #bk nw.tmp2 matches 128 if entity @a[distance=..129,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 128
execute if score #bk nw.tmp2 matches 128 if entity @a[distance=..129,gamemode=!spectator,gamemode=!creative] run scoreboard players set @s nw.ziel 1
execute if score #bk nw.tmp2 matches 0 run attribute @s minecraft:follow_range base set 128
execute if score @s nw.wut matches 1.. run attribute @s minecraft:follow_range base set 128
execute if score @s nw.wut matches 1.. run scoreboard players set @s nw.ziel 1
