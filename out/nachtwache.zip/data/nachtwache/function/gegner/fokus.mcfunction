scoreboard players set #bk nw.tmp2 0
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..40] run scoreboard players set #bk nw.tmp2 40
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..32] run scoreboard players set #bk nw.tmp2 32
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..26] run scoreboard players set #bk nw.tmp2 26
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..20] run scoreboard players set #bk nw.tmp2 20
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..16] run scoreboard players set #bk nw.tmp2 16
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..12] run scoreboard players set #bk nw.tmp2 12
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..9] run scoreboard players set #bk nw.tmp2 9
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..7] run scoreboard players set #bk nw.tmp2 7
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..5] run scoreboard players set #bk nw.tmp2 5
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..3] run scoreboard players set #bk nw.tmp2 3
execute if score #bk nw.tmp2 matches 40 unless entity @a[distance=..43,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 43
execute if score #bk nw.tmp2 matches 40 if entity @a[distance=..43,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 32 unless entity @a[distance=..35,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 35
execute if score #bk nw.tmp2 matches 32 if entity @a[distance=..35,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 26 unless entity @a[distance=..29,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 29
execute if score #bk nw.tmp2 matches 26 if entity @a[distance=..29,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 20 unless entity @a[distance=..23,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 23
execute if score #bk nw.tmp2 matches 20 if entity @a[distance=..23,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 16 unless entity @a[distance=..19,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 19
execute if score #bk nw.tmp2 matches 16 if entity @a[distance=..19,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 12 unless entity @a[distance=..15,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 15
execute if score #bk nw.tmp2 matches 12 if entity @a[distance=..15,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 9 unless entity @a[distance=..12,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 12
execute if score #bk nw.tmp2 matches 9 if entity @a[distance=..12,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 7 unless entity @a[distance=..10,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 10
execute if score #bk nw.tmp2 matches 7 if entity @a[distance=..10,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 5 unless entity @a[distance=..8,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 8
execute if score #bk nw.tmp2 matches 5 if entity @a[distance=..8,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 3 unless entity @a[distance=..6,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 6
execute if score #bk nw.tmp2 matches 3 if entity @a[distance=..6,gamemode=!spectator,gamemode=!creative] run attribute @s minecraft:follow_range base set 40
execute if score #bk nw.tmp2 matches 0 run attribute @s minecraft:follow_range base set 40
