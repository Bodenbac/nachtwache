tag @s add nw.pfeil
scoreboard players set #own nw.tmp 0
execute store success score #own nw.tmp on owner if entity @s[tag=nw.welle]
execute if score #own nw.tmp matches 0 if entity @e[tag=nw.welle,distance=..2] unless entity @a[distance=..2] run scoreboard players set #own nw.tmp 1
execute if score #own nw.tmp matches 1 run tag @s add nw.mobpfeil
