tag @s add nw.pfeil
execute if entity @e[tag=nw.welle,distance=..3] unless entity @a[distance=..5] run tag @s add nw.mobpfeil
