scoreboard players set #klasse nw.tmp 0
execute if block ~ ~ ~ #nachtwache:weich run scoreboard players set #klasse nw.tmp 1
execute if block ~ ~1 ~ #nachtwache:weich run scoreboard players set #klasse nw.tmp 1
execute if block ~ ~ ~ #nachtwache:mittel run scoreboard players set #klasse nw.tmp 2
execute if block ~ ~1 ~ #nachtwache:mittel run scoreboard players set #klasse nw.tmp 2
execute if block ~ ~ ~ #nachtwache:hart run scoreboard players set #klasse nw.tmp 3
execute if block ~ ~1 ~ #nachtwache:hart run scoreboard players set #klasse nw.tmp 3
execute if score #klasse nw.tmp matches 0 if block ~ ~ ~ minecraft:air if block ~ ~-1 ~ minecraft:air unless entity @a[distance=..2] run tp @s ^ ^0.6 ^0.4
execute if score #klasse nw.tmp matches 0 run return 0
execute if score #klasse nw.tmp matches 1 unless score @s nw.still matches 120.. run return run function nachtwache:gegner/klopfen
execute if score #klasse nw.tmp matches 2 unless score @s nw.still matches 180.. run return run function nachtwache:gegner/klopfen
execute if score #klasse nw.tmp matches 3 unless score @s nw.still matches 280.. run return run function nachtwache:gegner/klopfen
execute if block ~ ~ ~ #nachtwache:grabbar run setblock ~ ~ ~ minecraft:air destroy
execute if block ~ ~1 ~ #nachtwache:grabbar run setblock ~ ~1 ~ minecraft:air destroy
execute if entity @s[tag=nw.boss_koloss] if block ~ ~2 ~ #nachtwache:grabbar run setblock ~ ~2 ~ minecraft:air destroy
execute if entity @s[tag=nw.boss_koloss] if block ^1 ^ ^0 #nachtwache:grabbar run setblock ^1 ^ ^0 minecraft:air destroy
execute if entity @s[tag=nw.boss_koloss] if block ^1 ^1 ^0 #nachtwache:grabbar run setblock ^1 ^1 ^0 minecraft:air destroy
execute if entity @s[tag=nw.boss_koloss] if block ^1 ^2 ^0 #nachtwache:grabbar run setblock ^1 ^2 ^0 minecraft:air destroy
execute if entity @s[tag=nw.boss_koloss] if block ^-1 ^ ^0 #nachtwache:grabbar run setblock ^-1 ^ ^0 minecraft:air destroy
execute if entity @s[tag=nw.boss_koloss] if block ^-1 ^1 ^0 #nachtwache:grabbar run setblock ^-1 ^1 ^0 minecraft:air destroy
execute if entity @s[tag=nw.boss_koloss] if block ^-1 ^2 ^0 #nachtwache:grabbar run setblock ^-1 ^2 ^0 minecraft:air destroy
playsound minecraft:block.stone.break hostile @a ~ ~ ~ 1 0.5
playsound minecraft:entity.zombie.break_wooden_door hostile @a ~ ~ ~ 0.6 0.6
scoreboard players set @s nw.still 60
