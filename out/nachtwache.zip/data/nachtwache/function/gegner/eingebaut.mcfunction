execute facing entity @p feet rotated ~ 0 positioned ^ ^ ^1 unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ #nachtwache:grabbar run function nachtwache:gegner/festgefahren
