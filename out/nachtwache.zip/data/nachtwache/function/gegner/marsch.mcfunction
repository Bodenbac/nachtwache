execute if score @s nw.ziel matches 1 run return run function nachtwache:gegner/marsch_spieler
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..6] run return 0
execute if score @s nw.pz matches 63.. run return run function nachtwache:gegner/marsch_tor
function nachtwache:gegner/marsch_ziel
