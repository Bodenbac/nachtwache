execute if score @s nw.sockel matches 1 run return 0
execute if entity @s[tag=nw.bosstrupp] run return run function nachtwache:gegner/marsch_spieler
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..6] unless score @s nw.wut matches 1.. run return run function nachtwache:gegner/marsch_ziel
execute if score @s nw.ziel matches 1 run return run function nachtwache:gegner/marsch_spieler
execute if score @s nw.pz matches 63.. run return run function nachtwache:gegner/marsch_tor
function nachtwache:gegner/marsch_ziel
