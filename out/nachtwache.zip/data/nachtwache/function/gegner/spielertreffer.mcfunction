advancement revoke @s only nachtwache:gegner_getroffen
scoreboard players set #treffer nw.status 2
