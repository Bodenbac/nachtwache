execute store result score @s nw.hpv run data get entity @s Health
execute if score @s nw.hpv < @s nw.hpp run scoreboard players set @s nw.chan 0
scoreboard players operation @s nw.hpp = @s nw.hpv
execute unless entity @s[x=0.5,y=64.5,z=-16.5,distance=..3.5] run scoreboard players set @s nw.chan 0
execute if entity @s[x=0.5,y=64.5,z=-16.5,distance=..3.5] run scoreboard players add @s nw.chan 1
execute if score @s nw.chan matches 1.. if score #m20 nw.tmp matches 0 at @s run particle minecraft:dust{color:[1.0,0.2,0.2],scale:1.0} ~ ~1 ~ 0.3 0.5 0.3 0 6
execute if score @s nw.chan matches 100.. run return run function nachtwache:gegner/durchbruch
execute store result score @s nw.px run data get entity @s Pos[0]
execute store result score @s nw.py run data get entity @s Pos[1]
execute store result score @s nw.pz run data get entity @s Pos[2]
execute if score @s nw.py matches ..55 run return run function nachtwache:gegner/festgefahren
scoreboard players add @s nw.still 1
execute unless score @s nw.px = @s nw.qx run scoreboard players set @s nw.still 0
execute unless score @s nw.py = @s nw.qy run scoreboard players set @s nw.still 0
execute unless score @s nw.pz = @s nw.qz run scoreboard players set @s nw.still 0
scoreboard players operation @s nw.qx = @s nw.px
scoreboard players operation @s nw.qy = @s nw.py
scoreboard players operation @s nw.qz = @s nw.pz
execute if score @s nw.still matches 600.. run function nachtwache:gegner/eingebaut
execute if score @s nw.still matches 80.. run function nachtwache:gegner/blockiert
execute if score #m20 nw.tmp matches 3 run function nachtwache:gegner/fokus
function nachtwache:gegner/marsch
