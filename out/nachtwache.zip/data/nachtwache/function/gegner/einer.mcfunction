execute store result score @s nw.px run data get entity @s Pos[0]
execute store result score @s nw.py run data get entity @s Pos[1]
execute store result score @s nw.pz run data get entity @s Pos[2]
execute if score @s nw.py matches ..55 run return run function nachtwache:gegner/festgefahren
scoreboard players add @s nw.still 1
execute unless score @s nw.px = @s nw.qx run scoreboard players set @s nw.still 0
execute unless score @s nw.py = @s nw.qy run scoreboard players set @s nw.still 0
execute unless score @s nw.pz = @s nw.qz run scoreboard players set @s nw.still 0
scoreboard players operation @s nw.qx = @s nw.px
scoreboard players operation @s nw.qy = @s nw.py
scoreboard players operation @s nw.qz = @s nw.pz
execute if score @s nw.still matches 600.. if entity @a run function nachtwache:gegner/eingebaut
execute if score @s nw.still matches 80.. if entity @a run function nachtwache:gegner/blockiert
