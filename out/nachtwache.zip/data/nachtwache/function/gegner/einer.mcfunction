execute store result score @s nw.px run data get entity @s Pos[0]
execute store result score @s nw.py run data get entity @s Pos[1]
execute store result score @s nw.pz run data get entity @s Pos[2]
execute if score @s nw.py matches ..55 run return run function nachtwache:gegner/festgefahren
scoreboard players add @s nw.still 1
execute unless score @s nw.px = @s nw.qx run scoreboard players set @s nw.still 0
execute unless score @s nw.py = @s nw.qy run scoreboard players set @s nw.still 0
execute unless score @s nw.pz = @s nw.qz run scoreboard players set @s nw.still 0
scoreboard players operation @s nw.qx = @s nw.px
scoreboard players operation @s nw.qy = @s nw.py
scoreboard players operation @s nw.qz = @s nw.pz
execute store result score #ppx nw.tmp run data get entity @p Pos[0]
execute store result score #ppy nw.tmp run data get entity @p Pos[1]
execute store result score #ppz nw.tmp run data get entity @p Pos[2]
scoreboard players operation #ppx nw.tmp -= @s nw.px
scoreboard players operation #ppy nw.tmp -= @s nw.py
scoreboard players operation #ppz nw.tmp -= @s nw.pz
execute if score #ppx nw.tmp matches ..-1 run scoreboard players operation #ppx nw.tmp *= #-1 nw.const
execute if score #ppy nw.tmp matches ..-1 run scoreboard players operation #ppy nw.tmp *= #-1 nw.const
execute if score #ppz nw.tmp matches ..-1 run scoreboard players operation #ppz nw.tmp *= #-1 nw.const
scoreboard players operation #ppx nw.tmp += #ppy nw.tmp
scoreboard players operation #ppx nw.tmp += #ppz nw.tmp
execute unless score @s nw.dmin matches 0.. run scoreboard players set @s nw.dmin 9999
execute if score #ppx nw.tmp < @s nw.dmin run scoreboard players operation @s nw.dmin = #ppx nw.tmp
execute if score #ppx nw.tmp < @s nw.dmin run scoreboard players set @s nw.fest 0
execute unless score #ppx nw.tmp < @s nw.dmin run scoreboard players add @s nw.fest 1
execute if score #ppx nw.tmp matches ..3 run scoreboard players set @s nw.fest 0
execute if score @s nw.fest matches 400.. run return run function nachtwache:gegner/festgefahren
execute if score @s nw.still matches 80.. if entity @a run function nachtwache:gegner/blockiert
