execute store result score @s nw.hpv run data get entity @s Health
execute if score @s nw.hpv < @s nw.hpp if score #treffer nw.status matches 1.. run scoreboard players set @s nw.chan 0
execute if score @s nw.hpv < @s nw.hpp if score #treffer nw.status matches 1.. run scoreboard players set @s nw.wut 200
scoreboard players operation @s nw.hpp = @s nw.hpv
execute if score @s nw.wut matches 1.. run scoreboard players remove @s nw.wut 1
scoreboard players set @s nw.sockel 0
execute at @s if block ~ ~-1 ~ minecraft:iron_block if entity @s[x=0.5,y=64,z=-16.5,distance=..3] run scoreboard players set @s nw.sockel 1
execute if score @s nw.sockel matches 0 run scoreboard players set @s nw.chan 0
execute if score @s nw.sockel matches 1 unless score @s nw.wut matches 1.. run scoreboard players add @s nw.chan 1
execute if score @s nw.chan matches 1.. if score #m20 nw.tmp matches 0 at @s run particle minecraft:dust{color:[1.0,0.2,0.2],scale:1.0} ~ ~1 ~ 0.3 0.5 0.3 0 6
execute if score @s nw.chan matches 1.. run team join nw_chan @s
execute if score @s nw.chan matches 1.. run effect give @s minecraft:glowing 2 0 true
execute if score @s nw.chan matches ..0 run team leave @s
execute if score @s nw.chan matches ..0 run effect clear @s minecraft:glowing
execute if score @s nw.chan matches 1.. run scoreboard players set @s nw.still 0
execute if score @s nw.chan matches 100.. run return run function nachtwache:gegner/durchbruch
execute store result score @s nw.px run data get entity @s Pos[0]
execute store result score @s nw.py run data get entity @s Pos[1]
execute store result score @s nw.pz run data get entity @s Pos[2]
execute if score @s nw.py matches ..55 run return run function nachtwache:gegner/festgefahren
scoreboard players add @s nw.still 1
execute unless score @s nw.px = @s nw.qx run scoreboard players set @s nw.still 0
execute unless score @s nw.py = @s nw.qy run scoreboard players set @s nw.still 0
execute unless score @s nw.pz = @s nw.qz run scoreboard players set @s nw.still 0
scoreboard players operation @s nw.qx = @s nw.px
scoreboard players operation @s nw.qy = @s nw.py
scoreboard players operation @s nw.qz = @s nw.pz
execute if score @s nw.still matches 600.. run function nachtwache:gegner/eingebaut
execute if score @s nw.still matches 80.. run function nachtwache:gegner/blockiert
execute if score #m20 nw.tmp matches 3 run function nachtwache:gegner/fokus
function nachtwache:gegner/marsch
