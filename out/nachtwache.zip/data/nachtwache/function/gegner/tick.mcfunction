execute store result score #gegner nw.gegner if entity @e[tag=nw.welle]
execute store result bossbar nw:welle value run scoreboard players get #gegner nw.gegner
execute unless score #gegner nw.gegner = #gegner_prev nw.gegner run bossbar set nw:welle name [{"text":"Night ","color":"red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"red"},{"text":":  ","color":"red"},{"score":{"name":"#gegner","objective":"nw.gegner"},"color":"white"},{"text":" enemies","color":"red"}]
execute unless score #gegner nw.gegner = #gegner_prev nw.gegner if score #kontrakt nw.upgrade matches 2 run bossbar set nw:welle name [{"text":"Night ","color":"red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"red"},{"text":":  ","color":"red"},{"score":{"name":"#gegner","objective":"nw.gegner"},"color":"white"},{"text":" enemies  ","color":"red"},{"text":"★","color":"white"}]
execute if score #gegner nw.gegner matches 0 if score #status nw.status matches 0 run bossbar set nw:welle visible false
scoreboard players operation #gegner_prev nw.gegner = #gegner nw.gegner
execute if score #m20 nw.tmp matches 3 if score #status nw.status matches 1 run bossbar set nw:welle players @a
execute store result score #c_zombie nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_zombie,tag=!nw.boss]
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 run scoreboard players operation #d nw.tmp = #p_zombie nw.tmp2
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_zombie nw.tmp2
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 run scoreboard players set #kg nw.tmp 6
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_zombie nw.tmp2 < #p_zombie nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_zombie nw.tmp2 = #c_zombie nw.tmp2
execute store result score #c_zombie_baby nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_zombie_baby,tag=!nw.boss]
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 run scoreboard players operation #d nw.tmp = #p_zombie_baby nw.tmp2
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_zombie_baby nw.tmp2
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 run scoreboard players set #kg nw.tmp 20
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_zombie_baby nw.tmp2 < #p_zombie_baby nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_zombie_baby nw.tmp2 = #c_zombie_baby nw.tmp2
execute store result score #c_zombie_leder nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_zombie_leder,tag=!nw.boss]
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 run scoreboard players operation #d nw.tmp = #p_zombie_leder nw.tmp2
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_zombie_leder nw.tmp2
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 run scoreboard players set #kg nw.tmp 9
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_zombie_leder nw.tmp2 < #p_zombie_leder nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_zombie_leder nw.tmp2 = #c_zombie_leder nw.tmp2
execute store result score #c_zombie_eisen nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_zombie_eisen,tag=!nw.boss]
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 run scoreboard players operation #d nw.tmp = #p_zombie_eisen nw.tmp2
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_zombie_eisen nw.tmp2
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 run scoreboard players set #kg nw.tmp 14
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_zombie_eisen nw.tmp2 < #p_zombie_eisen nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_zombie_eisen nw.tmp2 = #c_zombie_eisen nw.tmp2
execute store result score #c_husk nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_husk,tag=!nw.boss]
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 run scoreboard players operation #d nw.tmp = #p_husk nw.tmp2
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_husk nw.tmp2
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 run scoreboard players set #kg nw.tmp 6
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_husk nw.tmp2 < #p_husk nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_husk nw.tmp2 = #c_husk nw.tmp2
execute store result score #c_brutalo nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_brutalo,tag=!nw.boss]
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 run scoreboard players operation #d nw.tmp = #p_brutalo nw.tmp2
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_brutalo nw.tmp2
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 run scoreboard players set #kg nw.tmp 25
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_brutalo nw.tmp2 < #p_brutalo nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_brutalo nw.tmp2 = #c_brutalo nw.tmp2
execute store result score #c_skeleton nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_skeleton,tag=!nw.boss]
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 run scoreboard players operation #d nw.tmp = #p_skeleton nw.tmp2
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_skeleton nw.tmp2
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 run scoreboard players set #kg nw.tmp 9
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_skeleton nw.tmp2 < #p_skeleton nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_skeleton nw.tmp2 = #c_skeleton nw.tmp2
execute store result score #c_spider nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_spider,tag=!nw.boss]
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 run scoreboard players operation #d nw.tmp = #p_spider nw.tmp2
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_spider nw.tmp2
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 run scoreboard players set #kg nw.tmp 6
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_spider nw.tmp2 < #p_spider nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_spider nw.tmp2 = #c_spider nw.tmp2
execute store result score #c_cave_spider nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_cave_spider,tag=!nw.boss]
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 run scoreboard players operation #d nw.tmp = #p_cave_spider nw.tmp2
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_cave_spider nw.tmp2
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 run scoreboard players set #kg nw.tmp 4
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_cave_spider nw.tmp2 < #p_cave_spider nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_cave_spider nw.tmp2 = #c_cave_spider nw.tmp2
execute store result score #c_enderman nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_enderman,tag=!nw.boss]
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 run scoreboard players operation #d nw.tmp = #p_enderman nw.tmp2
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_enderman nw.tmp2
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 run scoreboard players set #kg nw.tmp 30
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_enderman nw.tmp2 < #p_enderman nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_enderman nw.tmp2 = #c_enderman nw.tmp2
execute store result score #c_witch nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_witch,tag=!nw.boss]
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 run scoreboard players operation #d nw.tmp = #p_witch nw.tmp2
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_witch nw.tmp2
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 run scoreboard players set #kg nw.tmp 18
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_witch nw.tmp2 < #p_witch nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_witch nw.tmp2 = #c_witch nw.tmp2
execute store result score #c_wither_skeleton nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_wither_skeleton,tag=!nw.boss]
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 run scoreboard players operation #d nw.tmp = #p_wither_skeleton nw.tmp2
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_wither_skeleton nw.tmp2
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 run scoreboard players set #kg nw.tmp 18
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_wither_skeleton nw.tmp2 < #p_wither_skeleton nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_wither_skeleton nw.tmp2 = #c_wither_skeleton nw.tmp2
execute store result score #c_pillager nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_pillager,tag=!nw.boss]
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 run scoreboard players operation #d nw.tmp = #p_pillager nw.tmp2
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_pillager nw.tmp2
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 run scoreboard players set #kg nw.tmp 15
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_pillager nw.tmp2 < #p_pillager nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_pillager nw.tmp2 = #c_pillager nw.tmp2
execute store result score #c_ravager nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_ravager,tag=!nw.boss]
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 run scoreboard players operation #d nw.tmp = #p_ravager nw.tmp2
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_ravager nw.tmp2
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 run scoreboard players set #kg nw.tmp 45
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_ravager nw.tmp2 < #p_ravager nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_ravager nw.tmp2 = #c_ravager nw.tmp2
execute store result score #c_zpiglin nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_zpiglin,tag=!nw.boss]
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 run scoreboard players operation #d nw.tmp = #p_zpiglin nw.tmp2
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_zpiglin nw.tmp2
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 run scoreboard players set #kg nw.tmp 0
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_zpiglin nw.tmp2 < #p_zpiglin nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_zpiglin nw.tmp2 = #c_zpiglin nw.tmp2
execute store result score #c_magma nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_magma,tag=!nw.boss]
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 run scoreboard players operation #d nw.tmp = #p_magma nw.tmp2
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_magma nw.tmp2
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 run scoreboard players set #kg nw.tmp 0
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_magma nw.tmp2 < #p_magma nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_magma nw.tmp2 = #c_magma nw.tmp2
execute store result score #c_blaze nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_blaze,tag=!nw.boss]
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 run scoreboard players operation #d nw.tmp = #p_blaze nw.tmp2
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_blaze nw.tmp2
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 run scoreboard players set #kg nw.tmp 0
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_blaze nw.tmp2 < #p_blaze nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_blaze nw.tmp2 = #c_blaze nw.tmp2
execute store result score #c_ghast nw.tmp2 if entity @e[tag=nw.welle,tag=nw.a_ghast,tag=!nw.boss]
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 run scoreboard players operation #d nw.tmp = #p_ghast nw.tmp2
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 run scoreboard players operation #d nw.tmp -= #c_ghast nw.tmp2
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 run scoreboard players operation #kills nw.kills += #d nw.tmp
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 run scoreboard players set #kg nw.tmp 0
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 if score #welt nw.status matches 1 run scoreboard players set #kg nw.tmp 0
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 run scoreboard players operation #d nw.tmp *= #kg nw.tmp
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 run scoreboard players operation #konto nw.konto += #d nw.tmp
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 run scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #c_ghast nw.tmp2 < #p_ghast nw.tmp2 unless score #d nw.tmp matches 0 run title @a actionbar [{"text":"Bounty +","color":"gold"},{"score":{"name":"#d","objective":"nw.tmp"},"color":"gold"}]
scoreboard players operation #p_ghast nw.tmp2 = #c_ghast nw.tmp2
execute if score #treffer nw.status matches 1.. run scoreboard players remove #treffer nw.status 1
execute as @e[tag=nw.welle] at @s run function nachtwache:gegner/einer
execute if score #glocke nw.upgrade matches 1 if score #glocke_geklingelt nw.upgrade matches 0 if entity @e[tag=nw.welle,x=-4,y=55,z=9,dx=8,dy=20,dz=25] run function nachtwache:gegner/glocke
