scoreboard players set #glocke_geklingelt nw.upgrade 1
playsound minecraft:block.bell.use block @a ~ ~ ~ 2 0.7
playsound minecraft:block.bell.resonate block @a ~ ~ ~ 2 0.7
tellraw @a [{"text":"The watch bell rings. Something is on the road.","color":"red"}]
