execute if entity @p[gamemode=!spectator,gamemode=!creative,distance=..1.6] run return 1
execute unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:short_grass unless block ~ ~ ~ minecraft:tall_grass run return 0
scoreboard players remove #sicht nw.tmp 1
execute if score #sicht nw.tmp matches ..0 run return 0
execute positioned ^ ^ ^1 run return run function nachtwache:gegner/sicht
