execute if entity @a[distance=..12,gamemode=!spectator,gamemode=!creative] run return 0
execute unless entity @a[distance=..200,gamemode=!spectator,gamemode=!creative] run return 0
execute facing entity @p[gamemode=!spectator,gamemode=!creative] feet rotated ~ 0 if block ^ ^ ^1 minecraft:air if block ^ ^1 ^1 minecraft:air run tp @s ^ ^ ^0.11 ~ ~
