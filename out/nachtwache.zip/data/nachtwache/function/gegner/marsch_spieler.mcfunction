execute if entity @a[distance=..12,gamemode=!spectator,gamemode=!creative] run return 0
execute unless entity @a[distance=..200,gamemode=!spectator,gamemode=!creative] run return 0
execute facing entity @p[gamemode=!spectator,gamemode=!creative] feet rotated ~ 0 if block ^0 ^0 ^1 #nachtwache:begehbar if block ^0.4 ^0 ^1 #nachtwache:begehbar if block ^-0.4 ^0 ^1 #nachtwache:begehbar if block ^0 ^1 ^1 #nachtwache:begehbar if block ^0.4 ^1 ^1 #nachtwache:begehbar if block ^-0.4 ^1 ^1 #nachtwache:begehbar run tp @s ^ ^ ^0.11 ~ ~
