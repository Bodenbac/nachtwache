execute unless entity @e[type=#nachtwache:neutral,tag=nw.welle] run return 0
execute store result score #t nw.tmp2 run time query gametime
scoreboard players add #t nw.tmp2 600
execute as @e[type=#nachtwache:neutral,tag=nw.welle] at @s if entity @p run data modify entity @s angry_at set from entity @p UUID
execute as @e[type=#nachtwache:neutral,tag=nw.welle] store result entity @s anger_end_time long 1 run scoreboard players get #t nw.tmp2
