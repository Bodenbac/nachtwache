execute at @s run particle minecraft:soul ~ ~1 ~ 0.3 0.5 0.3 0.05 30
execute at @s run playsound minecraft:entity.evoker.cast_spell hostile @a ~ ~ ~ 1 0.5
execute if entity @s[tag=nw.boss] run scoreboard players set #boss nw.boss 0
execute if entity @s[tag=nw.boss] run bossbar set nw:boss visible false
execute if entity @s[tag=nw.boss] run tellraw @a [{"text":"The boss reached the beacon. ","color":"dark_purple"},{"text":"No bounty.","color":"gray"}]
kill @s
function nachtwache:gegner/vergessen
function nachtwache:beacon/verlust
