execute at @s run particle minecraft:soul ~ ~1 ~ 0.3 0.5 0.3 0.05 30
execute at @s run playsound minecraft:entity.evoker.cast_spell hostile @a ~ ~ ~ 1 0.5
kill @s
function nachtwache:gegner/vergessen
function nachtwache:beacon/verlust
