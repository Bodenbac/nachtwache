execute positioned ^ ^ ^0.5 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
execute positioned ^ ^ ^1.0 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
execute positioned ^ ^ ^1.5 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
execute positioned ^ ^ ^2.0 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
execute positioned ^ ^ ^2.5 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
execute positioned ^ ^ ^3.0 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
execute positioned ^ ^ ^3.5 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
execute positioned ^ ^ ^4.0 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
execute positioned ^ ^ ^4.5 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
execute positioned ^ ^ ^4.8 positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0] run return 0
tp @s ^ ^ ^4.8
