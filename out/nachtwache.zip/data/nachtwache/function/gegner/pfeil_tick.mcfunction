execute as @e[type=arrow,tag=!nw.pfeil] at @s run function nachtwache:gegner/pfeil_neu
execute as @e[type=arrow,tag=nw.mobpfeil] at @s run function nachtwache:gegner/pfeil_frei
