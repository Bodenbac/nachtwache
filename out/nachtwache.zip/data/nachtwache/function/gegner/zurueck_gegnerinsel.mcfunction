tp @s 0.5 64 67.5
scoreboard players set @s nw.still 0
execute at @s run particle minecraft:portal ~ ~1 ~ 0.5 1 0.5 0.5 40
