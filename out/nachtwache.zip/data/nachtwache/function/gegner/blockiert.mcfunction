execute if score @s nw.ziel matches 1 facing entity @p feet rotated ~ 0 positioned ^ ^ ^1 run return run function nachtwache:gegner/graben
execute unless score @s nw.ziel matches 1 facing 0.5 64.5 -16.5 rotated ~ 0 positioned ^ ^ ^1 run function nachtwache:gegner/graben
