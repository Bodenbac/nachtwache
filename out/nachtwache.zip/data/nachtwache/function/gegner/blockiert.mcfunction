execute facing entity @p feet rotated ~ 0 positioned ^ ^ ^1 run function nachtwache:gegner/graben
