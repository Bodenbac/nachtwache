execute if entity @a[distance=..12,gamemode=!spectator,gamemode=!creative] run return 0
execute facing 0.5 64.5 6.5 rotated ~ 0 run function nachtwache:gegner/schritt
