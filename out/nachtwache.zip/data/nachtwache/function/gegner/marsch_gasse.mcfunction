execute if entity @a[distance=..12,gamemode=!spectator,gamemode=!creative] run return 0
execute facing 0.5 64.5 6.5 rotated ~ 0 if block ^0 ^0 ^1 minecraft:air if block ^0.4 ^0 ^1 minecraft:air if block ^-0.4 ^0 ^1 minecraft:air if block ^0 ^1 ^1 minecraft:air if block ^0.4 ^1 ^1 minecraft:air if block ^-0.4 ^1 ^1 minecraft:air run tp @s ^ ^ ^0.11 ~ ~
