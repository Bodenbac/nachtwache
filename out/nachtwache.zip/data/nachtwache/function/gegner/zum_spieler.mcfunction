execute at @p run spreadplayers ~ ~ 2 4 under 320 false @s
execute at @s run particle minecraft:portal ~ ~1 ~ 0.5 1 0.5 0.5 40
