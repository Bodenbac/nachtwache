execute at @p rotated ~ 0 positioned ^ ^ ^13 run spreadplayers ~ ~ 0 3 under 320 false @s
execute if entity @s[x=0.5,y=64,z=6.5,distance=..1.5] at @p rotated ~45 0 positioned ^ ^ ^13 run spreadplayers ~ ~ 0 3 under 320 false @s
execute if entity @s[x=0.5,y=64,z=6.5,distance=..1.5] at @p rotated ~-45 0 positioned ^ ^ ^13 run spreadplayers ~ ~ 0 3 under 320 false @s
execute if entity @s[x=0.5,y=64,z=6.5,distance=..1.5] at @p rotated ~90 0 positioned ^ ^ ^13 run spreadplayers ~ ~ 0 3 under 320 false @s
execute if entity @s[x=0.5,y=64,z=6.5,distance=..1.5] at @p rotated ~-90 0 positioned ^ ^ ^13 run spreadplayers ~ ~ 0 3 under 320 false @s
execute if entity @s[x=0.5,y=64,z=6.5,distance=..1.5] at @p rotated ~135 0 positioned ^ ^ ^13 run spreadplayers ~ ~ 0 3 under 320 false @s
execute if entity @s[x=0.5,y=64,z=6.5,distance=..1.5] at @p rotated ~-135 0 positioned ^ ^ ^13 run spreadplayers ~ ~ 0 3 under 320 false @s
execute if entity @s[x=0.5,y=64,z=6.5,distance=..1.5] at @p rotated ~180 0 positioned ^ ^ ^13 run spreadplayers ~ ~ 0 3 under 320 false @s
execute if entity @s[x=0.5,y=64,z=6.5,distance=..1.5] at @s if entity @p[distance=..8] at @p rotated ~180 0 positioned ^ ^ ^5 run spreadplayers ~ ~ 0 2 under 320 false @s
execute at @s run particle minecraft:portal ~ ~1 ~ 0.5 1 0.5 0.5 40
