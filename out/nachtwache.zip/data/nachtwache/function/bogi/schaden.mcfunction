$damage @s $(dmg) minecraft:arrow
