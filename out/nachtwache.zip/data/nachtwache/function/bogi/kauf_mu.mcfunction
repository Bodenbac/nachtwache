scoreboard players operation #bs nw.tmp2 = @s nw.b_mu
execute if score #bs nw.tmp2 matches 0 run scoreboard players set #bp nw.tmp2 2000
execute if score #bs nw.tmp2 matches 1 run scoreboard players set #bp nw.tmp2 4000
execute as @a[distance=..8] store result score @s nw.tmp run clear @s *[custom_data~{nw_bogi_mu:1b}] 0
execute as @a[distance=..8,scores={nw.tmp=1..}] run function nachtwache:bogi/kauf_mu_ab
scoreboard players operation @s nw.b_mu = #bs nw.tmp2
execute store result entity @s data.mu int 1 run scoreboard players get #bs nw.tmp2
function nachtwache:bogi/symbol
