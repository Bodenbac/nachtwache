kill @e[type=item,distance=..2.0]
setblock ~ ~ ~ minecraft:trapped_chest[facing=north,type=single]
execute unless block ~ ~ ~ minecraft:trapped_chest[type=single] run setblock ~ ~ ~ minecraft:trapped_chest[facing=east,type=single]
execute unless block ~ ~ ~ minecraft:trapped_chest[type=single] run setblock ~ ~ ~ minecraft:trapped_chest[facing=south,type=single]
execute unless block ~ ~ ~ minecraft:trapped_chest[type=single] run setblock ~ ~ ~ minecraft:trapped_chest[facing=west,type=single]
execute if data entity @s data.inv run data modify block ~ ~ ~ Items set from entity @s data.inv
function nachtwache:bogi/symbol
