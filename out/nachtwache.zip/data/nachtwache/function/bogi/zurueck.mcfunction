data modify storage nachtwache:tmp sp set from entity @s data.sp
data modify storage nachtwache:tmp st set from entity @s data.st
data modify storage nachtwache:tmp mu set from entity @s data.mu
data modify storage nachtwache:tmp fl set from entity @s data.fl
data modify storage nachtwache:tmp inf set from entity @s data.inf
data modify storage nachtwache:tmp kb set from entity @s data.kb
data modify storage nachtwache:tmp rg set from entity @s data.rg
data modify storage nachtwache:tmp nm set from entity @s data.nm
data modify storage nachtwache:tmp inv set value []
execute if data entity @s data.inv run data modify storage nachtwache:tmp inv set from entity @s data.inv
execute store result score #bnm nw.tmp2 run data get entity @s data.nm
execute as @p[distance=..10] run function nachtwache:bogi/geben
tellraw @p[distance=..10] [{"text":"[Bogi] ","color":"green"},{"text":"Put me on a free block, on solid ground.","color":"gray"}]
kill @s
