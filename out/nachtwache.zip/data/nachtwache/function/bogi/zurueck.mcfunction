execute as @p[distance=..10] run function nachtwache:bogi/geben
tellraw @p[distance=..10] [{"text":"[Bogi] ","color":"green"},{"text":"Put me on a free block, on solid ground.","color":"gray"}]
kill @s
