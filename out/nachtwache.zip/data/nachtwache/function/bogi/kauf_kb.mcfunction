scoreboard players operation #bs nw.tmp2 = @s nw.b_kb
execute if score #bs nw.tmp2 matches 0 run scoreboard players set #bp nw.tmp2 800
execute if score #bs nw.tmp2 matches 1 run scoreboard players set #bp nw.tmp2 1600
execute as @a[distance=..8] store result score @s nw.tmp run clear @s *[custom_data~{nw_bogi_kb:1b}] 0
execute as @a[distance=..8,scores={nw.tmp=1..}] run function nachtwache:bogi/kauf_kb_ab
scoreboard players operation @s nw.b_kb = #bs nw.tmp2
execute store result entity @s data.kb int 1 run scoreboard players get #bs nw.tmp2
function nachtwache:bogi/symbol
