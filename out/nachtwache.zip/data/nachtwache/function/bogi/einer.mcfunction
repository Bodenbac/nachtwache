execute unless block ~ ~ ~ minecraft:trapped_chest run return run function nachtwache:bogi/kaputt
scoreboard players add @s nw.b_t 1
scoreboard players operation #bt nw.tmp2 = @s nw.b_sp
scoreboard players operation #bt nw.tmp2 *= #10 nw.const
scoreboard players set #btakt nw.tmp2 60
scoreboard players operation #btakt nw.tmp2 -= #bt nw.tmp2
execute if score @s nw.b_t >= #btakt nw.tmp2 run function nachtwache:bogi/schuss
execute if score @s nw.b_t matches 5 as @e[type=item_display,tag=nw.bogi_a,distance=..0.1] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{left_rotation:[0.0f,0f,0f,1.0f],translation:[0f,0.0f,0.0f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
execute unless items block ~ ~ ~ container.8 *[custom_data~{nw_bogi_sp:1b}] run function nachtwache:bogi/kauf_sp
execute unless items block ~ ~ ~ container.7 *[custom_data~{nw_bogi_st:1b}] run function nachtwache:bogi/kauf_st
execute unless items block ~ ~ ~ container.6 *[custom_data~{nw_bogi_mu:1b}] run function nachtwache:bogi/kauf_mu
execute unless items block ~ ~ ~ container.5 *[custom_data~{nw_bogi_fl:1b}] run function nachtwache:bogi/kauf_fl
execute unless items block ~ ~ ~ container.4 *[custom_data~{nw_bogi_inf:1b}] run function nachtwache:bogi/kauf_inf
execute unless items block ~ ~ ~ container.3 *[custom_data~{nw_bogi_kb:1b}] run function nachtwache:bogi/kauf_kb
execute unless items block ~ ~ ~ container.2 *[custom_data~{nw_bogi_rg:1b}] run function nachtwache:bogi/kauf_rg
execute unless items block ~ ~ ~ container.26 * run function nachtwache:bogi/mitnehmen
clear @a[distance=..8] *[custom_data~{nw_bogi_lock:1b}]
execute if score #m20 nw.tmp matches 13 run function nachtwache:bogi/symbol
execute if score #m20 nw.tmp matches 15 run function nachtwache:bogi/merken
