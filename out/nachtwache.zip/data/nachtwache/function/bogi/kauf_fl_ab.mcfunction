clear @s *[custom_data~{nw_bogi_fl:1b}]
execute if score #bs nw.tmp2 matches 1.. run return run tellraw @s [{"text":"[Bogi] ","color":"green"},{"text":"That one is already at its best.","color":"gray"}]
execute if score #konto nw.konto < #bp nw.tmp2 run tellraw @s [{"text":"[Bogi] ","color":"green"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#bp","objective":"nw.tmp2"},"color":"gold"},{"text":" needed.","color":"gray"}]
execute if score #konto nw.konto < #bp nw.tmp2 run return run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
scoreboard players operation #konto nw.konto -= #bp nw.tmp2
scoreboard players add #bs nw.tmp2 1
playsound minecraft:block.smithing_table.use block @s ~ ~ ~ 0.8 1.2
tellraw @s [{"text":"[Bogi] ","color":"green"},{"text":"Flame improved.","color":"gray"}]
