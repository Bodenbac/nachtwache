kill @e[type=item_display,tag=nw.bogi_k,distance=..0.1]
kill @e[type=item_display,tag=nw.bogi_a,distance=..0.1]
kill @e[type=item,distance=..2.0]
kill @e[type=item,distance=..2.5,nbt={Item:{id:"minecraft:trapped_chest"}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_bogi_lock:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_bogi_sp:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_bogi_st:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_bogi_mu:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_bogi_fl:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_bogi_inf:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_bogi_kb:1b}}}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_bogi_rg:1b}}}}]
execute store result storage nachtwache:tmp sp int 1 run scoreboard players get @s nw.b_sp
execute store result storage nachtwache:tmp st int 1 run scoreboard players get @s nw.b_st
execute store result storage nachtwache:tmp mu int 1 run scoreboard players get @s nw.b_mu
execute store result storage nachtwache:tmp fl int 1 run scoreboard players get @s nw.b_fl
execute store result storage nachtwache:tmp inf int 1 run scoreboard players get @s nw.b_inf
execute store result storage nachtwache:tmp kb int 1 run scoreboard players get @s nw.b_kb
execute store result storage nachtwache:tmp rg int 1 run scoreboard players get @s nw.b_rg
data modify storage nachtwache:tmp nm set from entity @s data.nm
data modify storage nachtwache:tmp inv set value []
execute if data entity @s data.inv run data modify storage nachtwache:tmp inv set from entity @s data.inv
execute store result score #bnm nw.tmp2 run data get entity @s data.nm
execute as @p[distance=..10] run function nachtwache:bogi/geben
setblock ~ ~ ~ minecraft:air
kill @e[type=item,distance=..2.5,nbt={Item:{id:"minecraft:trapped_chest"}}]
kill @e[type=item,distance=..2.5,nbt={Item:{components:{"minecraft:custom_data":{nw_bogi_take:1b}}}}]
clear @a[distance=..8] *[custom_data~{nw_bogi_take:1b}]
tellraw @p[distance=..10] [{"text":"[Bogi] ","color":"green"},{"text":"Packing up. I am in your inventory.","color":"gray"}]
playsound minecraft:entity.item.pickup player @p[distance=..10] ~ ~ ~ 1 0.8
kill @s
