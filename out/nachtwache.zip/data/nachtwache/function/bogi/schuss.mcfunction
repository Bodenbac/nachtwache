scoreboard players set @s nw.b_t 0
scoreboard players operation #brg nw.tmp2 = @s nw.b_rg
scoreboard players operation #bmu nw.tmp2 = @s nw.b_mu
scoreboard players operation #bfl nw.tmp2 = @s nw.b_fl
scoreboard players operation #bkb nw.tmp2 = @s nw.b_kb
scoreboard players operation #bdmg nw.tmp2 = @s nw.b_st
scoreboard players operation #bdmg nw.tmp2 *= #2 nw.const
scoreboard players add #bdmg nw.tmp2 4
scoreboard players set #bpf nw.tmp2 -1
execute if items block ~ ~ ~ container.1 minecraft:arrow run scoreboard players set #bpf nw.tmp2 1
execute if items block ~ ~ ~ container.0 minecraft:arrow run scoreboard players set #bpf nw.tmp2 0
execute if score #bpf nw.tmp2 matches -1 run return 0
execute if score #brg nw.tmp2 matches 0 if score #bmu nw.tmp2 matches 0 as @e[tag=nw.welle,distance=..10,sort=nearest,limit=1] run function nachtwache:bogi/treffer
execute if score #brg nw.tmp2 matches 0 if score #bmu nw.tmp2 matches 1 as @e[tag=nw.welle,distance=..10,sort=nearest,limit=2] run function nachtwache:bogi/treffer
execute if score #brg nw.tmp2 matches 0 if score #bmu nw.tmp2 matches 2 as @e[tag=nw.welle,distance=..10,sort=nearest,limit=3] run function nachtwache:bogi/treffer
execute if score #brg nw.tmp2 matches 1 if score #bmu nw.tmp2 matches 0 as @e[tag=nw.welle,distance=..14,sort=nearest,limit=1] run function nachtwache:bogi/treffer
execute if score #brg nw.tmp2 matches 1 if score #bmu nw.tmp2 matches 1 as @e[tag=nw.welle,distance=..14,sort=nearest,limit=2] run function nachtwache:bogi/treffer
execute if score #brg nw.tmp2 matches 1 if score #bmu nw.tmp2 matches 2 as @e[tag=nw.welle,distance=..14,sort=nearest,limit=3] run function nachtwache:bogi/treffer
execute if score #brg nw.tmp2 matches 2 if score #bmu nw.tmp2 matches 0 as @e[tag=nw.welle,distance=..18,sort=nearest,limit=1] run function nachtwache:bogi/treffer
execute if score #brg nw.tmp2 matches 2 if score #bmu nw.tmp2 matches 1 as @e[tag=nw.welle,distance=..18,sort=nearest,limit=2] run function nachtwache:bogi/treffer
execute if score #brg nw.tmp2 matches 2 if score #bmu nw.tmp2 matches 2 as @e[tag=nw.welle,distance=..18,sort=nearest,limit=3] run function nachtwache:bogi/treffer
execute unless score #btreffer nw.tmp2 matches 1.. run return 0
scoreboard players set #btreffer nw.tmp2 0
playsound minecraft:entity.arrow.shoot player @a[distance=..16] ~ ~ ~ 0.7 1.2
execute as @e[type=item_display,tag=nw.bogi_a,distance=..0.1] run data merge entity @s {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[-0.21644f,0f,0f,0.9763f],translation:[0f,0.01906f,0.02349f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
execute if score @s nw.b_inf matches 0 if score #bpf nw.tmp2 matches 0 run item modify block ~ ~ ~ container.0 nachtwache:pfeil_weg
execute if score @s nw.b_inf matches 0 if score #bpf nw.tmp2 matches 1 run item modify block ~ ~ ~ container.1 nachtwache:pfeil_weg
