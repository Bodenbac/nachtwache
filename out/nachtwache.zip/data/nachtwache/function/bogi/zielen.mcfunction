tp @e[type=item_display,tag=nw.bogi_k,distance=..0.6] ~ ~ ~ ~ 0
tp @e[type=item_display,tag=nw.bogi_a,distance=..0.6] ~ ~ ~ ~ 0
scoreboard players set #spur nw.tmp 16
execute positioned ~ ~0.7 ~ run function nachtwache:bogi/spur
