execute as @e[type=marker,tag=nw.bogi_neu] at @s run function nachtwache:bogi/neu
execute as @e[type=marker,tag=nw.bogi] at @s run function nachtwache:bogi/einer
