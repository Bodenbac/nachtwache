tag @s remove nw.bogi_neu
execute align xyz positioned ~0.5 ~0.5 ~0.5 run tp @s ~ ~ ~
execute at @s unless block ~ ~ ~ minecraft:air run return run function nachtwache:bogi/zurueck
execute at @s unless block ~ ~-1 ~ #nachtwache:grabbar unless block ~ ~-1 ~ minecraft:grass_block run return run function nachtwache:bogi/zurueck
tag @s add nw.bogi
execute store result score @s nw.b_sp run data get entity @s data.sp
execute store result score @s nw.b_st run data get entity @s data.st
execute store result score @s nw.b_mu run data get entity @s data.mu
execute store result score @s nw.b_fl run data get entity @s data.fl
execute store result score @s nw.b_inf run data get entity @s data.inf
execute store result score @s nw.b_kb run data get entity @s data.kb
execute store result score @s nw.b_rg run data get entity @s data.rg
execute store result score @s nw.b_nm run data get entity @s data.nm
scoreboard players set @s nw.b_t 0
execute at @s run setblock ~ ~ ~ minecraft:trapped_chest[facing=north,type=single]
execute at @s unless block ~ ~ ~ minecraft:trapped_chest[type=single] run setblock ~ ~ ~ minecraft:trapped_chest[facing=east,type=single]
execute at @s unless block ~ ~ ~ minecraft:trapped_chest[type=single] run setblock ~ ~ ~ minecraft:trapped_chest[facing=south,type=single]
execute at @s unless block ~ ~ ~ minecraft:trapped_chest[type=single] run setblock ~ ~ ~ minecraft:trapped_chest[facing=west,type=single]
execute if data entity @s data.inv run data modify block ~ ~ ~ Items set from entity @s data.inv
execute at @s run function nachtwache:bogi/zeichnen
execute at @s run function nachtwache:bogi/symbol
playsound minecraft:entity.villager.work_fletcher neutral @a ~ ~ ~ 1 0.9
tellraw @a[distance=..12] [{"text":"Bogi takes his post. Give him arrows and he will shoot.","color":"green"}]
