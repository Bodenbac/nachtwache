kill @e[type=item_display,tag=nw.bogi_k,distance=..0.1]
kill @e[type=item_display,tag=nw.bogi_a,distance=..0.1]
summon minecraft:item_display ~ ~ ~ {Tags:["nw.bogi_k"],item_display:"none",interpolation_duration:2,brightness:{sky:15,block:15},item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"nachtwache:archer_body"}}}
summon minecraft:item_display ~ ~ ~ {Tags:["nw.bogi_a"],item_display:"none",interpolation_duration:2,brightness:{sky:15,block:15},item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"nachtwache:archer_arm"}}}
