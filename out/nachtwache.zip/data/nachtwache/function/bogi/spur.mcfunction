particle minecraft:crit ~ ~ ~ 0 0 0 0 1 force
scoreboard players remove #spur nw.tmp 1
execute if score #spur nw.tmp matches 1.. positioned ^ ^ ^0.5 run function nachtwache:bogi/spur
