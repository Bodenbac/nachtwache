scoreboard players set #btreffer nw.tmp2 1
execute facing entity @s eyes run function nachtwache:bogi/zielen
execute store result storage nachtwache:tmp dmg int 1 run scoreboard players get #bdmg nw.tmp2
function nachtwache:bogi/schaden with storage nachtwache:tmp
execute if score #bfl nw.tmp2 matches 1 run data modify entity @s Fire set value 100s
execute if score #bkb nw.tmp2 matches 1.. facing entity @s feet run tp @s ^ ^ ^0.8
execute if score #bkb nw.tmp2 matches 2 facing entity @s feet run tp @s ^ ^ ^0.8
playsound minecraft:entity.arrow.hit_player player @a[distance=..16] ~ ~ ~ 0.5 1.4
