execute positioned ^ ^ ^0.8 if block ~ ~ ~ #minecraft:air if block ~ ~1 ~ #minecraft:air run tp @s ~ ~ ~
