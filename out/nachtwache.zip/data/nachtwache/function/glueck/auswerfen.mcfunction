$summon minecraft:item ~ ~0.5 ~ {Item:$(gl),PickupDelay:0s}
