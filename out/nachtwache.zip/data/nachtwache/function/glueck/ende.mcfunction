scoreboard players set @s nw.gl 0
scoreboard players set @s nw.glw 0
title @s times 0 60 10
execute if score @s nw.glz matches 1 run function nachtwache:glueck/ende_1
execute if score @s nw.glz matches 2 run function nachtwache:glueck/ende_2
execute if score @s nw.glz matches 3 run function nachtwache:glueck/ende_3
execute if score @s nw.glz matches 4 run function nachtwache:glueck/ende_4
execute if score @s nw.glz matches 5 run function nachtwache:glueck/ende_5
execute if score @s nw.glz matches 6 run function nachtwache:glueck/ende_6
execute if score @s nw.glz matches 7 run function nachtwache:glueck/ende_7
scoreboard players set @s nw.glz 0
