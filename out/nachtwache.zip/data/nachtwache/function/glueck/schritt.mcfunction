execute if score @s nw.glw matches 1.. run return run scoreboard players remove @s nw.glw 1
scoreboard players remove @s nw.gl 1
execute if score @s nw.gl matches ..0 run return run function nachtwache:glueck/ende
execute if score @s nw.gl matches 1 run function nachtwache:glueck/bild_1
execute if score @s nw.gl matches 1 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 2 run function nachtwache:glueck/bild_2
execute if score @s nw.gl matches 2 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 3 run function nachtwache:glueck/bild_3
execute if score @s nw.gl matches 3 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 4 run function nachtwache:glueck/bild_4
execute if score @s nw.gl matches 4 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 5 run function nachtwache:glueck/bild_5
execute if score @s nw.gl matches 5 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 6 run function nachtwache:glueck/bild_6
execute if score @s nw.gl matches 6 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 7 run function nachtwache:glueck/bild_7
execute if score @s nw.gl matches 7 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 8 run function nachtwache:glueck/bild_8
execute if score @s nw.gl matches 8 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 9 run function nachtwache:glueck/bild_9
execute if score @s nw.gl matches 9 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 10 run function nachtwache:glueck/bild_10
execute if score @s nw.gl matches 10 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 11 run function nachtwache:glueck/bild_11
execute if score @s nw.gl matches 11 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 12 run function nachtwache:glueck/bild_12
execute if score @s nw.gl matches 12 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 13 run function nachtwache:glueck/bild_13
execute if score @s nw.gl matches 13 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 14 run function nachtwache:glueck/bild_14
execute if score @s nw.gl matches 14 run scoreboard players set @s nw.glw 1
execute if score @s nw.gl matches 15 run function nachtwache:glueck/bild_15
execute if score @s nw.gl matches 15 run scoreboard players set @s nw.glw 2
execute if score @s nw.gl matches 16 run function nachtwache:glueck/bild_16
execute if score @s nw.gl matches 16 run scoreboard players set @s nw.glw 2
execute if score @s nw.gl matches 17 run function nachtwache:glueck/bild_17
execute if score @s nw.gl matches 17 run scoreboard players set @s nw.glw 2
execute if score @s nw.gl matches 18 run function nachtwache:glueck/bild_18
execute if score @s nw.gl matches 18 run scoreboard players set @s nw.glw 2
execute if score @s nw.gl matches 19 run function nachtwache:glueck/bild_19
execute if score @s nw.gl matches 19 run scoreboard players set @s nw.glw 2
execute if score @s nw.gl matches 20 run function nachtwache:glueck/bild_20
execute if score @s nw.gl matches 20 run scoreboard players set @s nw.glw 2
execute if score @s nw.gl matches 21 run function nachtwache:glueck/bild_21
execute if score @s nw.gl matches 21 run scoreboard players set @s nw.glw 3
execute if score @s nw.gl matches 22 run function nachtwache:glueck/bild_22
execute if score @s nw.gl matches 22 run scoreboard players set @s nw.glw 3
execute if score @s nw.gl matches 23 run function nachtwache:glueck/bild_23
execute if score @s nw.gl matches 23 run scoreboard players set @s nw.glw 3
execute if score @s nw.gl matches 24 run function nachtwache:glueck/bild_24
execute if score @s nw.gl matches 24 run scoreboard players set @s nw.glw 3
execute if score @s nw.gl matches 25 run function nachtwache:glueck/bild_25
execute if score @s nw.gl matches 25 run scoreboard players set @s nw.glw 4
execute if score @s nw.gl matches 26 run function nachtwache:glueck/bild_26
execute if score @s nw.gl matches 26 run scoreboard players set @s nw.glw 5
execute if score @s nw.gl matches 27 run function nachtwache:glueck/bild_27
execute if score @s nw.gl matches 27 run scoreboard players set @s nw.glw 6
execute if score @s nw.gl matches 28 run function nachtwache:glueck/bild_28
execute if score @s nw.gl matches 28 run scoreboard players set @s nw.glw 8
execute if score @s nw.gl matches 29 run function nachtwache:glueck/bild_29
execute if score @s nw.gl matches 29 run scoreboard players set @s nw.glw 10
execute if score @s nw.gl matches 30 run function nachtwache:glueck/bild_30
execute if score @s nw.gl matches 30 run scoreboard players set @s nw.glw 13
