title @s title [{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":"[","color":"yellow","bold":true},{"text":" ","color":"white"},{"text":"]","color":"yellow","bold":true},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"}]
title @s subtitle [{"text":"Yellow Crate","color":"yellow","bold":true}]
loot give @s loot nachtwache:glueck/kiste5
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.0
tellraw @a [{"selector":"@s","color":"white"},{"text":" opened a ","color":"gray"},{"text":"Yellow Crate","color":"yellow","bold":true},{"text":".","color":"gray"}]
