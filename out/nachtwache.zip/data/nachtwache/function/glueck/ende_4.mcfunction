title @a title [{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":"[","color":"yellow","bold":true},{"text":" ","color":"white"},{"text":"]","color":"yellow","bold":true},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"}]
title @a subtitle [{"text":"Purple Crate","color":"light_purple","bold":true}]
loot give @s loot nachtwache:glueck/stufe4
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 1
playsound minecraft:block.note_block.bell master @a ~ ~ ~ 1 1.0
tellraw @a [{"selector":"@s","color":"white"},{"text":" opened a ","color":"gray"},{"text":"Purple Crate","color":"light_purple","bold":true},{"text":".","color":"gray"}]
