advancement revoke @s only nachtwache:key_benutzt
execute if score @s nw.gl matches 1.. run return run tellraw @s [{"text":"The wheel is still turning.","color":"gray","italic":true}]
execute store result score @s nw.glr run random value 1..100
execute if score @s nw.glr matches 1..40 run scoreboard players set @s nw.glz 1
execute if score @s nw.glr matches 41..65 run scoreboard players set @s nw.glz 2
execute if score @s nw.glr matches 66..80 run scoreboard players set @s nw.glz 3
execute if score @s nw.glr matches 81..90 run scoreboard players set @s nw.glz 4
execute if score @s nw.glr matches 91..96 run scoreboard players set @s nw.glz 5
execute if score @s nw.glr matches 97..99 run scoreboard players set @s nw.glz 6
execute if score @s nw.glr matches 100..100 run scoreboard players set @s nw.glz 7
scoreboard players set @s nw.gl 31
scoreboard players set @s nw.glw 0
title @s times 0 40 6
playsound minecraft:block.note_block.bit master @s ~ ~ ~ 1 0.6
tellraw @s [{"text":"The Collector spins the wheel.","color":"gold","italic":true}]
