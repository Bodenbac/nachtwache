execute as @a[scores={nw.gl=1..}] at @s run function nachtwache:glueck/schritt
