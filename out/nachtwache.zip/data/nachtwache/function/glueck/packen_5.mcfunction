setblock 0 5 -10 minecraft:barrel
loot replace block 0 5 -10 container.0 loot nachtwache:glueck/stufe5
execute store result score #gx nw.tmp run random value 1..10000
execute if score #gx nw.tmp matches ..2000 run function nachtwache:glueck/extra_focus
execute if score #gx nw.tmp matches ..2000 run tellraw @a [{"selector":"@s","color":"white"},{"text":" finds ","color":"gray"},{"text":"a Source Focus","color":"gold","bold":true},{"text":" in the crate!","color":"gray"}]
execute store result score #gx nw.tmp run random value 1..10000
execute if score #gx nw.tmp matches ..1000 run function nachtwache:glueck/extra_fraggle
execute if score #gx nw.tmp matches ..1000 run tellraw @a [{"selector":"@s","color":"white"},{"text":" finds ","color":"gray"},{"text":"Fraggle","color":"gold","bold":true},{"text":" in the crate!","color":"gray"}]
execute store result score #gx nw.tmp run random value 1..10000
execute if score #gx nw.tmp matches ..1000 run function nachtwache:glueck/extra_bogi
execute if score #gx nw.tmp matches ..1000 run tellraw @a [{"selector":"@s","color":"white"},{"text":" finds ","color":"gray"},{"text":"a Bogi","color":"gold","bold":true},{"text":" in the crate!","color":"gray"}]
data modify storage nachtwache:tmp gl set from block 0 5 -10 Items[{Slot:0b}]
data remove storage nachtwache:tmp gl.Slot
setblock 0 5 -10 minecraft:air
execute at @s run function nachtwache:glueck/auswerfen with storage nachtwache:tmp
