scoreboard players add #bogi_nr nw.status 1
execute unless score #bogi_nr nw.status matches 1..16 run scoreboard players set #bogi_nr nw.status 1
execute if score #bogi_nr nw.status matches 1 run function nachtwache:glueck/extra_bogi_1
execute if score #bogi_nr nw.status matches 2 run function nachtwache:glueck/extra_bogi_2
execute if score #bogi_nr nw.status matches 3 run function nachtwache:glueck/extra_bogi_3
execute if score #bogi_nr nw.status matches 4 run function nachtwache:glueck/extra_bogi_4
execute if score #bogi_nr nw.status matches 5 run function nachtwache:glueck/extra_bogi_5
execute if score #bogi_nr nw.status matches 6 run function nachtwache:glueck/extra_bogi_6
execute if score #bogi_nr nw.status matches 7 run function nachtwache:glueck/extra_bogi_7
execute if score #bogi_nr nw.status matches 8 run function nachtwache:glueck/extra_bogi_8
execute if score #bogi_nr nw.status matches 9 run function nachtwache:glueck/extra_bogi_9
execute if score #bogi_nr nw.status matches 10 run function nachtwache:glueck/extra_bogi_10
execute if score #bogi_nr nw.status matches 11 run function nachtwache:glueck/extra_bogi_11
execute if score #bogi_nr nw.status matches 12 run function nachtwache:glueck/extra_bogi_12
execute if score #bogi_nr nw.status matches 13 run function nachtwache:glueck/extra_bogi_13
execute if score #bogi_nr nw.status matches 14 run function nachtwache:glueck/extra_bogi_14
execute if score #bogi_nr nw.status matches 15 run function nachtwache:glueck/extra_bogi_15
execute if score #bogi_nr nw.status matches 16 run function nachtwache:glueck/extra_bogi_16
