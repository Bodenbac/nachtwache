title @s title [{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":"[","color":"yellow","bold":true},{"text":" ","color":"white"},{"text":"]","color":"yellow","bold":true},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"},{"text":" ","color":"white"}]
title @s subtitle [{"text":"Black Crate","color":"dark_purple","bold":true}]
loot give @s loot nachtwache:glueck/kiste7
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.4
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 0.6 1.4
tellraw @a [{"selector":"@s","color":"white"},{"text":" opened a ","color":"gray"},{"text":"Black Crate","color":"dark_purple","bold":true},{"text":"!","color":"gray"}]
