tag @a[name=luisgamer2349] add nw.admin
scoreboard players enable @a[tag=nw.admin] reset
scoreboard players enable @a[tag=nw.admin] yes
scoreboard players enable @a[tag=nw.admin] night
scoreboard players enable @a[tag=nw.admin] boss
scoreboard players enable @a[tag=nw.admin] fraggle
scoreboard players enable @a[tag=nw.admin] endnight
scoreboard players enable @a[tag=nw.admin] money
function nachtwache:laterne/sekunde
function nachtwache:focus/sekunde
function nachtwache:beacon/aufbauen
function nachtwache:beacon/anzeige
function nachtwache:decoy/sekunde
kill @e[type=block_display,tag=nw.gen_block]
function nachtwache:gegner/enderman_wut
execute if entity @e[tag=nw.villager] run scoreboard players set #fehlt nw.tmp2 0
execute unless entity @e[tag=nw.villager] run scoreboard players add #fehlt nw.tmp2 1
execute unless score #finale nw.status matches 1 if score #fehlt nw.tmp2 matches 5.. run function nachtwache:sammler/erscheinen
execute if score #migrieren nw.status matches 1 if score #tick nw.tick matches 100.. run function nachtwache:migration
kill @e[tag=nw.villager,name=!"The Collector"]
execute store result score #cv nw.tmp2 if entity @e[tag=nw.villager]
execute if score #cv nw.tmp2 matches 2.. run kill @e[tag=nw.villager,limit=1,sort=arbitrary]
execute store result score #ci nw.tmp2 if entity @e[tag=nw.sammler]
execute if score #ci nw.tmp2 matches 2.. run kill @e[tag=nw.sammler,limit=1,sort=arbitrary]
execute if score #tick nw.tick matches 6000.. run scoreboard players operation #m6000 nw.tmp2 = #tick nw.tick
scoreboard players operation #m6000 nw.tmp2 %= #6000 nw.const
execute if score #m6000 nw.tmp2 matches 0..19 unless score #modus nw.status matches 3 run weather thunder 1000000
scoreboard players enable @a nw.kauf
scoreboard players enable @a nw.hilfe
