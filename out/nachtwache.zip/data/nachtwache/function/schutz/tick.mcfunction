scoreboard players operation #m2 nw.tmp2 = #tick nw.tick
scoreboard players operation #m2 nw.tmp2 %= #2 nw.const
execute if score #m2 nw.tmp2 matches 0 run function nachtwache:welt/gegnerinsel
execute if score #m2 nw.tmp2 matches 1 if score #status nw.status matches 1 run function nachtwache:strasse/bauen
execute if score #m2 nw.tmp2 matches 1 if score #status nw.status matches 0 run function nachtwache:strasse/entfernen
kill @e[type=item,x=-13,y=55,z=60,dx=26,dy=25,dz=24]
kill @e[type=item,x=-4,y=62,z=9,dx=8,dy=6,dz=50]
