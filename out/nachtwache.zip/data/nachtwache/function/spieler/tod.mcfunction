scoreboard players reset @s nw.tode
scoreboard players add #tode nw.tode 1
scoreboard players operation #abzug nw.tmp = #konto nw.konto
scoreboard players operation #abzug nw.tmp /= #10 nw.const
scoreboard players operation #konto nw.konto -= #abzug nw.tmp
tellraw @a [{"selector":"@s","color":"red"},{"text":" died. ","color":"gray"},{"text":"-","color":"gold"},{"score":{"name":"#abzug","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"gold"},{"text":"●","color":"white"}]
spawnpoint @s 0 64 3
function nachtwache:sammler/spruch/tod
