execute as @a store result score @s nw.schlaf run data get entity @s SleepTimer
execute if score #gegner nw.gegner matches 1.. as @a[scores={nw.schlaf=1..}] run function nachtwache:spieler/aufwecken
execute if score #gegner nw.gegner matches 0 if score #status nw.status matches 1 if entity @a unless entity @a[scores={nw.schlaf=..0}] run function nachtwache:nacht/schlafen
