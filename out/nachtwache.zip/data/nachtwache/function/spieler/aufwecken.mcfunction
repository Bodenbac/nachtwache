tp @s ~ ~ ~
tellraw @s [{"text":"Not while something is alive.","color":"red","italic":true}]
