scoreboard players set #w nw.tmp2 27
