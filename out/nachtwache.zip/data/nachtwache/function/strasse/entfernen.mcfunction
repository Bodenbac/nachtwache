setblock -1 66 11 minecraft:air
setblock -1 66 17 minecraft:air
setblock -1 66 23 minecraft:air
setblock -1 66 29 minecraft:air
setblock -1 66 35 minecraft:air
setblock -1 66 41 minecraft:air
setblock -1 66 47 minecraft:air
setblock -1 66 53 minecraft:air
setblock 1 66 11 minecraft:air
setblock 1 66 17 minecraft:air
setblock 1 66 23 minecraft:air
setblock 1 66 29 minecraft:air
setblock 1 66 35 minecraft:air
setblock 1 66 41 minecraft:air
setblock 1 66 47 minecraft:air
setblock 1 66 53 minecraft:air
fill -2 61 9 2 62 62 minecraft:air
fill -3 60 9 3 70 62 minecraft:air
execute as @e[type=marker,tag=nw.laterne,x=-3,y=63,z=9,dx=6,dy=3,dz=50] at @s run function nachtwache:laterne/halten
