fill -2 64 9 -2 64 59 minecraft:air
fill 2 64 9 2 64 59 minecraft:air
fill -3 62 9 3 66 59 minecraft:air
execute as @e[type=marker,tag=nw.laterne,x=-3,y=63,z=9,dx=6,dy=3,dz=50] at @s run function nachtwache:laterne/halten
