fill -2 64 9 -2 64 59 minecraft:air
fill 2 64 9 2 64 59 minecraft:air
fill -3 62 9 3 66 59 minecraft:air
