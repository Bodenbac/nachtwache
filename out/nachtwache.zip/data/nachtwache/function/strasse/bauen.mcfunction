fill -1 63 9 1 63 59 minecraft:crimson_planks
fill -1 64 9 1 66 59 minecraft:air
fill -3 62 9 3 62 59 minecraft:air
fill -3 63 9 -3 66 59 minecraft:air
fill 3 63 9 3 66 59 minecraft:air
fill -2 65 9 -2 66 59 minecraft:air
fill 2 65 9 2 66 59 minecraft:air
fill -2 63 9 -2 64 10 minecraft:air
fill 2 63 9 2 64 10 minecraft:air
fill -2 63 12 -2 64 16 minecraft:air
fill 2 63 12 2 64 16 minecraft:air
fill -2 63 18 -2 64 22 minecraft:air
fill 2 63 18 2 64 22 minecraft:air
fill -2 63 24 -2 64 28 minecraft:air
fill 2 63 24 2 64 28 minecraft:air
fill -2 63 30 -2 64 34 minecraft:air
fill 2 63 30 2 64 34 minecraft:air
fill -2 63 36 -2 64 40 minecraft:air
fill 2 63 36 2 64 40 minecraft:air
fill -2 63 42 -2 64 46 minecraft:air
fill 2 63 42 2 64 46 minecraft:air
fill -2 63 48 -2 64 52 minecraft:air
fill 2 63 48 2 64 52 minecraft:air
fill -2 63 54 -2 64 59 minecraft:air
fill 2 63 54 2 64 59 minecraft:air
execute unless block -2 63 11 minecraft:crimson_fence run setblock -2 63 11 minecraft:crimson_fence
execute unless block -2 64 11 minecraft:redstone_torch run setblock -2 64 11 minecraft:redstone_torch[lit=true]
execute unless block 2 63 11 minecraft:crimson_fence run setblock 2 63 11 minecraft:crimson_fence
execute unless block 2 64 11 minecraft:redstone_torch run setblock 2 64 11 minecraft:redstone_torch[lit=true]
execute unless block -2 63 17 minecraft:crimson_fence run setblock -2 63 17 minecraft:crimson_fence
execute unless block -2 64 17 minecraft:redstone_torch run setblock -2 64 17 minecraft:redstone_torch[lit=true]
execute unless block 2 63 17 minecraft:crimson_fence run setblock 2 63 17 minecraft:crimson_fence
execute unless block 2 64 17 minecraft:redstone_torch run setblock 2 64 17 minecraft:redstone_torch[lit=true]
execute unless block -2 63 23 minecraft:crimson_fence run setblock -2 63 23 minecraft:crimson_fence
execute unless block -2 64 23 minecraft:redstone_torch run setblock -2 64 23 minecraft:redstone_torch[lit=true]
execute unless block 2 63 23 minecraft:crimson_fence run setblock 2 63 23 minecraft:crimson_fence
execute unless block 2 64 23 minecraft:redstone_torch run setblock 2 64 23 minecraft:redstone_torch[lit=true]
execute unless block -2 63 29 minecraft:crimson_fence run setblock -2 63 29 minecraft:crimson_fence
execute unless block -2 64 29 minecraft:redstone_torch run setblock -2 64 29 minecraft:redstone_torch[lit=true]
execute unless block 2 63 29 minecraft:crimson_fence run setblock 2 63 29 minecraft:crimson_fence
execute unless block 2 64 29 minecraft:redstone_torch run setblock 2 64 29 minecraft:redstone_torch[lit=true]
execute unless block -2 63 35 minecraft:crimson_fence run setblock -2 63 35 minecraft:crimson_fence
execute unless block -2 64 35 minecraft:redstone_torch run setblock -2 64 35 minecraft:redstone_torch[lit=true]
execute unless block 2 63 35 minecraft:crimson_fence run setblock 2 63 35 minecraft:crimson_fence
execute unless block 2 64 35 minecraft:redstone_torch run setblock 2 64 35 minecraft:redstone_torch[lit=true]
execute unless block -2 63 41 minecraft:crimson_fence run setblock -2 63 41 minecraft:crimson_fence
execute unless block -2 64 41 minecraft:redstone_torch run setblock -2 64 41 minecraft:redstone_torch[lit=true]
execute unless block 2 63 41 minecraft:crimson_fence run setblock 2 63 41 minecraft:crimson_fence
execute unless block 2 64 41 minecraft:redstone_torch run setblock 2 64 41 minecraft:redstone_torch[lit=true]
execute unless block -2 63 47 minecraft:crimson_fence run setblock -2 63 47 minecraft:crimson_fence
execute unless block -2 64 47 minecraft:redstone_torch run setblock -2 64 47 minecraft:redstone_torch[lit=true]
execute unless block 2 63 47 minecraft:crimson_fence run setblock 2 63 47 minecraft:crimson_fence
execute unless block 2 64 47 minecraft:redstone_torch run setblock 2 64 47 minecraft:redstone_torch[lit=true]
execute unless block -2 63 53 minecraft:crimson_fence run setblock -2 63 53 minecraft:crimson_fence
execute unless block -2 64 53 minecraft:redstone_torch run setblock -2 64 53 minecraft:redstone_torch[lit=true]
execute unless block 2 63 53 minecraft:crimson_fence run setblock 2 63 53 minecraft:crimson_fence
execute unless block 2 64 53 minecraft:redstone_torch run setblock 2 64 53 minecraft:redstone_torch[lit=true]
execute as @e[type=marker,tag=nw.laterne,x=-3,y=63,z=9,dx=6,dy=3,dz=50] at @s run function nachtwache:laterne/halten
