fill -1 63 9 1 63 59 minecraft:polished_blackstone_bricks
fill -2 63 9 -2 63 60 minecraft:polished_deepslate
fill 2 63 9 2 63 60 minecraft:polished_deepslate
fill -1 60 9 1 62 59 minecraft:air
fill -3 60 9 -3 72 60 minecraft:air
fill 3 60 9 3 72 60 minecraft:air
fill -2 70 9 2 72 60 minecraft:air
fill -2 64 9 -2 68 10 minecraft:deepslate_bricks
fill 2 64 9 2 68 10 minecraft:deepslate_bricks
fill -1 69 9 1 69 10 minecraft:iron_bars
fill -2 69 9 -2 69 10 minecraft:deepslate_bricks
fill 2 69 9 2 69 10 minecraft:deepslate_bricks
fill -1 64 9 1 68 10 minecraft:air
fill -2 64 12 -2 68 16 minecraft:deepslate_bricks
fill 2 64 12 2 68 16 minecraft:deepslate_bricks
fill -1 69 12 1 69 16 minecraft:iron_bars
fill -2 69 12 -2 69 16 minecraft:deepslate_bricks
fill 2 69 12 2 69 16 minecraft:deepslate_bricks
fill -1 64 12 1 68 16 minecraft:air
fill -2 64 18 -2 68 22 minecraft:deepslate_bricks
fill 2 64 18 2 68 22 minecraft:deepslate_bricks
fill -1 69 18 1 69 22 minecraft:iron_bars
fill -2 69 18 -2 69 22 minecraft:deepslate_bricks
fill 2 69 18 2 69 22 minecraft:deepslate_bricks
fill -1 64 18 1 68 22 minecraft:air
fill -2 64 24 -2 68 28 minecraft:deepslate_bricks
fill 2 64 24 2 68 28 minecraft:deepslate_bricks
fill -1 69 24 1 69 28 minecraft:iron_bars
fill -2 69 24 -2 69 28 minecraft:deepslate_bricks
fill 2 69 24 2 69 28 minecraft:deepslate_bricks
fill -1 64 24 1 68 28 minecraft:air
fill -2 64 30 -2 68 34 minecraft:deepslate_bricks
fill 2 64 30 2 68 34 minecraft:deepslate_bricks
fill -1 69 30 1 69 34 minecraft:iron_bars
fill -2 69 30 -2 69 34 minecraft:deepslate_bricks
fill 2 69 30 2 69 34 minecraft:deepslate_bricks
fill -1 64 30 1 68 34 minecraft:air
fill -2 64 36 -2 68 40 minecraft:deepslate_bricks
fill 2 64 36 2 68 40 minecraft:deepslate_bricks
fill -1 69 36 1 69 40 minecraft:iron_bars
fill -2 69 36 -2 69 40 minecraft:deepslate_bricks
fill 2 69 36 2 69 40 minecraft:deepslate_bricks
fill -1 64 36 1 68 40 minecraft:air
fill -2 64 42 -2 68 46 minecraft:deepslate_bricks
fill 2 64 42 2 68 46 minecraft:deepslate_bricks
fill -1 69 42 1 69 46 minecraft:iron_bars
fill -2 69 42 -2 69 46 minecraft:deepslate_bricks
fill 2 69 42 2 69 46 minecraft:deepslate_bricks
fill -1 64 42 1 68 46 minecraft:air
fill -2 64 48 -2 68 52 minecraft:deepslate_bricks
fill 2 64 48 2 68 52 minecraft:deepslate_bricks
fill -1 69 48 1 69 52 minecraft:iron_bars
fill -2 69 48 -2 69 52 minecraft:deepslate_bricks
fill 2 69 48 2 69 52 minecraft:deepslate_bricks
fill -1 64 48 1 68 52 minecraft:air
fill -2 64 54 -2 68 60 minecraft:deepslate_bricks
fill 2 64 54 2 68 60 minecraft:deepslate_bricks
fill -1 69 54 1 69 60 minecraft:iron_bars
fill -2 69 54 -2 69 60 minecraft:deepslate_bricks
fill 2 69 54 2 69 60 minecraft:deepslate_bricks
fill -1 64 54 1 68 60 minecraft:air
fill -2 64 11 -2 69 11 minecraft:polished_blackstone_bricks
fill 2 64 11 2 69 11 minecraft:polished_blackstone_bricks
fill -1 69 11 1 69 11 minecraft:polished_blackstone_bricks
fill -1 64 11 1 67 11 minecraft:air
setblock 0 68 11 minecraft:air
execute unless block -1 68 11 minecraft:soul_lantern run setblock -1 68 11 minecraft:soul_lantern[hanging=true]
execute unless block 1 68 11 minecraft:soul_lantern run setblock 1 68 11 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 11 minecraft:iron_chain run setblock -2 62 11 minecraft:iron_chain
execute unless block -2 61 11 minecraft:iron_chain run setblock -2 61 11 minecraft:iron_chain
execute unless block 2 62 11 minecraft:iron_chain run setblock 2 62 11 minecraft:iron_chain
execute unless block 2 61 11 minecraft:iron_chain run setblock 2 61 11 minecraft:iron_chain
fill -2 64 17 -2 69 17 minecraft:polished_blackstone_bricks
fill 2 64 17 2 69 17 minecraft:polished_blackstone_bricks
fill -1 69 17 1 69 17 minecraft:polished_blackstone_bricks
fill -1 64 17 1 67 17 minecraft:air
setblock 0 68 17 minecraft:air
execute unless block -1 68 17 minecraft:soul_lantern run setblock -1 68 17 minecraft:soul_lantern[hanging=true]
execute unless block 1 68 17 minecraft:soul_lantern run setblock 1 68 17 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 17 minecraft:iron_chain run setblock -2 62 17 minecraft:iron_chain
execute unless block -2 61 17 minecraft:iron_chain run setblock -2 61 17 minecraft:iron_chain
execute unless block 2 62 17 minecraft:iron_chain run setblock 2 62 17 minecraft:iron_chain
execute unless block 2 61 17 minecraft:iron_chain run setblock 2 61 17 minecraft:iron_chain
fill -2 64 23 -2 69 23 minecraft:polished_blackstone_bricks
fill 2 64 23 2 69 23 minecraft:polished_blackstone_bricks
fill -1 69 23 1 69 23 minecraft:polished_blackstone_bricks
fill -1 64 23 1 67 23 minecraft:air
setblock 0 68 23 minecraft:air
execute unless block -1 68 23 minecraft:soul_lantern run setblock -1 68 23 minecraft:soul_lantern[hanging=true]
execute unless block 1 68 23 minecraft:soul_lantern run setblock 1 68 23 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 23 minecraft:iron_chain run setblock -2 62 23 minecraft:iron_chain
execute unless block -2 61 23 minecraft:iron_chain run setblock -2 61 23 minecraft:iron_chain
execute unless block 2 62 23 minecraft:iron_chain run setblock 2 62 23 minecraft:iron_chain
execute unless block 2 61 23 minecraft:iron_chain run setblock 2 61 23 minecraft:iron_chain
fill -2 64 29 -2 69 29 minecraft:polished_blackstone_bricks
fill 2 64 29 2 69 29 minecraft:polished_blackstone_bricks
fill -1 69 29 1 69 29 minecraft:polished_blackstone_bricks
fill -1 64 29 1 67 29 minecraft:air
setblock 0 68 29 minecraft:air
execute unless block -1 68 29 minecraft:soul_lantern run setblock -1 68 29 minecraft:soul_lantern[hanging=true]
execute unless block 1 68 29 minecraft:soul_lantern run setblock 1 68 29 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 29 minecraft:iron_chain run setblock -2 62 29 minecraft:iron_chain
execute unless block -2 61 29 minecraft:iron_chain run setblock -2 61 29 minecraft:iron_chain
execute unless block 2 62 29 minecraft:iron_chain run setblock 2 62 29 minecraft:iron_chain
execute unless block 2 61 29 minecraft:iron_chain run setblock 2 61 29 minecraft:iron_chain
fill -2 64 35 -2 69 35 minecraft:polished_blackstone_bricks
fill 2 64 35 2 69 35 minecraft:polished_blackstone_bricks
fill -1 69 35 1 69 35 minecraft:polished_blackstone_bricks
fill -1 64 35 1 67 35 minecraft:air
setblock 0 68 35 minecraft:air
execute unless block -1 68 35 minecraft:soul_lantern run setblock -1 68 35 minecraft:soul_lantern[hanging=true]
execute unless block 1 68 35 minecraft:soul_lantern run setblock 1 68 35 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 35 minecraft:iron_chain run setblock -2 62 35 minecraft:iron_chain
execute unless block -2 61 35 minecraft:iron_chain run setblock -2 61 35 minecraft:iron_chain
execute unless block 2 62 35 minecraft:iron_chain run setblock 2 62 35 minecraft:iron_chain
execute unless block 2 61 35 minecraft:iron_chain run setblock 2 61 35 minecraft:iron_chain
fill -2 64 41 -2 69 41 minecraft:polished_blackstone_bricks
fill 2 64 41 2 69 41 minecraft:polished_blackstone_bricks
fill -1 69 41 1 69 41 minecraft:polished_blackstone_bricks
fill -1 64 41 1 67 41 minecraft:air
setblock 0 68 41 minecraft:air
execute unless block -1 68 41 minecraft:soul_lantern run setblock -1 68 41 minecraft:soul_lantern[hanging=true]
execute unless block 1 68 41 minecraft:soul_lantern run setblock 1 68 41 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 41 minecraft:iron_chain run setblock -2 62 41 minecraft:iron_chain
execute unless block -2 61 41 minecraft:iron_chain run setblock -2 61 41 minecraft:iron_chain
execute unless block 2 62 41 minecraft:iron_chain run setblock 2 62 41 minecraft:iron_chain
execute unless block 2 61 41 minecraft:iron_chain run setblock 2 61 41 minecraft:iron_chain
fill -2 64 47 -2 69 47 minecraft:polished_blackstone_bricks
fill 2 64 47 2 69 47 minecraft:polished_blackstone_bricks
fill -1 69 47 1 69 47 minecraft:polished_blackstone_bricks
fill -1 64 47 1 67 47 minecraft:air
setblock 0 68 47 minecraft:air
execute unless block -1 68 47 minecraft:soul_lantern run setblock -1 68 47 minecraft:soul_lantern[hanging=true]
execute unless block 1 68 47 minecraft:soul_lantern run setblock 1 68 47 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 47 minecraft:iron_chain run setblock -2 62 47 minecraft:iron_chain
execute unless block -2 61 47 minecraft:iron_chain run setblock -2 61 47 minecraft:iron_chain
execute unless block 2 62 47 minecraft:iron_chain run setblock 2 62 47 minecraft:iron_chain
execute unless block 2 61 47 minecraft:iron_chain run setblock 2 61 47 minecraft:iron_chain
fill -2 64 53 -2 69 53 minecraft:polished_blackstone_bricks
fill 2 64 53 2 69 53 minecraft:polished_blackstone_bricks
fill -1 69 53 1 69 53 minecraft:polished_blackstone_bricks
fill -1 64 53 1 67 53 minecraft:air
setblock 0 68 53 minecraft:air
execute unless block -1 68 53 minecraft:soul_lantern run setblock -1 68 53 minecraft:soul_lantern[hanging=true]
execute unless block 1 68 53 minecraft:soul_lantern run setblock 1 68 53 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 53 minecraft:iron_chain run setblock -2 62 53 minecraft:iron_chain
execute unless block -2 61 53 minecraft:iron_chain run setblock -2 61 53 minecraft:iron_chain
execute unless block 2 62 53 minecraft:iron_chain run setblock 2 62 53 minecraft:iron_chain
execute unless block 2 61 53 minecraft:iron_chain run setblock 2 61 53 minecraft:iron_chain
execute as @e[type=marker,tag=nw.laterne,x=-3,y=63,z=9,dx=6,dy=5,dz=50] at @s run function nachtwache:laterne/halten
