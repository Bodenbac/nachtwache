fill -1 63 9 1 63 59 minecraft:polished_blackstone_bricks
fill -2 63 9 -2 63 62 minecraft:polished_deepslate
fill 2 63 9 2 63 62 minecraft:polished_deepslate
fill -1 60 9 1 62 59 minecraft:air
fill -3 60 9 -3 70 62 minecraft:air
fill 3 60 9 3 70 62 minecraft:air
fill -2 68 9 2 70 62 minecraft:air
fill -2 64 9 -2 66 10 minecraft:deepslate_bricks
fill 2 64 9 2 66 10 minecraft:deepslate_bricks
fill -1 67 9 1 67 10 minecraft:iron_bars
fill -2 67 9 -2 67 10 minecraft:deepslate_bricks
fill 2 67 9 2 67 10 minecraft:deepslate_bricks
fill -1 64 9 1 66 10 minecraft:air
fill -2 64 12 -2 66 16 minecraft:deepslate_bricks
fill 2 64 12 2 66 16 minecraft:deepslate_bricks
fill -1 67 12 1 67 16 minecraft:iron_bars
fill -2 67 12 -2 67 16 minecraft:deepslate_bricks
fill 2 67 12 2 67 16 minecraft:deepslate_bricks
fill -1 64 12 1 66 16 minecraft:air
fill -2 64 18 -2 66 22 minecraft:deepslate_bricks
fill 2 64 18 2 66 22 minecraft:deepslate_bricks
fill -1 67 18 1 67 22 minecraft:iron_bars
fill -2 67 18 -2 67 22 minecraft:deepslate_bricks
fill 2 67 18 2 67 22 minecraft:deepslate_bricks
fill -1 64 18 1 66 22 minecraft:air
fill -2 64 24 -2 66 28 minecraft:deepslate_bricks
fill 2 64 24 2 66 28 minecraft:deepslate_bricks
fill -1 67 24 1 67 28 minecraft:iron_bars
fill -2 67 24 -2 67 28 minecraft:deepslate_bricks
fill 2 67 24 2 67 28 minecraft:deepslate_bricks
fill -1 64 24 1 66 28 minecraft:air
fill -2 64 30 -2 66 34 minecraft:deepslate_bricks
fill 2 64 30 2 66 34 minecraft:deepslate_bricks
fill -1 67 30 1 67 34 minecraft:iron_bars
fill -2 67 30 -2 67 34 minecraft:deepslate_bricks
fill 2 67 30 2 67 34 minecraft:deepslate_bricks
fill -1 64 30 1 66 34 minecraft:air
fill -2 64 36 -2 66 40 minecraft:deepslate_bricks
fill 2 64 36 2 66 40 minecraft:deepslate_bricks
fill -1 67 36 1 67 40 minecraft:iron_bars
fill -2 67 36 -2 67 40 minecraft:deepslate_bricks
fill 2 67 36 2 67 40 minecraft:deepslate_bricks
fill -1 64 36 1 66 40 minecraft:air
fill -2 64 42 -2 66 46 minecraft:deepslate_bricks
fill 2 64 42 2 66 46 minecraft:deepslate_bricks
fill -1 67 42 1 67 46 minecraft:iron_bars
fill -2 67 42 -2 67 46 minecraft:deepslate_bricks
fill 2 67 42 2 67 46 minecraft:deepslate_bricks
fill -1 64 42 1 66 46 minecraft:air
fill -2 64 48 -2 66 52 minecraft:deepslate_bricks
fill 2 64 48 2 66 52 minecraft:deepslate_bricks
fill -1 67 48 1 67 52 minecraft:iron_bars
fill -2 67 48 -2 67 52 minecraft:deepslate_bricks
fill 2 67 48 2 67 52 minecraft:deepslate_bricks
fill -1 64 48 1 66 52 minecraft:air
fill -2 64 54 -2 66 62 minecraft:deepslate_bricks
fill 2 64 54 2 66 62 minecraft:deepslate_bricks
fill -1 67 54 1 67 62 minecraft:iron_bars
fill -2 67 54 -2 67 62 minecraft:deepslate_bricks
fill 2 67 54 2 67 62 minecraft:deepslate_bricks
fill -1 64 54 1 66 62 minecraft:air
fill -2 64 11 -2 67 11 minecraft:polished_blackstone_bricks
fill 2 64 11 2 67 11 minecraft:polished_blackstone_bricks
fill -1 67 11 1 67 11 minecraft:polished_blackstone_bricks
fill -1 64 11 1 65 11 minecraft:air
setblock 0 66 11 minecraft:air
execute unless block -1 66 11 minecraft:soul_lantern run setblock -1 66 11 minecraft:soul_lantern[hanging=true]
execute unless block 1 66 11 minecraft:soul_lantern run setblock 1 66 11 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 11 minecraft:iron_chain run setblock -2 62 11 minecraft:iron_chain
execute unless block -2 61 11 minecraft:iron_chain run setblock -2 61 11 minecraft:iron_chain
execute unless block 2 62 11 minecraft:iron_chain run setblock 2 62 11 minecraft:iron_chain
execute unless block 2 61 11 minecraft:iron_chain run setblock 2 61 11 minecraft:iron_chain
fill -2 64 17 -2 67 17 minecraft:polished_blackstone_bricks
fill 2 64 17 2 67 17 minecraft:polished_blackstone_bricks
fill -1 67 17 1 67 17 minecraft:polished_blackstone_bricks
fill -1 64 17 1 65 17 minecraft:air
setblock 0 66 17 minecraft:air
execute unless block -1 66 17 minecraft:soul_lantern run setblock -1 66 17 minecraft:soul_lantern[hanging=true]
execute unless block 1 66 17 minecraft:soul_lantern run setblock 1 66 17 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 17 minecraft:iron_chain run setblock -2 62 17 minecraft:iron_chain
execute unless block -2 61 17 minecraft:iron_chain run setblock -2 61 17 minecraft:iron_chain
execute unless block 2 62 17 minecraft:iron_chain run setblock 2 62 17 minecraft:iron_chain
execute unless block 2 61 17 minecraft:iron_chain run setblock 2 61 17 minecraft:iron_chain
fill -2 64 23 -2 67 23 minecraft:polished_blackstone_bricks
fill 2 64 23 2 67 23 minecraft:polished_blackstone_bricks
fill -1 67 23 1 67 23 minecraft:polished_blackstone_bricks
fill -1 64 23 1 65 23 minecraft:air
setblock 0 66 23 minecraft:air
execute unless block -1 66 23 minecraft:soul_lantern run setblock -1 66 23 minecraft:soul_lantern[hanging=true]
execute unless block 1 66 23 minecraft:soul_lantern run setblock 1 66 23 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 23 minecraft:iron_chain run setblock -2 62 23 minecraft:iron_chain
execute unless block -2 61 23 minecraft:iron_chain run setblock -2 61 23 minecraft:iron_chain
execute unless block 2 62 23 minecraft:iron_chain run setblock 2 62 23 minecraft:iron_chain
execute unless block 2 61 23 minecraft:iron_chain run setblock 2 61 23 minecraft:iron_chain
fill -2 64 29 -2 67 29 minecraft:polished_blackstone_bricks
fill 2 64 29 2 67 29 minecraft:polished_blackstone_bricks
fill -1 67 29 1 67 29 minecraft:polished_blackstone_bricks
fill -1 64 29 1 65 29 minecraft:air
setblock 0 66 29 minecraft:air
execute unless block -1 66 29 minecraft:soul_lantern run setblock -1 66 29 minecraft:soul_lantern[hanging=true]
execute unless block 1 66 29 minecraft:soul_lantern run setblock 1 66 29 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 29 minecraft:iron_chain run setblock -2 62 29 minecraft:iron_chain
execute unless block -2 61 29 minecraft:iron_chain run setblock -2 61 29 minecraft:iron_chain
execute unless block 2 62 29 minecraft:iron_chain run setblock 2 62 29 minecraft:iron_chain
execute unless block 2 61 29 minecraft:iron_chain run setblock 2 61 29 minecraft:iron_chain
fill -2 64 35 -2 67 35 minecraft:polished_blackstone_bricks
fill 2 64 35 2 67 35 minecraft:polished_blackstone_bricks
fill -1 67 35 1 67 35 minecraft:polished_blackstone_bricks
fill -1 64 35 1 65 35 minecraft:air
setblock 0 66 35 minecraft:air
execute unless block -1 66 35 minecraft:soul_lantern run setblock -1 66 35 minecraft:soul_lantern[hanging=true]
execute unless block 1 66 35 minecraft:soul_lantern run setblock 1 66 35 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 35 minecraft:iron_chain run setblock -2 62 35 minecraft:iron_chain
execute unless block -2 61 35 minecraft:iron_chain run setblock -2 61 35 minecraft:iron_chain
execute unless block 2 62 35 minecraft:iron_chain run setblock 2 62 35 minecraft:iron_chain
execute unless block 2 61 35 minecraft:iron_chain run setblock 2 61 35 minecraft:iron_chain
fill -2 64 41 -2 67 41 minecraft:polished_blackstone_bricks
fill 2 64 41 2 67 41 minecraft:polished_blackstone_bricks
fill -1 67 41 1 67 41 minecraft:polished_blackstone_bricks
fill -1 64 41 1 65 41 minecraft:air
setblock 0 66 41 minecraft:air
execute unless block -1 66 41 minecraft:soul_lantern run setblock -1 66 41 minecraft:soul_lantern[hanging=true]
execute unless block 1 66 41 minecraft:soul_lantern run setblock 1 66 41 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 41 minecraft:iron_chain run setblock -2 62 41 minecraft:iron_chain
execute unless block -2 61 41 minecraft:iron_chain run setblock -2 61 41 minecraft:iron_chain
execute unless block 2 62 41 minecraft:iron_chain run setblock 2 62 41 minecraft:iron_chain
execute unless block 2 61 41 minecraft:iron_chain run setblock 2 61 41 minecraft:iron_chain
fill -2 64 47 -2 67 47 minecraft:polished_blackstone_bricks
fill 2 64 47 2 67 47 minecraft:polished_blackstone_bricks
fill -1 67 47 1 67 47 minecraft:polished_blackstone_bricks
fill -1 64 47 1 65 47 minecraft:air
setblock 0 66 47 minecraft:air
execute unless block -1 66 47 minecraft:soul_lantern run setblock -1 66 47 minecraft:soul_lantern[hanging=true]
execute unless block 1 66 47 minecraft:soul_lantern run setblock 1 66 47 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 47 minecraft:iron_chain run setblock -2 62 47 minecraft:iron_chain
execute unless block -2 61 47 minecraft:iron_chain run setblock -2 61 47 minecraft:iron_chain
execute unless block 2 62 47 minecraft:iron_chain run setblock 2 62 47 minecraft:iron_chain
execute unless block 2 61 47 minecraft:iron_chain run setblock 2 61 47 minecraft:iron_chain
fill -2 64 53 -2 67 53 minecraft:polished_blackstone_bricks
fill 2 64 53 2 67 53 minecraft:polished_blackstone_bricks
fill -1 67 53 1 67 53 minecraft:polished_blackstone_bricks
fill -1 64 53 1 65 53 minecraft:air
setblock 0 66 53 minecraft:air
execute unless block -1 66 53 minecraft:soul_lantern run setblock -1 66 53 minecraft:soul_lantern[hanging=true]
execute unless block 1 66 53 minecraft:soul_lantern run setblock 1 66 53 minecraft:soul_lantern[hanging=true]
execute unless block -2 62 53 minecraft:iron_chain run setblock -2 62 53 minecraft:iron_chain
execute unless block -2 61 53 minecraft:iron_chain run setblock -2 61 53 minecraft:iron_chain
execute unless block 2 62 53 minecraft:iron_chain run setblock 2 62 53 minecraft:iron_chain
execute unless block 2 61 53 minecraft:iron_chain run setblock 2 61 53 minecraft:iron_chain
execute as @e[type=marker,tag=nw.laterne,x=-3,y=63,z=9,dx=6,dy=3,dz=50] at @s run function nachtwache:laterne/halten
