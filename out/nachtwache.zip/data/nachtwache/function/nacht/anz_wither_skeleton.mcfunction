scoreboard players operation #c nw.tmp2 = #wn nw.tmp2
scoreboard players remove #c nw.tmp2 5
scoreboard players set #k nw.tmp2 2
scoreboard players operation #c nw.tmp2 /= #k nw.tmp2
scoreboard players set #k nw.tmp2 1
scoreboard players operation #c nw.tmp2 *= #k nw.tmp2
scoreboard players add #c nw.tmp2 2
execute if score #kontrakt nw.upgrade matches 1.. run scoreboard players set #k nw.tmp2 130
execute if score #kontrakt nw.upgrade matches 1.. run scoreboard players operation #c nw.tmp2 *= #k nw.tmp2
execute if score #kontrakt nw.upgrade matches 1.. run scoreboard players operation #c nw.tmp2 /= #100 nw.const
scoreboard players operation #n_wither_skeleton nw.tmp = #c nw.tmp2
scoreboard players operation #anz0 nw.tmp += #c nw.tmp2
