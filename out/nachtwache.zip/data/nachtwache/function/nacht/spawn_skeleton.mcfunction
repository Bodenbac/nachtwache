execute if score #n_skeleton nw.tmp matches ..0 run return 0
summon minecraft:skeleton 0.5 64 67.5 {Tags:["nw.welle","nw.a_skeleton","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{head:{id:"minecraft:leather_helmet",count:1,components:{"minecraft:unbreakable":{},"minecraft:dyed_color":1315860}},mainhand:{id:"minecraft:bow",count:1}},drop_chances:{head:0.0f,mainhand:0.05f}}
scoreboard players remove #n_skeleton nw.tmp 1
function nachtwache:nacht/spawn_skeleton
