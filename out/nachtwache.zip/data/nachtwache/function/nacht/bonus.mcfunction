scoreboard players operation #b nw.tmp = #nacht nw.nacht
scoreboard players operation #b nw.tmp *= #16 nw.const
scoreboard players operation #konto nw.konto += #b nw.tmp
scoreboard players operation #verdient nw.verdient += #b nw.tmp
tellraw @a [{"text":"The whole wave is dead. Bonus: ","color":"green"},{"score":{"name":"#b","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"green"},{"text":"●","color":"white"}]
execute if score #nacht nw.nacht matches 10.. run loot give @a loot nachtwache:belohnung
execute if score #nacht nw.nacht matches 10.. run tellraw @a [{"text":"Something extra is in your inventory. From the Collector. Supposedly.","color":"gray","italic":true}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
