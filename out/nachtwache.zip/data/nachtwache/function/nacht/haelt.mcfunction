execute if score #nacht_haelt nw.status matches 1 run return 0
scoreboard players set #nacht_haelt nw.status 1
tellraw @a [{"text":"The night stays until nothing is left alive.","color":"dark_red","italic":true}]
playsound minecraft:entity.warden.heartbeat hostile @a ~ ~ ~ 1 0.5
