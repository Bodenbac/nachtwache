execute unless entity @e[tag=nw.boss_finale] run return 0
execute as @e[tag=nw.boss_finale] run data modify entity @s Brain.memories."minecraft:dig_cooldown" set value {value:{},ttl:6000L}
execute as @e[tag=nw.boss_finale] run data modify entity @s anger set value {suspects:[{uuid:[I;0,0,0,0],anger:150}]}
execute as @e[tag=nw.boss_finale] at @s if entity @p run data modify entity @s anger.suspects[0].uuid set from entity @p UUID
