execute if score #n_ghast nw.tmp matches ..0 run return 0
summon minecraft:ghast 0.5 76 67.5 {Tags:["nw.welle","nw.a_ghast","nw.flieger"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],ExplosionPower:0b}
scoreboard players remove #n_ghast nw.tmp 1
function nachtwache:nacht/spawn_ghast
