scoreboard players set #boss nw.boss 0
bossbar set nw:boss visible false
scoreboard players add #konto nw.konto 150
scoreboard players add #verdient nw.verdient 150
execute if score #finale nw.status matches 1 run return run function nachtwache:nacht/sieg
tellraw @a [{"text":"The boss is dead. ","color":"dark_purple"},{"text":"+150 ","color":"gray"},{"text":"●","color":"white"},{"text":" and something from his pocket.","color":"gray"}]
loot give @a loot nachtwache:bossbeute
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.8
