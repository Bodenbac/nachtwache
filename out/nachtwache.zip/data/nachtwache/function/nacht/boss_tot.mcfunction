scoreboard players set #boss nw.boss 0
bossbar set nw:boss visible false
scoreboard players set #d nw.tmp 150
execute if score #kontrakt nw.upgrade matches 2 run scoreboard players operation #d nw.tmp *= #2 nw.const
scoreboard players operation #konto nw.konto += #d nw.tmp
scoreboard players operation #verdient nw.verdient += #d nw.tmp
execute if score #finale nw.status matches 1 run return run function nachtwache:nacht/sieg
tellraw @a [{"text":"The boss is dead. ","color":"dark_purple"},{"text":"+150 ","color":"gray"},{"text":"●","color":"white"},{"text":" and something from his pocket.","color":"gray"}]
loot give @a loot nachtwache:bossbeute
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.8
