summon minecraft:ravager 0.5 64 67.5 {Tags:["nw.welle","nw.boss","nw.bosstrupp","nw.boss_koloss"],CustomName:{text:"The Colossus",color:"dark_purple",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,Glowing:1b,attributes:[{id:"minecraft:follow_range",base:128d},{id:"minecraft:max_health",base:150d},{id:"minecraft:movement_speed",base:0.24d},{id:"minecraft:knockback_resistance",base:1.0d}],Health:150f}
summon minecraft:zombie 0.5 64 67.5 {Tags:["nw.welle","nw.a_brutalo","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,CanBreakDoors:1b,CustomName:"Brute",attributes:[{id:"minecraft:follow_range",base:100d},{id:"minecraft:max_health",base:40d},{id:"minecraft:attack_damage",base:7d},{id:"minecraft:movement_speed",base:0.27d}],Health:40f,equipment:{head:{id:"minecraft:iron_chainmail_helmet",count:1}},drop_chances:{head:0.0f},active_effects:[{id:"minecraft:strength",duration:-1,amplifier:0,show_particles:0b}]}
summon minecraft:zombie 0.5 64 67.5 {Tags:["nw.welle","nw.a_brutalo","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,CanBreakDoors:1b,CustomName:"Brute",attributes:[{id:"minecraft:follow_range",base:100d},{id:"minecraft:max_health",base:40d},{id:"minecraft:attack_damage",base:7d},{id:"minecraft:movement_speed",base:0.27d}],Health:40f,equipment:{head:{id:"minecraft:iron_chainmail_helmet",count:1}},drop_chances:{head:0.0f},active_effects:[{id:"minecraft:strength",duration:-1,amplifier:0,show_particles:0b}]}
summon minecraft:zombie 0.5 64 67.5 {Tags:["nw.welle","nw.a_brutalo","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,CanBreakDoors:1b,CustomName:"Brute",attributes:[{id:"minecraft:follow_range",base:100d},{id:"minecraft:max_health",base:40d},{id:"minecraft:attack_damage",base:7d},{id:"minecraft:movement_speed",base:0.27d}],Health:40f,equipment:{head:{id:"minecraft:iron_chainmail_helmet",count:1}},drop_chances:{head:0.0f},active_effects:[{id:"minecraft:strength",duration:-1,amplifier:0,show_particles:0b}]}
summon minecraft:zombie 0.5 64 67.5 {Tags:["nw.welle","nw.a_brutalo","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,CanBreakDoors:1b,CustomName:"Brute",attributes:[{id:"minecraft:follow_range",base:100d},{id:"minecraft:max_health",base:40d},{id:"minecraft:attack_damage",base:7d},{id:"minecraft:movement_speed",base:0.27d}],Health:40f,equipment:{head:{id:"minecraft:iron_chainmail_helmet",count:1}},drop_chances:{head:0.0f},active_effects:[{id:"minecraft:strength",duration:-1,amplifier:0,show_particles:0b}]}
spreadplayers 0 72 2 9 false @e[tag=nw.neu]
tag @e[tag=nw.neu] remove nw.neu
bossbar set nw:boss name [{"text":"The Colossus","color":"dark_purple","bold":true}]
bossbar set nw:boss max 150
bossbar set nw:boss value 150
bossbar set nw:boss players @a
bossbar set nw:boss visible true
scoreboard players set #boss nw.boss 1
title @a subtitle [{"text":"The Colossus is coming for you.","color":"dark_purple"}]
title @a title [{"text":"Night ","color":"dark_red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"dark_red"}]
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 0.7 0.5
function nachtwache:nacht/warden_wut
