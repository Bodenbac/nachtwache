summon minecraft:ravager 0.5 64 67.5 {Tags:["nw.welle","nw.boss"],CustomName:{text:"The Colossus",color:"dark_purple",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,Glowing:1b,attributes:[{id:"minecraft:follow_range",base:100d},{id:"minecraft:max_health",base:150d}],Health:150f}
bossbar set nw:boss name [{"text":"The Colossus","color":"dark_purple","bold":true}]
bossbar set nw:boss max 150
bossbar set nw:boss value 150
bossbar set nw:boss players @a
bossbar set nw:boss visible true
scoreboard players set #boss nw.boss 1
title @a subtitle [{"text":"The Colossus is on the road.","color":"dark_purple"}]
title @a title [{"text":"Night ","color":"dark_red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"dark_red"}]
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 0.7 0.5
function nachtwache:nacht/warden_wut
