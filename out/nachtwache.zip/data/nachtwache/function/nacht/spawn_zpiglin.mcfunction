execute if score #n_zpiglin nw.tmp matches ..0 run return 0
summon minecraft:zombified_piglin 0.5 64 67.5 {Tags:["nw.welle","nw.a_zpiglin","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{mainhand:{id:"minecraft:golden_sword",count:1}},drop_chances:{mainhand:0.0f}}
scoreboard players remove #n_zpiglin nw.tmp 1
function nachtwache:nacht/spawn_zpiglin
