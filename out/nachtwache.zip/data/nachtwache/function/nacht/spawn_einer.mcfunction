execute if score #nacht nw.nacht matches 1..3 run return run function nachtwache:nacht/typ_1
execute if score #nacht nw.nacht matches 4..6 run return run function nachtwache:nacht/typ_2
execute if score #nacht nw.nacht matches 7..10 run return run function nachtwache:nacht/typ_3
execute if score #nacht nw.nacht matches 11..14 run return run function nachtwache:nacht/typ_4
execute if score #nacht nw.nacht matches 15..19 run return run function nachtwache:nacht/typ_5
execute if score #nacht nw.nacht matches 20..24 run return run function nachtwache:nacht/typ_6
execute if score #nacht nw.nacht matches 25..999 run return run function nachtwache:nacht/typ_7
