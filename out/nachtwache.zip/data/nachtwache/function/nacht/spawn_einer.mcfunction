execute if score #nacht nw.nacht matches 1..4 run return run function nachtwache:nacht/typ_1
execute if score #nacht nw.nacht matches 5..7 run return run function nachtwache:nacht/typ_2
execute if score #nacht nw.nacht matches 8..11 run return run function nachtwache:nacht/typ_3
execute if score #nacht nw.nacht matches 12..15 run return run function nachtwache:nacht/typ_4
execute if score #nacht nw.nacht matches 16..19 run return run function nachtwache:nacht/typ_5
execute if score #nacht nw.nacht matches 20..24 run return run function nachtwache:nacht/typ_6
execute if score #nacht nw.nacht matches 25..999 run return run function nachtwache:nacht/typ_7
