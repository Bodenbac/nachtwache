summon minecraft:skeleton 0.5 64 67.5 {Tags:["nw.welle","nw.boss","nw.boss_schuetze"],CustomName:{text:"The Marksman",color:"dark_purple",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,Glowing:1b,attributes:[{id:"minecraft:follow_range",base:100d},{id:"minecraft:max_health",base:60d}],Health:60f,equipment:{head:{id:"minecraft:leather_helmet",count:1,components:{"minecraft:unbreakable":{},"minecraft:dyed_color":1315860}},mainhand:{id:"minecraft:bow",count:1,components:{"minecraft:enchantments":{"minecraft:power":5}}}},drop_chances:{head:0.0f,mainhand:0.0f}}
bossbar set nw:boss name [{"text":"The Marksman","color":"dark_purple","bold":true}]
bossbar set nw:boss max 60
bossbar set nw:boss value 60
bossbar set nw:boss players @a
bossbar set nw:boss visible true
scoreboard players set #boss nw.boss 1
title @a subtitle [{"text":"The Marksman is on the road.","color":"dark_purple"}]
title @a title [{"text":"Night ","color":"dark_red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"dark_red"}]
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 0.7 0.5
function nachtwache:nacht/warden_wut
