scoreboard players set #status nw.status 0
function nachtwache:strasse/entfernen
execute as @a[scores={nw.schlaf=1..}] run tp @s ~ ~ ~
effect give @e[tag=nw.welle] minecraft:glowing infinite 0 true
execute as @e[tag=nw.welle,x=-30,y=0,z=60,dx=60,dy=200,dz=40] run tp @s 2.5 64 6.5
execute if score #gegner nw.gegner matches 0 run function nachtwache:nacht/bonus
execute if score #gegner nw.gegner matches 1.. run tellraw @a [{"text":"Dawn breaks. ","color":"gray"},{"score":{"name":"#gegner","objective":"nw.gegner"},"color":"red"},{"text":" enemies are still alive. They glow, and they are coming.","color":"gray"}]
execute if score #gegner nw.gegner matches 1.. run playsound minecraft:entity.zombie.ambient hostile @a ~ ~ ~ 1 0.5
function nachtwache:sammler/spruch/morgen
execute if score #kontrakt nw.upgrade matches 2 run tellraw @a [{"text":"[The Collector] ","color":"dark_red"},{"text":"The contract is fulfilled. Pleasure doing business.","color":"gray"}]
execute if score #kontrakt nw.upgrade matches 2 run scoreboard players set #kontrakt nw.upgrade 0
scoreboard players add @e[type=marker,tag=nw.laterne] nw.laterne 1
execute as @e[type=marker,tag=nw.laterne,scores={nw.laterne=3..}] at @s run function nachtwache:laterne/erloschen
