execute if score #n_zombie_baby nw.tmp matches ..0 run return 0
summon minecraft:zombie 0.5 64 67.5 {Tags:["nw.welle","nw.a_zombie_baby","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{head:{id:"minecraft:leather_helmet",count:1,components:{"minecraft:unbreakable":{},"minecraft:dyed_color":1315860}}},drop_chances:{head:0.0f},CanBreakDoors:1b,IsBaby:1b}
scoreboard players remove #n_zombie_baby nw.tmp 1
function nachtwache:nacht/spawn_zombie_baby
