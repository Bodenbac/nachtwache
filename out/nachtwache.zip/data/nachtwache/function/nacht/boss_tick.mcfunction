execute unless score #boss nw.boss matches 1 run return 0
execute store result bossbar nw:boss value run data get entity @e[tag=nw.boss,limit=1] Health
execute unless entity @e[tag=nw.boss] run return run function nachtwache:nacht/boss_tot
scoreboard players operation #m200 nw.tmp2 = #tick nw.tick
scoreboard players operation #m200 nw.tmp2 %= #200 nw.const
execute unless score #m200 nw.tmp2 matches 0 run return 0
execute store result score #cs nw.tmp2 if entity @e[type=cave_spider,tag=nw.welle]
execute if score #cs nw.tmp2 matches ..7 as @e[tag=nw.boss_mutter] at @s run summon minecraft:cave_spider ~ ~ ~ {Tags:["nw.welle"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
execute if score #cs nw.tmp2 matches ..6 as @e[tag=nw.boss_mutter] at @s run summon minecraft:cave_spider ~ ~ ~ {Tags:["nw.welle"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
execute as @e[tag=nw.boss_hexe] at @s run summon minecraft:zombie ~ ~ ~ {Tags:["nw.welle"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{head:{id:"minecraft:leather_helmet",count:1,components:{"minecraft:unbreakable":{},"minecraft:dyed_color":1315860}}},drop_chances:{head:0.0f},CanBreakDoors:1b}
execute as @e[tag=nw.boss_hexe] at @s run summon minecraft:zombie ~ ~ ~ {Tags:["nw.welle"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{head:{id:"minecraft:leather_helmet",count:1,components:{"minecraft:unbreakable":{},"minecraft:dyed_color":1315860}}},drop_chances:{head:0.0f},CanBreakDoors:1b}
function nachtwache:nacht/warden_wut
