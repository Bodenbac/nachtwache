execute unless score #boss nw.boss matches 1 run return 0
execute store result bossbar nw:boss value run data get entity @e[tag=nw.boss,limit=1] Health
execute unless entity @e[tag=nw.boss] run return run function nachtwache:nacht/boss_tot
execute as @e[tag=nw.boss_schuetze] at @s run function nachtwache:nacht/boss_rueckzug
execute as @e[tag=nw.boss_mutter] at @s run function nachtwache:nacht/boss_rueckzug
execute as @e[tag=nw.boss_hexe] at @s run function nachtwache:nacht/boss_rueckzug
scoreboard players operation #ms nw.tmp2 = #tick nw.tick
scoreboard players set #k nw.tmp2 40
scoreboard players operation #ms nw.tmp2 %= #k nw.tmp2
execute if score #ms nw.tmp2 matches 0 as @e[tag=nw.boss_schuetze] at @s run function nachtwache:nacht/boss_schuss
scoreboard players operation #m200 nw.tmp2 = #tick nw.tick
scoreboard players operation #m200 nw.tmp2 %= #200 nw.const
execute unless score #m200 nw.tmp2 matches 0 run return 0
execute store result score #cs nw.tmp2 if entity @e[type=cave_spider,tag=nw.welle]
execute if score #cs nw.tmp2 matches ..5 as @e[tag=nw.boss_mutter] at @s run summon minecraft:cave_spider ~ ~ ~ {Tags:["nw.welle","nw.a_cave_spider","nw.bosstrupp"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
execute if score #cs nw.tmp2 matches ..4 as @e[tag=nw.boss_mutter] at @s run summon minecraft:cave_spider ~ ~ ~ {Tags:["nw.welle","nw.a_cave_spider","nw.bosstrupp"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
execute as @e[tag=nw.boss_hexe] at @s run effect give @e[tag=nw.welle,distance=..12] minecraft:instant_health 1 0 true
execute as @e[tag=nw.boss_hexe] at @s run particle minecraft:happy_villager ~ ~1 ~ 6 1 6 0 30
function nachtwache:nacht/warden_wut
