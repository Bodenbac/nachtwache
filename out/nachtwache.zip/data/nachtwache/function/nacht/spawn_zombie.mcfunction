execute if score #n_zombie nw.tmp matches ..0 run return 0
function nachtwache:nacht/zombie_variante
scoreboard players remove #n_zombie nw.tmp 1
function nachtwache:nacht/spawn_zombie
