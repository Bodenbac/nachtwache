scoreboard players set #finale nw.status 1
function nachtwache:sammler/spruch/finale
kill @e[tag=nw.villager]
kill @e[tag=nw.sammler]
title @a subtitle [{"text":"The last night. The stall is empty.","color":"dark_purple"}]
