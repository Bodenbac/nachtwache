scoreboard players set #anz0 nw.tmp 0
scoreboard players operation #wn nw.tmp2 = #nacht nw.nacht
execute if score #wn nw.tmp2 matches 36.. run scoreboard players set #wn nw.tmp2 35
scoreboard players set #n_zombie nw.tmp 0
execute if score #wn nw.tmp2 matches 1.. unless score #welt nw.status matches 1 run function nachtwache:nacht/anz_zombie
execute if score #wn nw.tmp2 matches 1.. unless score #welt nw.status matches 1 run function nachtwache:nacht/spawn_zombie
scoreboard players set #n_spider nw.tmp 0
execute if score #wn nw.tmp2 matches 2.. unless score #welt nw.status matches 1 run function nachtwache:nacht/anz_spider
execute if score #wn nw.tmp2 matches 2.. unless score #welt nw.status matches 1 run function nachtwache:nacht/spawn_spider
scoreboard players set #n_skeleton nw.tmp 0
execute if score #wn nw.tmp2 matches 3.. unless score #welt nw.status matches 1 run function nachtwache:nacht/anz_skeleton
execute if score #wn nw.tmp2 matches 3.. unless score #welt nw.status matches 1 run function nachtwache:nacht/spawn_skeleton
scoreboard players set #n_zombie_baby nw.tmp 0
execute if score #wn nw.tmp2 matches 7.. unless score #welt nw.status matches 1 run function nachtwache:nacht/anz_zombie_baby
execute if score #wn nw.tmp2 matches 7.. unless score #welt nw.status matches 1 run function nachtwache:nacht/spawn_zombie_baby
scoreboard players set #n_enderman nw.tmp 0
execute if score #wn nw.tmp2 matches 9.. unless score #welt nw.status matches 1 run function nachtwache:nacht/anz_enderman
execute if score #wn nw.tmp2 matches 9.. unless score #welt nw.status matches 1 run function nachtwache:nacht/spawn_enderman
scoreboard players set #n_witch nw.tmp 0
execute if score #wn nw.tmp2 matches 11.. unless score #welt nw.status matches 1 run function nachtwache:nacht/anz_witch
execute if score #wn nw.tmp2 matches 11.. unless score #welt nw.status matches 1 run function nachtwache:nacht/spawn_witch
scoreboard players set #n_zpiglin nw.tmp 0
execute if score #wn nw.tmp2 matches 1.. if score #welt nw.status matches 1 run function nachtwache:nacht/anz_zpiglin
execute if score #wn nw.tmp2 matches 1.. if score #welt nw.status matches 1 run function nachtwache:nacht/spawn_zpiglin
scoreboard players set #n_magma nw.tmp 0
execute if score #wn nw.tmp2 matches 2.. if score #welt nw.status matches 1 run function nachtwache:nacht/anz_magma
execute if score #wn nw.tmp2 matches 2.. if score #welt nw.status matches 1 run function nachtwache:nacht/spawn_magma
scoreboard players set #n_blaze nw.tmp 0
execute if score #wn nw.tmp2 matches 3.. if score #welt nw.status matches 1 run function nachtwache:nacht/anz_blaze
execute if score #wn nw.tmp2 matches 3.. if score #welt nw.status matches 1 run function nachtwache:nacht/spawn_blaze
scoreboard players set #n_ghast nw.tmp 0
execute if score #wn nw.tmp2 matches 4.. if score #welt nw.status matches 1 run function nachtwache:nacht/anz_ghast
execute if score #wn nw.tmp2 matches 4.. if score #welt nw.status matches 1 run function nachtwache:nacht/spawn_ghast
scoreboard players set #n_wither_skeleton nw.tmp 0
execute if score #wn nw.tmp2 matches 5.. if score #welt nw.status matches 1 run function nachtwache:nacht/anz_wither_skeleton
execute if score #wn nw.tmp2 matches 5.. if score #welt nw.status matches 1 run function nachtwache:nacht/spawn_wither_skeleton
execute if score #kontrakt nw.upgrade matches 1 run scoreboard players set #kontrakt nw.upgrade 2
spreadplayers 0 72 2 9 false @e[tag=nw.neu]
tag @e[tag=nw.neu] remove nw.neu
execute store result bossbar nw:welle max run scoreboard players get #anz0 nw.tmp
bossbar set nw:welle players @a
bossbar set nw:welle visible true
