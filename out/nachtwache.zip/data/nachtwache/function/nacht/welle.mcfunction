scoreboard players operation #anz nw.tmp = #nacht nw.nacht
scoreboard players set #k nw.tmp2 2
scoreboard players operation #anz nw.tmp *= #k nw.tmp2
scoreboard players add #anz nw.tmp 4
execute if score #phase nw.phase matches 1 run scoreboard players set #f nw.tmp2 10
execute if score #phase nw.phase matches 2 run scoreboard players set #f nw.tmp2 10
execute if score #phase nw.phase matches 3 run scoreboard players set #f nw.tmp2 10
execute if score #phase nw.phase matches 4 run scoreboard players set #f nw.tmp2 10
execute if score #phase nw.phase matches 5 run scoreboard players set #f nw.tmp2 10
execute if score #phase nw.phase matches 6 run scoreboard players set #f nw.tmp2 10
execute if score #phase nw.phase matches 7 run scoreboard players set #f nw.tmp2 10
scoreboard players operation #anz nw.tmp *= #f nw.tmp2
scoreboard players operation #anz nw.tmp /= #10 nw.const
execute if score #nacht nw.nacht matches 30 unless score #modus nw.status matches 2 run scoreboard players operation #anz nw.tmp *= #2 nw.const
execute if score #kontrakt nw.upgrade matches 1.. run scoreboard players operation #anz nw.tmp *= #3 nw.const
execute if score #kontrakt nw.upgrade matches 1.. run scoreboard players operation #anz nw.tmp /= #2 nw.const
execute if score #kontrakt nw.upgrade matches 1 run scoreboard players set #kontrakt nw.upgrade 2
execute if score #anz nw.tmp matches 151.. run scoreboard players set #anz nw.tmp 150
scoreboard players operation #anz0 nw.tmp = #anz nw.tmp
function nachtwache:nacht/spawn_schleife
spreadplayers 0 72 2 9 false @e[tag=nw.neu]
tag @e[tag=nw.neu] remove nw.neu
execute store result bossbar nw:welle max run scoreboard players get #anz0 nw.tmp
bossbar set nw:welle players @a
bossbar set nw:welle visible true
