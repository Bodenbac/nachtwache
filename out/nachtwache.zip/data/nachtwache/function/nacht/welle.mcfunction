scoreboard players set #anz0 nw.tmp 0
scoreboard players operation #wn nw.tmp2 = #nacht nw.nacht
execute if score #wn nw.tmp2 matches 36.. run scoreboard players set #wn nw.tmp2 35
scoreboard players set #n_zombie nw.tmp 0
execute if score #wn nw.tmp2 matches 1.. run function nachtwache:nacht/anz_zombie
execute if score #wn nw.tmp2 matches 1.. run function nachtwache:nacht/spawn_zombie
scoreboard players set #n_skeleton nw.tmp 0
execute if score #wn nw.tmp2 matches 3.. run function nachtwache:nacht/anz_skeleton
execute if score #wn nw.tmp2 matches 3.. run function nachtwache:nacht/spawn_skeleton
scoreboard players set #n_spider nw.tmp 0
execute if score #wn nw.tmp2 matches 3.. run function nachtwache:nacht/anz_spider
execute if score #wn nw.tmp2 matches 3.. run function nachtwache:nacht/spawn_spider
scoreboard players set #n_zombie_baby nw.tmp 0
execute if score #wn nw.tmp2 matches 5.. run function nachtwache:nacht/anz_zombie_baby
execute if score #wn nw.tmp2 matches 5.. run function nachtwache:nacht/spawn_zombie_baby
scoreboard players set #n_enderman nw.tmp 0
execute if score #wn nw.tmp2 matches 10.. run function nachtwache:nacht/anz_enderman
execute if score #wn nw.tmp2 matches 10.. run function nachtwache:nacht/spawn_enderman
execute if score #kontrakt nw.upgrade matches 1 run scoreboard players set #kontrakt nw.upgrade 2
spreadplayers 0 72 2 9 false @e[tag=nw.neu]
tag @e[tag=nw.neu] remove nw.neu
execute store result bossbar nw:welle max run scoreboard players get #anz0 nw.tmp
bossbar set nw:welle players @a
bossbar set nw:welle visible true
