scoreboard players set #bossart nw.boss 107
summon minecraft:ghast 0.5 76 67.5 {Tags:["nw.welle","nw.boss","nw.bosstrupp","nw.boss_heuler","nw.flieger"],CustomName:{text:"The Howler",color:"dark_purple",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,Glowing:1b,attributes:[{id:"minecraft:follow_range",base:128d},{id:"minecraft:max_health",base:100d}],Health:100f,ExplosionPower:0b}
summon minecraft:ghast 0.5 76 67.5 {Tags:["nw.welle","nw.a_ghast","nw.bosstrupp","nw.flieger"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],ExplosionPower:0b}
summon minecraft:ghast 0.5 76 67.5 {Tags:["nw.welle","nw.a_ghast","nw.bosstrupp","nw.flieger"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],ExplosionPower:0b}
spreadplayers 0 72 2 9 false @e[tag=nw.neu]
tag @e[tag=nw.neu] remove nw.neu
bossbar set nw:boss name [{"text":"The Howler","color":"dark_purple","bold":true}]
bossbar set nw:boss max 100
bossbar set nw:boss value 100
bossbar set nw:boss players @a
bossbar set nw:boss visible true
scoreboard players set #boss nw.boss 1
title @a subtitle [{"text":"The Howler is coming for you.","color":"dark_purple"}]
title @a title [{"text":"Night ","color":"dark_red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"dark_red"}]
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 0.7 0.5
function nachtwache:nacht/warden_wut
