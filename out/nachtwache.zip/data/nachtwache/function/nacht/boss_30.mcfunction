summon minecraft:warden 0.5 64 67.5 {Tags:["nw.welle","nw.boss","nw.bosstrupp","nw.boss_finale"],CustomName:{text:"The Collector",color:"dark_purple",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,Glowing:1b,attributes:[{id:"minecraft:follow_range",base:128d},{id:"minecraft:max_health",base:170d}],Health:170f,Brain:{memories:{"minecraft:dig_cooldown":{value:{},ttl:6000L}}}}
bossbar set nw:boss name [{"text":"The Collector","color":"dark_purple","bold":true}]
bossbar set nw:boss max 170
bossbar set nw:boss value 170
bossbar set nw:boss players @a
bossbar set nw:boss visible true
scoreboard players set #boss nw.boss 1
title @a subtitle [{"text":"The Collector is coming for you.","color":"dark_purple"}]
title @a title [{"text":"Night ","color":"dark_red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"dark_red"}]
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 0.7 0.5
function nachtwache:nacht/warden_wut
