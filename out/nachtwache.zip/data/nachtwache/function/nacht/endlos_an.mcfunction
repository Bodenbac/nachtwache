scoreboard players reset @s nw.endlos
scoreboard players enable @s nw.endlos
execute unless score #modus nw.status matches 3 run return 0
scoreboard players set #modus nw.status 2
weather thunder 1000000
tellraw @a [{"text":"Endless mode. The nights are back.","color":"dark_red"}]
