execute if score #n_witch nw.tmp matches ..0 run return 0
summon minecraft:witch 0.5 64 67.5 {Tags:["nw.welle","nw.a_witch","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
scoreboard players remove #n_witch nw.tmp 1
function nachtwache:nacht/spawn_witch
