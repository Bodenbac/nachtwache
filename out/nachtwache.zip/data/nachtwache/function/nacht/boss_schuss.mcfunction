execute unless entity @p[gamemode=!spectator,gamemode=!creative,distance=..26] run return 0
scoreboard players set #sicht nw.tmp 26
execute store result score #frei nw.tmp2 positioned ~ ~1.4 ~ facing entity @p[gamemode=!spectator,gamemode=!creative] eyes run function nachtwache:gegner/sicht
execute unless score #frei nw.tmp2 matches 1 run return 0
scoreboard players set #spur nw.tmp 52
execute positioned ~ ~1.4 ~ facing entity @p[gamemode=!spectator,gamemode=!creative] eyes run function nachtwache:bogi/spur
execute as @p[gamemode=!spectator,gamemode=!creative,distance=..26] run damage @s 6 minecraft:arrow
playsound minecraft:entity.arrow.shoot hostile @a[distance=..32] ~ ~ ~ 1 0.6
