summon minecraft:witch 0.5 64 67.5 {Tags:["nw.welle","nw.boss","nw.bosstrupp","nw.boss_hexe"],CustomName:{text:"The Witch",color:"dark_purple",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,Glowing:1b,attributes:[{id:"minecraft:follow_range",base:128d},{id:"minecraft:max_health",base:100d}],Health:100f}
summon minecraft:wither_skeleton 0.5 64 67.5 {Tags:["nw.welle","nw.a_wither_skeleton","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{mainhand:{id:"minecraft:stone_sword",count:1}},drop_chances:{mainhand:0.05f}}
summon minecraft:wither_skeleton 0.5 64 67.5 {Tags:["nw.welle","nw.a_wither_skeleton","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{mainhand:{id:"minecraft:stone_sword",count:1}},drop_chances:{mainhand:0.05f}}
summon minecraft:wither_skeleton 0.5 64 67.5 {Tags:["nw.welle","nw.a_wither_skeleton","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{mainhand:{id:"minecraft:stone_sword",count:1}},drop_chances:{mainhand:0.05f}}
summon minecraft:wither_skeleton 0.5 64 67.5 {Tags:["nw.welle","nw.a_wither_skeleton","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{mainhand:{id:"minecraft:stone_sword",count:1}},drop_chances:{mainhand:0.05f}}
summon minecraft:wither_skeleton 0.5 64 67.5 {Tags:["nw.welle","nw.a_wither_skeleton","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{mainhand:{id:"minecraft:stone_sword",count:1}},drop_chances:{mainhand:0.05f}}
summon minecraft:wither_skeleton 0.5 64 67.5 {Tags:["nw.welle","nw.a_wither_skeleton","nw.bosstrupp","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{mainhand:{id:"minecraft:stone_sword",count:1}},drop_chances:{mainhand:0.05f}}
spreadplayers 0 72 2 9 false @e[tag=nw.neu]
tag @e[tag=nw.neu] remove nw.neu
bossbar set nw:boss name [{"text":"The Witch","color":"dark_purple","bold":true}]
bossbar set nw:boss max 100
bossbar set nw:boss value 100
bossbar set nw:boss players @a
bossbar set nw:boss visible true
scoreboard players set #boss nw.boss 1
title @a subtitle [{"text":"The Witch is coming for you.","color":"dark_purple"}]
title @a title [{"text":"Night ","color":"dark_red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"dark_red"}]
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 0.7 0.5
function nachtwache:nacht/warden_wut
