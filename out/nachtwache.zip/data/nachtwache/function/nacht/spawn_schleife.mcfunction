execute if score #anz nw.tmp matches ..0 run return 0
function nachtwache:nacht/spawn_einer
scoreboard players remove #anz nw.tmp 1
function nachtwache:nacht/spawn_schleife
