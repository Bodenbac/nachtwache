scoreboard players set #bossart nw.boss 110
summon minecraft:blaze 0.5 76 67.5 {Tags:["nw.welle","nw.boss","nw.bosstrupp","nw.boss_feuer","nw.flieger"],CustomName:{text:"The Pyre",color:"dark_purple",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,Glowing:1b,attributes:[{id:"minecraft:follow_range",base:128d},{id:"minecraft:max_health",base:160d},{id:"minecraft:scale",base:1.8d}],Health:160f}
summon minecraft:blaze 0.5 76 67.5 {Tags:["nw.welle","nw.a_blaze","nw.bosstrupp","nw.flieger"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
summon minecraft:blaze 0.5 76 67.5 {Tags:["nw.welle","nw.a_blaze","nw.bosstrupp","nw.flieger"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
summon minecraft:blaze 0.5 76 67.5 {Tags:["nw.welle","nw.a_blaze","nw.bosstrupp","nw.flieger"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
summon minecraft:blaze 0.5 76 67.5 {Tags:["nw.welle","nw.a_blaze","nw.bosstrupp","nw.flieger"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
summon minecraft:blaze 0.5 76 67.5 {Tags:["nw.welle","nw.a_blaze","nw.bosstrupp","nw.flieger"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
spreadplayers 0 72 2 9 false @e[tag=nw.neu]
tag @e[tag=nw.neu] remove nw.neu
bossbar set nw:boss name [{"text":"The Pyre","color":"dark_purple","bold":true}]
bossbar set nw:boss max 160
bossbar set nw:boss value 160
bossbar set nw:boss players @a
bossbar set nw:boss visible true
scoreboard players set #boss nw.boss 1
title @a subtitle [{"text":"The Pyre is coming for you.","color":"dark_purple"}]
title @a title [{"text":"Night ","color":"dark_red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"dark_red"}]
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 0.7 0.5
function nachtwache:nacht/warden_wut
