scoreboard players set #zeit nw.zeit 23500
tellraw @a [{"text":"Nothing is left alive. Dawn breaks.","color":"green"}]
