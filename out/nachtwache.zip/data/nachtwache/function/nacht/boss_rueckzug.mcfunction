execute unless entity @p[gamemode=!spectator,gamemode=!creative,distance=..8] run return 0
execute facing entity @p[gamemode=!spectator,gamemode=!creative] feet rotated ~ 0 if block ^ ^ ^-1 minecraft:air if block ^ ^1 ^-1 minecraft:air unless block ^ ^-1 ^-1 minecraft:air run tp @s ^ ^ ^-0.11 ~ ~
