execute if score #n_blaze nw.tmp matches ..0 run return 0
summon minecraft:blaze 0.5 76 67.5 {Tags:["nw.welle","nw.a_blaze","nw.flieger"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
scoreboard players remove #n_blaze nw.tmp 1
function nachtwache:nacht/spawn_blaze
