execute if score #n_wither_skeleton nw.tmp matches ..0 run return 0
summon minecraft:wither_skeleton 0.5 64 67.5 {Tags:["nw.welle","nw.a_wither_skeleton","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],equipment:{mainhand:{id:"minecraft:stone_sword",count:1}},drop_chances:{mainhand:0.0f}}
scoreboard players remove #n_wither_skeleton nw.tmp 1
function nachtwache:nacht/spawn_wither_skeleton
