execute if score #bosszeit nw.boss matches ..0 run return 0
scoreboard players remove #bosszeit nw.boss 1
execute unless score #bosszeit nw.boss matches 0 run return 0
execute unless score #status nw.status matches 1 run return 0
execute if score #bossruf nw.boss matches 5 run function nachtwache:nacht/boss_5
execute if score #bossruf nw.boss matches 10 run function nachtwache:nacht/boss_10
execute if score #bossruf nw.boss matches 15 run function nachtwache:nacht/boss_15
execute if score #bossruf nw.boss matches 20 run function nachtwache:nacht/boss_20
execute if score #bossruf nw.boss matches 25 run function nachtwache:nacht/boss_25
execute if score #bossruf nw.boss matches 30 run function nachtwache:nacht/boss_30
execute if score #bossruf nw.boss matches -1 run function nachtwache:nacht/boss_zufall
