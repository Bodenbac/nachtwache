execute store result score #r nw.tmp2 run random value 1..5
execute if score #r nw.tmp2 matches 1 run function nachtwache:nacht/boss_5
execute if score #r nw.tmp2 matches 2 run function nachtwache:nacht/boss_10
execute if score #r nw.tmp2 matches 3 run function nachtwache:nacht/boss_15
execute if score #r nw.tmp2 matches 4 run function nachtwache:nacht/boss_20
execute if score #r nw.tmp2 matches 5 run function nachtwache:nacht/boss_25
