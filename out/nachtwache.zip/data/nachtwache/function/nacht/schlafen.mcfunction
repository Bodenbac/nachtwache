scoreboard players set #zeit nw.zeit 23500
tellraw @a [{"text":"You sleep. The night passes.","color":"gray","italic":true}]
