scoreboard players set #status nw.status 1
bossbar set nw:uhr visible false
scoreboard players set #nacht_haelt nw.status 0
scoreboard players add #nacht nw.nacht 1
function nachtwache:strasse/bauen
effect give @a minecraft:darkness 3 0 true
playsound minecraft:entity.wither.spawn hostile @a ~ ~ ~ 0.5 0.5
playsound minecraft:block.bell.use block @a ~ ~ ~ 1 0.5
title @a times 10 60 20
title @a title [{"text":"Night ","color":"dark_red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"dark_red"}]
title @a subtitle [{"text":"The road is growing.","color":"gray"}]
execute if score #nacht nw.nacht matches 30 unless score #modus nw.status matches 2 run function nachtwache:nacht/finale_start
function nachtwache:nacht/welle
scoreboard players set #bossruf nw.boss 0
scoreboard players set #bosszeit nw.boss 0
execute if score #nacht nw.nacht matches 5 unless score #modus nw.status matches 2 run scoreboard players set #bossruf nw.boss 5
execute if score #nacht nw.nacht matches 10 unless score #modus nw.status matches 2 run scoreboard players set #bossruf nw.boss 10
execute if score #nacht nw.nacht matches 15 unless score #modus nw.status matches 2 run scoreboard players set #bossruf nw.boss 15
execute if score #nacht nw.nacht matches 20 unless score #modus nw.status matches 2 run scoreboard players set #bossruf nw.boss 20
execute if score #nacht nw.nacht matches 25 unless score #modus nw.status matches 2 run scoreboard players set #bossruf nw.boss 25
execute if score #nacht nw.nacht matches 30 unless score #modus nw.status matches 2 run scoreboard players set #bossruf nw.boss 30
scoreboard players operation #m5 nw.tmp2 = #nacht nw.nacht
scoreboard players operation #m5 nw.tmp2 %= #5 nw.const
execute if score #modus nw.status matches 2 if score #m5 nw.tmp2 matches 0 run scoreboard players set #bossruf nw.boss -1
execute unless score #bossruf nw.boss matches 0 run scoreboard players set #bosszeit nw.boss 300
execute unless score #nacht nw.nacht matches 30 run function nachtwache:sammler/spruch/nacht
scoreboard players set #glocke_geklingelt nw.upgrade 0
