execute if score #n_magma nw.tmp matches ..0 run return 0
summon minecraft:magma_cube 0.5 64 67.5 {Tags:["nw.welle","nw.a_magma","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}],Size:1}
scoreboard players remove #n_magma nw.tmp 1
function nachtwache:nacht/spawn_magma
