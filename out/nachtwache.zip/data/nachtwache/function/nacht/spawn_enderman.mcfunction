execute if score #n_enderman nw.tmp matches ..0 run return 0
summon minecraft:enderman 0.5 64 67.5 {Tags:["nw.welle","nw.a_enderman","nw.neu"],PersistenceRequired:1b,attributes:[{id:"minecraft:follow_range",base:100d}]}
scoreboard players remove #n_enderman nw.tmp 1
function nachtwache:nacht/spawn_enderman
