scoreboard players set #modus nw.status 3
scoreboard players set #finale nw.status 0
scoreboard players set #status nw.status 0
kill @e[tag=nw.welle]
function nachtwache:strasse/entfernen
bossbar set nw:welle visible false
scoreboard players set #zeit nw.zeit 1000
time set 1000
weather clear 1000000
title @a times 20 100 40
title @a title [{"text":"DAWN BREAKS","color":"gold","bold":true}]
title @a subtitle [{"text":"Night 30 is over. The Collector is dead.","color":"gray"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
playsound minecraft:entity.ender_dragon.death master @a ~ ~ ~ 0.5 1.2
tellraw @a [{"text":"--- NIGHTWATCH: STATS ---","color":"gold","bold":true}]
tellraw @a [{"text":"Nights: ","color":"gray"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"white"},{"text":"   Deaths: ","color":"gray"},{"score":{"name":"#tode","objective":"nw.tode"},"color":"white"},{"text":"   Blocks mined at the Source: ","color":"gray"},{"score":{"name":"#abbau","objective":"nw.abbau"},"color":"white"}]
tellraw @a [{"text":"Enemies killed: ","color":"gray"},{"score":{"name":"#kills","objective":"nw.kills"},"color":"white"},{"text":"   Coins earned: ","color":"gray"},{"score":{"name":"#verdient","objective":"nw.verdient"},"color":"gold"}]
tellraw @a [{"text":"Keep playing without nights, or ","color":"gray"},{"text":"[start endless mode]","color":"yellow","click_event":{"action":"run_command","command":"trigger nw.endlos"}},{"text":" (waves keep growing, a boss every five nights).","color":"gray"}]
function nachtwache:sammler/erscheinen
function nachtwache:sammler/spruch/sieg
scoreboard players enable @a nw.endlos
