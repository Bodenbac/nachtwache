execute if score #status nw.status matches 1 run return run bossbar set nw:uhr visible false
execute if score #modus nw.status matches 3 run return run bossbar set nw:uhr visible false
scoreboard players set #rest nw.tmp2 13000
scoreboard players operation #rest nw.tmp2 -= #zeit nw.zeit
execute if score #rest nw.tmp2 matches ..0 run scoreboard players add #rest nw.tmp2 24000
execute store result bossbar nw:uhr value run scoreboard players get #rest nw.tmp2
scoreboard players operation #usek nw.tmp2 = #rest nw.tmp2
scoreboard players set #uhr_n nw.tmp2 32
scoreboard players operation #usek nw.tmp2 *= #uhr_n nw.tmp2
scoreboard players set #uhr_z nw.tmp2 900
scoreboard players operation #usek nw.tmp2 /= #uhr_z nw.tmp2
scoreboard players operation #umin nw.tmp2 = #usek nw.tmp2
scoreboard players set #sechzig nw.tmp2 60
scoreboard players operation #umin nw.tmp2 /= #sechzig nw.tmp2
scoreboard players operation #usek nw.tmp2 %= #sechzig nw.tmp2
execute if score #usek nw.tmp2 matches 0..9 run bossbar set nw:uhr name [{"text":"Day  ","color":"green"},{"text":"night in ","color":"gray"},{"score":{"name":"#umin","objective":"nw.tmp2"},"color":"white"},{"text":":0","color":"white"},{"score":{"name":"#usek","objective":"nw.tmp2"},"color":"white"}]
execute if score #usek nw.tmp2 matches 10.. run bossbar set nw:uhr name [{"text":"Day  ","color":"green"},{"text":"night in ","color":"gray"},{"score":{"name":"#umin","objective":"nw.tmp2"},"color":"white"},{"text":":","color":"white"},{"score":{"name":"#usek","objective":"nw.tmp2"},"color":"white"}]
execute if score #kontrakt nw.upgrade matches 1.. if score #usek nw.tmp2 matches 0..9 run bossbar set nw:uhr name [{"text":"Day  ","color":"green"},{"text":"night in ","color":"gray"},{"score":{"name":"#umin","objective":"nw.tmp2"},"color":"white"},{"text":":0","color":"white"},{"score":{"name":"#usek","objective":"nw.tmp2"},"color":"white"},{"text":"  ","color":"white"},{"text":"★","color":"white"}]
execute if score #kontrakt nw.upgrade matches 1.. if score #usek nw.tmp2 matches 10.. run bossbar set nw:uhr name [{"text":"Day  ","color":"green"},{"text":"night in ","color":"gray"},{"score":{"name":"#umin","objective":"nw.tmp2"},"color":"white"},{"text":":","color":"white"},{"score":{"name":"#usek","objective":"nw.tmp2"},"color":"white"},{"text":"  ","color":"white"},{"text":"★","color":"white"}]
bossbar set nw:uhr color green
execute if score #rest nw.tmp2 matches ..4000 run bossbar set nw:uhr color yellow
execute if score #rest nw.tmp2 matches ..1000 run bossbar set nw:uhr color red
execute if score #rest nw.tmp2 matches 1000..1020 run playsound minecraft:block.bell.use block @a ~ ~ ~ 1 0.6
bossbar set nw:uhr players @a
bossbar set nw:uhr visible true
