execute unless entity @a run return 0
scoreboard players set #tagphase nw.tmp 1
execute if score #zeit nw.zeit matches 13000..23499 run scoreboard players set #tagphase nw.tmp 0
scoreboard players operation #m nw.tmp = #tick nw.tick
execute if score #tagphase nw.tmp matches 1 run scoreboard players operation #m nw.tmp %= #4 nw.const
execute if score #tagphase nw.tmp matches 0 run scoreboard players operation #m nw.tmp %= #7 nw.const
execute unless score #m nw.tmp matches 0 run return 0
execute if score #status nw.status matches 1 if score #gegner nw.gegner matches 0 if score #zeit nw.zeit matches 13300.. run function nachtwache:nacht/alles_tot
execute if score #status nw.status matches 1 if score #zeit nw.zeit matches 23000.. if score #gegner nw.gegner matches 1.. run return run function nachtwache:nacht/haelt
execute if score #tagphase nw.tmp matches 1 run scoreboard players add #zeit nw.zeit 5
execute if score #tagphase nw.tmp matches 0 run scoreboard players add #zeit nw.zeit 5
execute if score #modus nw.status matches 3 if score #zeit nw.zeit matches 12000.. run scoreboard players set #zeit nw.zeit 0
execute if score #zeit nw.zeit matches 24000.. run scoreboard players remove #zeit nw.zeit 24000
execute store result storage nachtwache:tmp t int 1 run scoreboard players get #zeit nw.zeit
function nachtwache:uhr/setzen with storage nachtwache:tmp
execute if score #status nw.status matches 0 unless score #modus nw.status matches 3 if score #zeit nw.zeit matches 13000..23499 run function nachtwache:nacht/start
execute if score #status nw.status matches 1 unless score #zeit nw.zeit matches 13000..23499 run function nachtwache:nacht/ende
