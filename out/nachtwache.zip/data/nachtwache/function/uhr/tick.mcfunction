execute if score #ende nw.status matches 1 run return 0
execute unless entity @a run return 0
scoreboard players set #tagphase nw.tmp 1
execute if score #zeit nw.zeit matches 13000..23499 run scoreboard players set #tagphase nw.tmp 0
execute if score #tagphase nw.tmp matches 1 run scoreboard players add #uhr_akku nw.tmp2 45
execute if score #tagphase nw.tmp matches 1 run scoreboard players set #uhr_nenner nw.tmp2 32
execute if score #tagphase nw.tmp matches 0 run scoreboard players add #uhr_akku nw.tmp2 5
execute if score #tagphase nw.tmp matches 0 run scoreboard players set #uhr_nenner nw.tmp2 7
execute unless score #uhr_akku nw.tmp2 >= #uhr_nenner nw.tmp2 run return 0
scoreboard players operation #schritt nw.tmp2 = #uhr_akku nw.tmp2
scoreboard players operation #schritt nw.tmp2 /= #uhr_nenner nw.tmp2
scoreboard players operation #uhr_akku nw.tmp2 %= #uhr_nenner nw.tmp2
execute if score #status nw.status matches 1 if score #gegner nw.gegner matches 0 if score #zeit nw.zeit matches 13300.. run function nachtwache:nacht/alles_tot
execute if score #status nw.status matches 1 if score #zeit nw.zeit matches 23000.. if score #gegner nw.gegner matches 1.. run return run function nachtwache:nacht/haelt
scoreboard players operation #zeit nw.zeit += #schritt nw.tmp2
execute if score #modus nw.status matches 3 if score #zeit nw.zeit matches 12000.. run scoreboard players set #zeit nw.zeit 0
execute if score #zeit nw.zeit matches 24000.. run scoreboard players remove #zeit nw.zeit 24000
execute store result storage nachtwache:tmp t int 1 run scoreboard players get #zeit nw.zeit
function nachtwache:uhr/setzen with storage nachtwache:tmp
execute if score #status nw.status matches 0 unless score #modus nw.status matches 3 if score #zeit nw.zeit matches 13000..23499 run function nachtwache:nacht/start
execute if score #status nw.status matches 1 unless score #zeit nw.zeit matches 13000..23499 run function nachtwache:nacht/ende
