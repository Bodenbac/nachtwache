advancement revoke @s only nachtwache:skull_benutzt
execute store result score #opfer nw.tmp if entity @e[tag=nw.welle,tag=!nw.boss]
execute if score #opfer nw.tmp matches 0 run return run tellraw @s [{"text":"The skull finds nothing to reap.","color":"gray","italic":true}]
execute as @e[tag=nw.welle,tag=!nw.boss,sort=random,limit=3] at @s run function nachtwache:skull/opfer
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.5 1.6
tellraw @a [{"text":"The skull opens its jaws. Three of them fall.","color":"dark_red"}]
