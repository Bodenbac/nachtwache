particle minecraft:soul ~ ~1 ~ 0.3 0.6 0.3 0.05 40
particle minecraft:sculk_soul ~ ~1 ~ 0.3 0.6 0.3 0.02 15
playsound minecraft:entity.wither_skeleton.death hostile @a ~ ~ ~ 1 0.7
kill @s
