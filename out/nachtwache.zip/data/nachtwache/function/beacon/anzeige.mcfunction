data modify entity @e[tag=nw.herz_text,limit=1] text set value [{"text":" ","color":"red"},{"score":{"name":"#leben","objective":"nw.leben"},"color":"red","bold":true}]
