execute as @e[tag=nw.herz_text] run data modify entity @s text set value [{"text":" ","color":"red"},{"score":{"name":"#leben","objective":"nw.leben"},"color":"white","bold":true}]
