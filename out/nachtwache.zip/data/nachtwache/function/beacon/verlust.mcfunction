scoreboard players remove #leben nw.leben 1
particle minecraft:dust{color:[1.0,0.1,0.1],scale:2.0} 0.5 65.5 -16.5 0.8 1.2 0.8 0 60
playsound minecraft:entity.wither.hurt hostile @a 0 64 -17 1.4 0.6
tellraw @a [{"text":"Something reached the beacon. ","color":"dark_red"},{"text":"-1 ","color":"red"},{"text":"","color":"red"}]
title @a actionbar [{"text":"Lives: ","color":"red"},{"score":{"name":"#leben","objective":"nw.leben"},"color":"white"}]
function nachtwache:beacon/anzeige
execute if score #leben nw.leben matches ..0 run function nachtwache:beacon/ende
