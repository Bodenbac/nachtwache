scoreboard players set #leben nw.leben 0
scoreboard players set #ende nw.status 1
kill @e[tag=nw.welle]
function nachtwache:gegner/vergessen
scoreboard players set #gegner nw.gegner 0
scoreboard players set #boss nw.boss 0
bossbar set nw:welle visible false
bossbar set nw:boss visible false
bossbar set nw:uhr visible false
function nachtwache:strasse/entfernen
scoreboard players set #status nw.status 0
title @a times 10 120 20
title @a title [{"text":"GAME OVER","color":"dark_red","bold":true}]
title @a subtitle [{"text":"The beacon is dark.","color":"gray"}]
playsound minecraft:entity.wither.death master @a ~ ~ ~ 1 0.6
tellraw @a [{"text":"The beacon went out on night ","color":"dark_red"},{"score":{"name":"#nacht","objective":"nw.nacht"},"color":"white"},{"text":".","color":"dark_red"}]
tellraw @a [{"text":"Enemies killed: ","color":"gray"},{"score":{"name":"#kills","objective":"nw.kills"},"color":"white"},{"text":"   Coins earned: ","color":"gray"},{"score":{"name":"#verdient","objective":"nw.verdient"},"color":"gold"},{"text":"   Blocks mined: ","color":"gray"},{"score":{"name":"#abbau","objective":"nw.abbau"},"color":"white"}]
tellraw @a [{"text":"An admin can start over with ","color":"gray"},{"text":"/trigger reset","color":"yellow"},{"text":".","color":"gray"}]
