execute unless block 0 64 -17 minecraft:beacon run setblock 0 64 -17 minecraft:beacon
execute unless block 0 65 -17 minecraft:red_stained_glass run setblock 0 65 -17 minecraft:red_stained_glass
fill -1 63 -18 1 63 -16 minecraft:iron_block replace #nachtwache:beacon_sockel
kill @e[type=item,x=-2,y=62,z=-19,dx=4,dy=4,dz=4,nbt={Item:{id:"minecraft:iron_block"}}]
kill @e[type=item,x=-2,y=62,z=-19,dx=4,dy=4,dz=4,nbt={Item:{id:"minecraft:beacon"}}]
execute unless entity @e[tag=nw.herz] run summon minecraft:villager 0.5 65.1 -16.5 {Tags:["nw.herz"],NoAI:1b,Silent:1b,Invulnerable:1b,PersistenceRequired:1b,NoGravity:1b,Offers:{Recipes:[]},VillagerData:{profession:"minecraft:nitwit",level:1,type:"minecraft:swamp"},attributes:[{id:"minecraft:scale",base:0.2d},{id:"minecraft:max_health",base:1024d}],Health:1024f}
execute unless entity @e[tag=nw.herz_text] run summon minecraft:text_display 0.5 66.1 -16.5 {Tags:["nw.herz_text"],billboard:"center",background:0,see_through:false,text:[{"text":" ","color":"red"},{"score":{"name":"#leben","objective":"nw.leben"},"color":"red","bold":true}]}
