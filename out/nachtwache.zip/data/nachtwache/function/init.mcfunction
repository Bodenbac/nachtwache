gamerule advance_time false
gamerule advance_weather false
gamerule spawn_mobs false
gamerule spawn_monsters false
gamerule fire_spread_radius_around_player 0
gamerule spawn_phantoms false
gamerule spawn_patrols false
gamerule spawn_wandering_traders false
gamerule keep_inventory false
gamerule mob_griefing true
gamerule respawn_radius 0
gamerule players_sleeping_percentage 100
gamerule immediate_respawn false
gamerule show_advancement_messages false
gamerule spawner_blocks_work true
gamerule spawn_wardens false
difficulty hard
weather thunder 1000000
scoreboard players set #zeit nw.zeit 1000
time set 1000
scoreboard players set #konto nw.konto 0
scoreboard players set #abbau nw.abbau 0
scoreboard players set #phase nw.phase 1
scoreboard players set #nacht nw.nacht 0
scoreboard players set #gegner nw.gegner 0
scoreboard players set #status nw.status 0
scoreboard players set #modus nw.status 0
scoreboard players set #finale nw.status 0
scoreboard players set #kills nw.kills 0
scoreboard players set #verdient nw.verdient 0
scoreboard players set #tode nw.tode 0
scoreboard players set #leben nw.leben 10
scoreboard players set #ende nw.status 0
scoreboard players set #glocke nw.upgrade 0
scoreboard players set #kontrakt nw.upgrade 0
kill @e[type=marker,tag=nw.laterne]
kill @e[tag=nw.zwerg]
kill @e[tag=nw.zwerg_k]
kill @e[tag=nw.zwerg_a]
scoreboard players set #boss nw.boss 0
forceload add -20 -20 20 100
function nachtwache:welt/startinsel
function nachtwache:welt/stand
function nachtwache:welt/gegnerinsel
function nachtwache:quell/setzen
function nachtwache:sammler/erscheinen
spawnpoint @a 0 64 -10
setworldspawn 0 64 -10
scoreboard players set #init nw.status 1
scoreboard players set #version nw.status 80
function nachtwache:anzeige/aktualisieren
tellraw @a [{"text":"[Nightwatch] ","color":"dark_red"},{"text":"The world is built. The Source stands in the middle, the Collector waits at his stall.","color":"gray"}]
