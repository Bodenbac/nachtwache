function nachtwache:sammler/ench/typ
execute if score #et nw.tmp2 matches 1 unless items block -6 64 -10 container.0 * run function nachtwache:sammler/ench/kauf_sharpness
execute if score #et nw.tmp2 matches 1 unless items block -6 64 -10 container.1 * run function nachtwache:sammler/ench/kauf_fire_aspect
execute if score #et nw.tmp2 matches 1 unless items block -6 64 -10 container.2 * run function nachtwache:sammler/ench/kauf_looting
execute if score #et nw.tmp2 matches 1 unless items block -6 64 -10 container.3 * run function nachtwache:sammler/ench/kauf_sweeping_edge
execute if score #et nw.tmp2 matches 1 unless items block -6 64 -10 container.4 * run function nachtwache:sammler/ench/kauf_knockback
execute if score #et nw.tmp2 matches 1 unless items block -6 64 -10 container.5 * run function nachtwache:sammler/ench/kauf_unbreaking
execute if score #et nw.tmp2 matches 1 unless items block -6 64 -10 container.6 * run function nachtwache:sammler/ench/kauf_mending
execute if score #et nw.tmp2 matches 2 unless items block -6 64 -10 container.0 * run function nachtwache:sammler/ench/kauf_efficiency
execute if score #et nw.tmp2 matches 2 unless items block -6 64 -10 container.1 * run function nachtwache:sammler/ench/kauf_fortune
execute if score #et nw.tmp2 matches 2 unless items block -6 64 -10 container.2 * run function nachtwache:sammler/ench/kauf_silk_touch
execute if score #et nw.tmp2 matches 2 unless items block -6 64 -10 container.3 * run function nachtwache:sammler/ench/kauf_unbreaking
execute if score #et nw.tmp2 matches 2 unless items block -6 64 -10 container.4 * run function nachtwache:sammler/ench/kauf_mending
execute if score #et nw.tmp2 matches 3 unless items block -6 64 -10 container.0 * run function nachtwache:sammler/ench/kauf_sharpness
execute if score #et nw.tmp2 matches 3 unless items block -6 64 -10 container.1 * run function nachtwache:sammler/ench/kauf_efficiency
execute if score #et nw.tmp2 matches 3 unless items block -6 64 -10 container.2 * run function nachtwache:sammler/ench/kauf_unbreaking
execute if score #et nw.tmp2 matches 3 unless items block -6 64 -10 container.3 * run function nachtwache:sammler/ench/kauf_mending
execute if score #et nw.tmp2 matches 4 unless items block -6 64 -10 container.0 * run function nachtwache:sammler/ench/kauf_efficiency
execute if score #et nw.tmp2 matches 4 unless items block -6 64 -10 container.1 * run function nachtwache:sammler/ench/kauf_silk_touch
execute if score #et nw.tmp2 matches 4 unless items block -6 64 -10 container.2 * run function nachtwache:sammler/ench/kauf_unbreaking
execute if score #et nw.tmp2 matches 4 unless items block -6 64 -10 container.3 * run function nachtwache:sammler/ench/kauf_mending
execute if score #et nw.tmp2 matches 5 unless items block -6 64 -10 container.0 * run function nachtwache:sammler/ench/kauf_power
execute if score #et nw.tmp2 matches 5 unless items block -6 64 -10 container.1 * run function nachtwache:sammler/ench/kauf_punch
execute if score #et nw.tmp2 matches 5 unless items block -6 64 -10 container.2 * run function nachtwache:sammler/ench/kauf_flame
execute if score #et nw.tmp2 matches 5 unless items block -6 64 -10 container.3 * run function nachtwache:sammler/ench/kauf_infinity
execute if score #et nw.tmp2 matches 5 unless items block -6 64 -10 container.4 * run function nachtwache:sammler/ench/kauf_unbreaking
execute if score #et nw.tmp2 matches 5 unless items block -6 64 -10 container.5 * run function nachtwache:sammler/ench/kauf_mending
execute if score #et nw.tmp2 matches 6 unless items block -6 64 -10 container.0 * run function nachtwache:sammler/ench/kauf_protection
execute if score #et nw.tmp2 matches 6 unless items block -6 64 -10 container.1 * run function nachtwache:sammler/ench/kauf_thorns
execute if score #et nw.tmp2 matches 6 unless items block -6 64 -10 container.2 * run function nachtwache:sammler/ench/kauf_unbreaking
execute if score #et nw.tmp2 matches 6 unless items block -6 64 -10 container.3 * run function nachtwache:sammler/ench/kauf_mending
execute if score #et nw.tmp2 matches 7 unless items block -6 64 -10 container.0 * run function nachtwache:sammler/ench/kauf_protection
execute if score #et nw.tmp2 matches 7 unless items block -6 64 -10 container.1 * run function nachtwache:sammler/ench/kauf_thorns
execute if score #et nw.tmp2 matches 7 unless items block -6 64 -10 container.2 * run function nachtwache:sammler/ench/kauf_unbreaking
execute if score #et nw.tmp2 matches 7 unless items block -6 64 -10 container.3 * run function nachtwache:sammler/ench/kauf_mending
execute if score #et nw.tmp2 matches 8 unless items block -6 64 -10 container.0 * run function nachtwache:sammler/ench/kauf_protection
execute if score #et nw.tmp2 matches 8 unless items block -6 64 -10 container.1 * run function nachtwache:sammler/ench/kauf_thorns
execute if score #et nw.tmp2 matches 8 unless items block -6 64 -10 container.2 * run function nachtwache:sammler/ench/kauf_unbreaking
execute if score #et nw.tmp2 matches 8 unless items block -6 64 -10 container.3 * run function nachtwache:sammler/ench/kauf_mending
execute if score #et nw.tmp2 matches 9 unless items block -6 64 -10 container.0 * run function nachtwache:sammler/ench/kauf_protection
execute if score #et nw.tmp2 matches 9 unless items block -6 64 -10 container.1 * run function nachtwache:sammler/ench/kauf_thorns
execute if score #et nw.tmp2 matches 9 unless items block -6 64 -10 container.2 * run function nachtwache:sammler/ench/kauf_unbreaking
execute if score #et nw.tmp2 matches 9 unless items block -6 64 -10 container.3 * run function nachtwache:sammler/ench/kauf_feather_falling
execute if score #et nw.tmp2 matches 9 unless items block -6 64 -10 container.4 * run function nachtwache:sammler/ench/kauf_mending
function nachtwache:sammler/ench/typ
function nachtwache:sammler/ench/anzeige
clear @a[x=-7,y=64,z=-10,distance=..8] *[custom_data~{nw_ench_slot:1b}]
