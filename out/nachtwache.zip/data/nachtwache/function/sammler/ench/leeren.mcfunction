execute unless items block -6 64 -10 container.22 * run item replace block -6 64 -10 container.22 with minecraft:lime_stained_glass_pane[item_model="nachtwache:ench_slot",custom_data={nw_ench_slot:1b},custom_name={text:"Put gear here",color:"green",italic:false},lore=[{text:"Sword, pickaxe, axe, shovel, bow or armor.",color:"gray",italic:false},{text:"It stays here until you take it out.",color:"gray",italic:false}]]
item replace block -6 64 -10 container.0 with minecraft:air
item replace block -6 64 -10 container.1 with minecraft:air
item replace block -6 64 -10 container.2 with minecraft:air
item replace block -6 64 -10 container.3 with minecraft:air
item replace block -6 64 -10 container.4 with minecraft:air
item replace block -6 64 -10 container.5 with minecraft:air
item replace block -6 64 -10 container.6 with minecraft:air
item replace block -6 64 -10 container.7 with minecraft:air
item replace block -6 64 -10 container.8 with minecraft:air
