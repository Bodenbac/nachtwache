scoreboard players set #lv nw.tmp2 0
execute if data block -6 64 -10 Items[{Slot:22b}].components."minecraft:enchantments"."minecraft:knockback" store result score #lv nw.tmp2 run data get block -6 64 -10 Items[{Slot:22b}].components."minecraft:enchantments"."minecraft:knockback"
execute if data block -6 64 -10 Items[{Slot:22b}].components."minecraft:enchantments".levels."minecraft:knockback" store result score #lv nw.tmp2 run data get block -6 64 -10 Items[{Slot:22b}].components."minecraft:enchantments".levels."minecraft:knockback"
execute if score #lv nw.tmp2 matches 2.. run return run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Knockback is already at its maximum.","color":"gray"}]
execute if score #lv nw.tmp2 matches 0 unless score #phase nw.phase matches 1.. run return run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"The Source must reach tier 1 first.","color":"gray"}]
execute if score #lv nw.tmp2 matches 1 unless score #phase nw.phase matches 2.. run return run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"The Source must reach tier 2 first.","color":"gray"}]
scoreboard players operation #n nw.tmp2 = #lv nw.tmp2
scoreboard players add #n nw.tmp2 1
scoreboard players set #preis nw.tmp 125
scoreboard players operation #preis nw.tmp *= #n nw.tmp2
execute if score #konto nw.konto < #preis nw.tmp run return run function nachtwache:sammler/ench/zu_arm
scoreboard players operation #konto nw.konto -= #preis nw.tmp
execute if score #lv nw.tmp2 matches 0 run item modify block -6 64 -10 container.22 nachtwache:ench_knockback_1
execute if score #lv nw.tmp2 matches 1 run item modify block -6 64 -10 container.22 nachtwache:ench_knockback_2
playsound minecraft:block.enchantment_table.use master @a[distance=..12] ~ ~ ~ 1 1.2
playsound minecraft:block.anvil.use block @a[distance=..12] ~ ~ ~ 0.5 1.6
tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Knockback ","color":"gold"},{"score":{"name":"#n","objective":"nw.tmp2"},"color":"gold"},{"text":". That will hold.","color":"gray"}]
