scoreboard players set #et nw.tmp2 0
execute unless items block -6 64 -10 container.22 * run scoreboard players set #et nw.tmp2 -1
execute if items block -6 64 -10 container.22 *[custom_data~{nw_ench_slot:1b}] run scoreboard players set #et nw.tmp2 -1
execute if items block -6 64 -10 container.22 #nachtwache:ench_sword run scoreboard players set #et nw.tmp2 1
execute if items block -6 64 -10 container.22 #nachtwache:ench_pickaxe run scoreboard players set #et nw.tmp2 2
execute if items block -6 64 -10 container.22 #nachtwache:ench_axe run scoreboard players set #et nw.tmp2 3
execute if items block -6 64 -10 container.22 #nachtwache:ench_shovel run scoreboard players set #et nw.tmp2 4
execute if items block -6 64 -10 container.22 #nachtwache:ench_bow run scoreboard players set #et nw.tmp2 5
execute if items block -6 64 -10 container.22 #nachtwache:ench_helmet run scoreboard players set #et nw.tmp2 6
execute if items block -6 64 -10 container.22 #nachtwache:ench_chest run scoreboard players set #et nw.tmp2 7
execute if items block -6 64 -10 container.22 #nachtwache:ench_legs run scoreboard players set #et nw.tmp2 8
execute if items block -6 64 -10 container.22 #nachtwache:ench_boots run scoreboard players set #et nw.tmp2 9
