tellraw @a[x=-7,y=64,z=-10,distance=..8] [{"text":"[The Collector] ","color":"dark_red"},{"text":"I only work on swords, tools, bows and armor.","color":"gray"}]
playsound minecraft:entity.villager.no neutral @a[x=-7,y=64,z=-10,distance=..8] ~ ~ ~ 1 1
function nachtwache:sammler/ench/zurueck
