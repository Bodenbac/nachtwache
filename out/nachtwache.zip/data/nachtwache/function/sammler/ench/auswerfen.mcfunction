$summon minecraft:item ~ ~0.5 ~ {Item:$(it)}
