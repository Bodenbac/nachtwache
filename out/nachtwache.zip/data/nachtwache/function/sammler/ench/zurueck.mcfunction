execute positioned -7 64 -10 run function nachtwache:sammler/ench/zurueck_tun
