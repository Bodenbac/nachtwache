execute as @a[x=-7,y=64,z=-10,distance=..8] store result score @s nw.tmp run clear @s *[custom_data~{nw_ench:12}] 0
execute as @a[x=-7,y=64,z=-10,distance=..8,scores={nw.tmp=1..}] run function nachtwache:sammler/ench/abwickeln_knockback
clear @a[x=-7,y=64,z=-10,distance=..8] *[custom_data~{nw_ench:12}]
