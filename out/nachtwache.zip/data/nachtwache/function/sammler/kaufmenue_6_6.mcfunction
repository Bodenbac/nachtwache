item replace block -1 64 -5 container.0 with minecraft:tuff[custom_data={nw_menu:9001},custom_name={text:"Starter",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.1 with minecraft:green_concrete[custom_data={nw_menu:9002},custom_name={text:"Tier 2",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.2 with minecraft:blue_concrete[custom_data={nw_menu:9003},custom_name={text:"Tier 3",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.3 with minecraft:budding_amethyst[custom_data={nw_menu:9004},custom_name={text:"Tier 4",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.4 with minecraft:yellow_concrete[custom_data={nw_menu:9005},custom_name={text:"Tier 5",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.5 with minecraft:orange_concrete[enchantment_glint_override=true,custom_data={nw_menu:9006},custom_name={text:"Tier 6",color:"yellow",italic:false},lore=[{text:"Open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.6 with minecraft:air
item replace block -1 64 -5 container.7 with minecraft:air
item replace block -1 64 -5 container.8 with minecraft:enchanted_book[custom_data={nw_menu:9008},custom_name={text:"Books",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.9 with minecraft:ghast_tear[custom_data={nw_menu:110},custom_name={text:"Ghast Tear",color:"white",italic:false},lore=[[{text:"Price: 300 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 19200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.10 with minecraft:phantom_membrane[custom_data={nw_menu:111},custom_name={text:"Phantom Membrane",color:"white",italic:false},lore=[[{text:"Price: 150 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 9600 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.11 with minecraft:shulker_shell[custom_data={nw_menu:112},custom_name={text:"Shulker Shell",color:"white",italic:false},lore=[[{text:"Price: 800 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 51200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.12 with minecraft:dragon_breath[custom_data={nw_menu:113},custom_name={text:"Dragon's Breath",color:"white",italic:false},lore=[[{text:"Price: 400 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 25600 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.13 with minecraft:wither_skeleton_skull[custom_data={nw_menu:114},custom_name={text:"Wither Skeleton Skull",color:"white",italic:false},lore=[[{text:"Price: 1500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 96000 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.14 with minecraft:sculk_sensor[custom_data={nw_menu:115},custom_name={text:"Sculk Sensor",color:"white",italic:false},lore=[[{text:"Price: 300 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 19200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.15 with minecraft:heart_of_the_sea[custom_data={nw_menu:116},custom_name={text:"Heart of the Sea",color:"white",italic:false},lore=[[{text:"Price: 2500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.16 with minecraft:enchanted_golden_apple[custom_data={nw_menu:117},custom_name={text:"Enchanted Golden Apple",color:"white",italic:false},lore=[[{text:"Price: 3000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 192000 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.17 with minecraft:air
item replace block -1 64 -5 container.18 with minecraft:air
item replace block -1 64 -5 container.19 with minecraft:air
item replace block -1 64 -5 container.20 with minecraft:air
item replace block -1 64 -5 container.21 with minecraft:air
item replace block -1 64 -5 container.22 with minecraft:air
item replace block -1 64 -5 container.23 with minecraft:air
item replace block -1 64 -5 container.24 with minecraft:air
item replace block -1 64 -5 container.25 with minecraft:air
item replace block -1 64 -5 container.26 with minecraft:air
item replace block 0 64 -5 container.0 with minecraft:air
item replace block 0 64 -5 container.1 with minecraft:air
item replace block 0 64 -5 container.2 with minecraft:air
item replace block 0 64 -5 container.3 with minecraft:air
item replace block 0 64 -5 container.4 with minecraft:air
item replace block 0 64 -5 container.5 with minecraft:air
item replace block 0 64 -5 container.6 with minecraft:air
item replace block 0 64 -5 container.7 with minecraft:air
item replace block 0 64 -5 container.8 with minecraft:air
item replace block 0 64 -5 container.9 with minecraft:air
item replace block 0 64 -5 container.10 with minecraft:air
item replace block 0 64 -5 container.11 with minecraft:air
item replace block 0 64 -5 container.12 with minecraft:air
item replace block 0 64 -5 container.13 with minecraft:air
item replace block 0 64 -5 container.14 with minecraft:air
item replace block 0 64 -5 container.15 with minecraft:air
item replace block 0 64 -5 container.16 with minecraft:air
item replace block 0 64 -5 container.17 with minecraft:air
item replace block 0 64 -5 container.18 with minecraft:air
item replace block 0 64 -5 container.19 with minecraft:air
item replace block 0 64 -5 container.20 with minecraft:air
item replace block 0 64 -5 container.21 with minecraft:air
item replace block 0 64 -5 container.22 with minecraft:air
item replace block 0 64 -5 container.23 with minecraft:air
item replace block 0 64 -5 container.24 with minecraft:air
item replace block 0 64 -5 container.25 with minecraft:air
item replace block 0 64 -5 container.26 with minecraft:air
