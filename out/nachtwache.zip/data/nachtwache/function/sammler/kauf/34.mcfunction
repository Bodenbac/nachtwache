execute as @a[x=-1,y=64,z=-5,distance=..8] store result score @s nw.tmp run clear @s *[custom_data~{nw_menu:34}] 0
execute as @a[x=-1,y=64,z=-5,distance=..8,scores={nw.tmp=1..}] run function nachtwache:sammler/kauf_abwickeln/34
function nachtwache:sammler/kaufmenue
