execute as @a[x=-7,y=64,z=-10,distance=..8] store result score @s nw.tmp run clear @s *[custom_data~{nw_menu:75}] 0
execute as @a[x=-7,y=64,z=-10,distance=..8,scores={nw.tmp=1..}] run function nachtwache:sammler/kauf_abwickeln/75
function nachtwache:sammler/kaufmenue
