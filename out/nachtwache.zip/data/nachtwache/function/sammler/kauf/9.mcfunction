execute as @a[x=-1,y=64,z=-5,distance=..8] store result score @s nw.tmp run clear @s *[custom_data~{nw_menu:9}] 0
execute as @a[x=-1,y=64,z=-5,distance=..8,scores={nw.tmp=1..}] run function nachtwache:sammler/kauf_abwickeln/9
function nachtwache:sammler/kaufmenue
