$give @s $(item) $(n)
