execute unless items block 3 64 -6 container.* * run return 0
execute if items block 3 64 -6 container.0 * run function nachtwache:sammler/rampe_slot {slot:0}
execute if items block 3 64 -6 container.1 * run function nachtwache:sammler/rampe_slot {slot:1}
execute if items block 3 64 -6 container.2 * run function nachtwache:sammler/rampe_slot {slot:2}
execute if items block 3 64 -6 container.3 * run function nachtwache:sammler/rampe_slot {slot:3}
execute if items block 3 64 -6 container.4 * run function nachtwache:sammler/rampe_slot {slot:4}
