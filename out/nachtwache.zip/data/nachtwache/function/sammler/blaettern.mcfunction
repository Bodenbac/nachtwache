clear @a[x=-1,y=64,z=-5,distance=..8] *[custom_data~{nw_menu:9001}]
scoreboard players add #seite nw.status 1
function nachtwache:sammler/kaufmenue
