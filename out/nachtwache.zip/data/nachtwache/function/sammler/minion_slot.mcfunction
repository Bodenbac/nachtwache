$execute store result score #n nw.tmp run data get block -5 64 -10 Items[{Slot:$(slot)b}].count
$scoreboard players set #w nw.tmp2 $(wert)
scoreboard players operation #gain nw.tmp = #n nw.tmp
scoreboard players operation #gain nw.tmp *= #w nw.tmp2
scoreboard players operation #konto nw.konto += #gain nw.tmp
scoreboard players operation #verdient nw.verdient += #gain nw.tmp
$item replace block -5 64 -10 container.$(slot) with minecraft:air
playsound minecraft:entity.villager.trade neutral @a[distance=..12] -5 64 -10 0.8 1
title @a[distance=..12] actionbar [{"text":"Sold: +","color":"gold"},{"score":{"name":"#gain","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"gold"},{"text":"●","color":"white"}]
