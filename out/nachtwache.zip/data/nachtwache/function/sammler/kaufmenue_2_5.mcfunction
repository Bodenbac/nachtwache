item replace block -7 64 -10 container.0 with minecraft:stone[custom_data={nw_menu:9001},custom_name={text:"Building Blocks",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.1 with minecraft:iron_ingot[custom_data={nw_menu:9002},custom_name={text:"Minerals & Drops",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.2 with minecraft:rotten_flesh[custom_data={nw_menu:9003},custom_name={text:"Mob Drops",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.3 with minecraft:bread[custom_data={nw_menu:9004},custom_name={text:"Food",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.4 with minecraft:iron_pickaxe[enchantment_glint_override=true,custom_data={nw_menu:9005},custom_name={text:"Tools",color:"yellow",italic:false},lore=[{text:"Open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.5 with minecraft:redstone[custom_data={nw_menu:9006},custom_name={text:"Utility",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.6 with minecraft:enchanted_book[custom_data={nw_menu:9008},custom_name={text:"Enchanted Books",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.7 with minecraft:nether_star[custom_data={nw_menu:9009},custom_name={text:"Special",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.8 with minecraft:air
item replace block -7 64 -10 container.9 with minecraft:wooden_sword[custom_data={nw_menu:200},custom_name={text:"Wooden Sword",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.10 with minecraft:wooden_pickaxe[custom_data={nw_menu:201},custom_name={text:"Wooden Pickaxe",color:"white",italic:false},lore=[[{text:"Price: 25 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.11 with minecraft:wooden_axe[custom_data={nw_menu:202},custom_name={text:"Wooden Axe",color:"white",italic:false},lore=[[{text:"Price: 25 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.12 with minecraft:wooden_shovel[custom_data={nw_menu:203},custom_name={text:"Wooden Shovel",color:"white",italic:false},lore=[[{text:"Price: 15 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.13 with minecraft:air
item replace block -7 64 -10 container.14 with minecraft:leather_helmet[custom_data={nw_menu:204},custom_name={text:"Leather Helmet",color:"white",italic:false},lore=[[{text:"Price: 66 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.15 with minecraft:leather_chestplate[custom_data={nw_menu:205},custom_name={text:"Leather Chestplate",color:"white",italic:false},lore=[[{text:"Price: 106 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.16 with minecraft:leather_leggings[custom_data={nw_menu:206},custom_name={text:"Leather Leggings",color:"white",italic:false},lore=[[{text:"Price: 92 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.17 with minecraft:leather_boots[custom_data={nw_menu:207},custom_name={text:"Leather Boots",color:"white",italic:false},lore=[[{text:"Price: 52 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.18 with minecraft:stone_sword[custom_data={nw_menu:208},custom_name={text:"Stone Sword",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.19 with minecraft:stone_pickaxe[custom_data={nw_menu:209},custom_name={text:"Stone Pickaxe",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.20 with minecraft:stone_axe[custom_data={nw_menu:210},custom_name={text:"Stone Axe",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.21 with minecraft:stone_shovel[custom_data={nw_menu:211},custom_name={text:"Stone Shovel",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.22 with minecraft:air
item replace block -7 64 -10 container.23 with minecraft:chainmail_helmet[custom_data={nw_menu:212},custom_name={text:"Chainmail Helmet",color:"white",italic:false},lore=[[{text:"Price: 200 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.24 with minecraft:chainmail_chestplate[custom_data={nw_menu:213},custom_name={text:"Chainmail Chestplate",color:"white",italic:false},lore=[[{text:"Price: 320 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.25 with minecraft:chainmail_leggings[custom_data={nw_menu:214},custom_name={text:"Chainmail Leggings",color:"white",italic:false},lore=[[{text:"Price: 280 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.26 with minecraft:chainmail_boots[custom_data={nw_menu:215},custom_name={text:"Chainmail Boots",color:"white",italic:false},lore=[[{text:"Price: 160 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -6 64 -10 container.0 with minecraft:iron_sword[custom_data={nw_menu:216},custom_name={text:"Iron Sword",color:"white",italic:false},lore=[[{text:"Price: 110 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -6 64 -10 container.1 with minecraft:iron_pickaxe[custom_data={nw_menu:217},custom_name={text:"Iron Pickaxe",color:"white",italic:false},lore=[[{text:"Price: 165 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -6 64 -10 container.2 with minecraft:iron_axe[custom_data={nw_menu:218},custom_name={text:"Iron Axe",color:"white",italic:false},lore=[[{text:"Price: 165 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -6 64 -10 container.3 with minecraft:iron_shovel[custom_data={nw_menu:219},custom_name={text:"Iron Shovel",color:"white",italic:false},lore=[[{text:"Price: 55 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -6 64 -10 container.4 with minecraft:air
item replace block -6 64 -10 container.5 with minecraft:iron_helmet[custom_data={nw_menu:220},custom_name={text:"Iron Helmet",color:"white",italic:false},lore=[[{text:"Price: 275 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -6 64 -10 container.6 with minecraft:iron_chestplate[custom_data={nw_menu:221},custom_name={text:"Iron Chestplate",color:"white",italic:false},lore=[[{text:"Price: 440 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -6 64 -10 container.7 with minecraft:iron_leggings[custom_data={nw_menu:222},custom_name={text:"Iron Leggings",color:"white",italic:false},lore=[[{text:"Price: 385 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -6 64 -10 container.8 with minecraft:iron_boots[custom_data={nw_menu:223},custom_name={text:"Iron Boots",color:"white",italic:false},lore=[[{text:"Price: 220 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -6 64 -10 container.9 with minecraft:air
item replace block -6 64 -10 container.10 with minecraft:air
item replace block -6 64 -10 container.11 with minecraft:air
item replace block -6 64 -10 container.12 with minecraft:air
item replace block -6 64 -10 container.13 with minecraft:air
item replace block -6 64 -10 container.14 with minecraft:air
item replace block -6 64 -10 container.15 with minecraft:air
item replace block -6 64 -10 container.16 with minecraft:air
item replace block -6 64 -10 container.17 with minecraft:air
item replace block -6 64 -10 container.18 with minecraft:air
item replace block -6 64 -10 container.19 with minecraft:air
item replace block -6 64 -10 container.20 with minecraft:air
item replace block -6 64 -10 container.21 with minecraft:air
item replace block -6 64 -10 container.22 with minecraft:air
item replace block -6 64 -10 container.23 with minecraft:air
item replace block -6 64 -10 container.24 with minecraft:air
item replace block -6 64 -10 container.25 with minecraft:air
item replace block -6 64 -10 container.26 with minecraft:air
