kill @e[tag=nw.villager]
kill @e[tag=nw.sammler]
kill @e[tag=nw.kasse]
summon minecraft:zombie_villager -5.5 64 -10.5 {Tags:["nw.villager"],NoAI:1b,Silent:1b,Invulnerable:1b,PersistenceRequired:1b,NoGravity:1b,CustomName:{text:"The Collector",color:"dark_red"},CustomNameVisible:1b,VillagerData:{profession:"minecraft:nitwit",level:1,type:"minecraft:swamp"},Offers:{Recipes:[]},IsBaby:0b,Rotation:[0f,0f]}
summon minecraft:interaction -5.5 64 -10.5 {Tags:["nw.sammler"],width:1.6f,height:2.4f}
function nachtwache:sammler/tresen
function nachtwache:sammler/kaufmenue
