execute unless block -1 64 -5 minecraft:chest run setblock -1 64 -5 minecraft:chest[facing=south,type=right]
execute unless block 0 64 -5 minecraft:chest run setblock 0 64 -5 minecraft:chest[facing=south,type=left]
execute unless block 1 64 -5 minecraft:barrel run setblock 1 64 -5 minecraft:barrel[facing=up]
data merge block -1 64 -5 {CustomName:[{text:"BUY   ",color:"dark_red"},{text:"● ",color:"white"},{score:{name:"#konto",objective:"nw.konto"},color:"gold"}]}
data merge block 0 64 -5 {CustomName:[{text:"BUY   ",color:"dark_red"},{text:"● ",color:"white"},{score:{name:"#konto",objective:"nw.konto"},color:"gold"}]}
data merge block 1 64 -5 {CustomName:[{text:"SELL   ",color:"dark_red"},{text:"put goods here",color:"gray"}]}
