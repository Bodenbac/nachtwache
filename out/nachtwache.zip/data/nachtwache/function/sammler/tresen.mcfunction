execute unless block -7 64 -10 minecraft:chest run setblock -7 64 -10 minecraft:chest[facing=south,type=right]
execute unless block -6 64 -10 minecraft:chest run setblock -6 64 -10 minecraft:chest[facing=south,type=left]
execute unless block -5 64 -10 minecraft:barrel run setblock -5 64 -10 minecraft:barrel[facing=up]
data merge block -7 64 -10 {CustomName:[{text:"BUY   ",color:"dark_red"},{text:"● ",color:"white"},{score:{name:"#konto",objective:"nw.konto"},color:"gold"}]}
data merge block -6 64 -10 {CustomName:[{text:"BUY   ",color:"dark_red"},{text:"● ",color:"white"},{score:{name:"#konto",objective:"nw.konto"},color:"gold"}]}
data merge block -5 64 -10 {CustomName:[{text:"SELL   ",color:"dark_red"},{text:"put goods here",color:"gray"}]}
