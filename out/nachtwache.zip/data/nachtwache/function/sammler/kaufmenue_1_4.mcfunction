item replace block -1 64 -5 container.0 with minecraft:stone[custom_data={nw_menu:9001},custom_name={text:"Building Blocks",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.1 with minecraft:iron_ingot[custom_data={nw_menu:9002},custom_name={text:"Minerals & Drops",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.2 with minecraft:bread[custom_data={nw_menu:9003},custom_name={text:"Food & Farming",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.3 with minecraft:redstone[enchantment_glint_override=true,custom_data={nw_menu:9004},custom_name={text:"Tools & Redstone",color:"yellow",italic:false},lore=[{text:"Open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.4 with minecraft:enchanted_book[custom_data={nw_menu:9006},custom_name={text:"Enchanted Books",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.5 with minecraft:nether_star[custom_data={nw_menu:9007},custom_name={text:"Special",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.6 with minecraft:air
item replace block -1 64 -5 container.7 with minecraft:air
item replace block -1 64 -5 container.8 with minecraft:air
item replace block -1 64 -5 container.9 with minecraft:water_bucket[custom_data={nw_menu:15},custom_name={text:"Water Bucket",color:"white",italic:false},lore=[[{text:"Price: 500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.10 with minecraft:lava_bucket[custom_data={nw_menu:16},custom_name={text:"Lava Bucket",color:"white",italic:false},lore=[[{text:"Price: 500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.11 with minecraft:stone_pickaxe[custom_data={nw_menu:23},custom_name={text:"Stone Pickaxe",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.12 with minecraft:stone_sword[custom_data={nw_menu:24},custom_name={text:"Stone Sword",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.13 with minecraft:stone_axe[custom_data={nw_menu:25},custom_name={text:"Stone Axe",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.14 with minecraft:stone_shovel[custom_data={nw_menu:26},custom_name={text:"Stone Shovel",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.15 with minecraft:air
item replace block -1 64 -5 container.16 with minecraft:air
item replace block -1 64 -5 container.17 with minecraft:air
item replace block -1 64 -5 container.18 with minecraft:air
item replace block -1 64 -5 container.19 with minecraft:air
item replace block -1 64 -5 container.20 with minecraft:air
item replace block -1 64 -5 container.21 with minecraft:air
item replace block -1 64 -5 container.22 with minecraft:air
item replace block -1 64 -5 container.23 with minecraft:air
item replace block -1 64 -5 container.24 with minecraft:air
item replace block -1 64 -5 container.25 with minecraft:air
item replace block -1 64 -5 container.26 with minecraft:air
item replace block 0 64 -5 container.0 with minecraft:air
item replace block 0 64 -5 container.1 with minecraft:air
item replace block 0 64 -5 container.2 with minecraft:air
item replace block 0 64 -5 container.3 with minecraft:air
item replace block 0 64 -5 container.4 with minecraft:air
item replace block 0 64 -5 container.5 with minecraft:air
item replace block 0 64 -5 container.6 with minecraft:air
item replace block 0 64 -5 container.7 with minecraft:air
item replace block 0 64 -5 container.8 with minecraft:air
item replace block 0 64 -5 container.9 with minecraft:air
item replace block 0 64 -5 container.10 with minecraft:air
item replace block 0 64 -5 container.11 with minecraft:air
item replace block 0 64 -5 container.12 with minecraft:air
item replace block 0 64 -5 container.13 with minecraft:air
item replace block 0 64 -5 container.14 with minecraft:air
item replace block 0 64 -5 container.15 with minecraft:air
item replace block 0 64 -5 container.16 with minecraft:air
item replace block 0 64 -5 container.17 with minecraft:air
item replace block 0 64 -5 container.18 with minecraft:air
item replace block 0 64 -5 container.19 with minecraft:air
item replace block 0 64 -5 container.20 with minecraft:air
item replace block 0 64 -5 container.21 with minecraft:air
item replace block 0 64 -5 container.22 with minecraft:air
item replace block 0 64 -5 container.23 with minecraft:air
item replace block 0 64 -5 container.24 with minecraft:air
item replace block 0 64 -5 container.25 with minecraft:air
item replace block 0 64 -5 container.26 with minecraft:air
