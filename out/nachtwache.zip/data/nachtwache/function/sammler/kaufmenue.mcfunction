execute unless score #seite nw.status matches 1.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 2.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_1_1
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 2.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_2_1
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 2.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_3_1
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 2.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_4_1
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 3.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_5_1
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_5_2
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 3.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_6_1
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_6_2
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 3.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_7_1
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_7_2
