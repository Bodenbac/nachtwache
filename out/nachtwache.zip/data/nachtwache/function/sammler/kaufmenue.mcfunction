execute unless score #seite nw.status matches 1.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 5 run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 8.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_1_1
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_1_2
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 3 run function nachtwache:sammler/kaufmenue_1_3
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 4 run function nachtwache:sammler/kaufmenue_1_4
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 6 run function nachtwache:sammler/kaufmenue_1_6
execute if score #phase nw.phase matches 1 if score #seite nw.status matches 7 run function nachtwache:sammler/kaufmenue_1_7
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 5 run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 8.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_2_1
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_2_2
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 3 run function nachtwache:sammler/kaufmenue_2_3
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 4 run function nachtwache:sammler/kaufmenue_2_4
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 6 run function nachtwache:sammler/kaufmenue_2_6
execute if score #phase nw.phase matches 2 if score #seite nw.status matches 7 run function nachtwache:sammler/kaufmenue_2_7
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 8.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_3_1
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_3_2
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 3 run function nachtwache:sammler/kaufmenue_3_3
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 4 run function nachtwache:sammler/kaufmenue_3_4
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 5 run function nachtwache:sammler/kaufmenue_3_5
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 6 run function nachtwache:sammler/kaufmenue_3_6
execute if score #phase nw.phase matches 3 if score #seite nw.status matches 7 run function nachtwache:sammler/kaufmenue_3_7
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 8.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_4_1
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_4_2
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 3 run function nachtwache:sammler/kaufmenue_4_3
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 4 run function nachtwache:sammler/kaufmenue_4_4
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 5 run function nachtwache:sammler/kaufmenue_4_5
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 6 run function nachtwache:sammler/kaufmenue_4_6
execute if score #phase nw.phase matches 4 if score #seite nw.status matches 7 run function nachtwache:sammler/kaufmenue_4_7
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 8.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_5_1
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_5_2
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 3 run function nachtwache:sammler/kaufmenue_5_3
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 4 run function nachtwache:sammler/kaufmenue_5_4
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 5 run function nachtwache:sammler/kaufmenue_5_5
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 6 run function nachtwache:sammler/kaufmenue_5_6
execute if score #phase nw.phase matches 5 if score #seite nw.status matches 7 run function nachtwache:sammler/kaufmenue_5_7
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 8.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_6_1
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_6_2
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 3 run function nachtwache:sammler/kaufmenue_6_3
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 4 run function nachtwache:sammler/kaufmenue_6_4
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 5 run function nachtwache:sammler/kaufmenue_6_5
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 6 run function nachtwache:sammler/kaufmenue_6_6
execute if score #phase nw.phase matches 6 if score #seite nw.status matches 7 run function nachtwache:sammler/kaufmenue_6_7
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 8.. run scoreboard players set #seite nw.status 1
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 1 run function nachtwache:sammler/kaufmenue_7_1
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 2 run function nachtwache:sammler/kaufmenue_7_2
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 3 run function nachtwache:sammler/kaufmenue_7_3
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 4 run function nachtwache:sammler/kaufmenue_7_4
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 5 run function nachtwache:sammler/kaufmenue_7_5
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 6 run function nachtwache:sammler/kaufmenue_7_6
execute if score #phase nw.phase matches 7 if score #seite nw.status matches 7 run function nachtwache:sammler/kaufmenue_7_7
