item replace block -1 64 -5 container.0 with minecraft:observer[custom_data={nw_menu:72},custom_name={text:"Observer",color:"white",italic:false},lore=[[{text:"Price: 60 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 3840 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.1 with minecraft:dispenser[custom_data={nw_menu:73},custom_name={text:"Dispenser",color:"white",italic:false},lore=[[{text:"Price: 80 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 5120 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.2 with minecraft:slime_ball[custom_data={nw_menu:74},custom_name={text:"Slimeball",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1920 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.3 with minecraft:tnt[custom_data={nw_menu:75},custom_name={text:"TNT",color:"white",italic:false},lore=[[{text:"Price: 200 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 12800 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.4 with minecraft:cobweb[custom_data={nw_menu:76},custom_name={text:"Cobweb",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1280 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.5 with minecraft:magma_block[custom_data={nw_menu:77},custom_name={text:"Magma Block",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1280 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.6 with minecraft:chest[item_model="nachtwache:kit",custom_data={nw_menu:78},custom_name={text:"Piston Crusher Kit",color:"white",italic:false},lore=[[{text:"Price: 450 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.7 with minecraft:chest[item_model="nachtwache:kit",custom_data={nw_menu:79},custom_name={text:"Arrow Tower Kit",color:"white",italic:false},lore=[[{text:"Price: 350 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.8 with minecraft:experience_bottle[custom_data={nw_menu:101},custom_name={text:"Bottle o' Enchanting",color:"white",italic:false},lore=[[{text:"Price: 50 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 3200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.9 with minecraft:ender_pearl[custom_data={nw_menu:102},custom_name={text:"Ender Pearl",color:"white",italic:false},lore=[[{text:"Price: 100 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 16 for 1600 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.10 with minecraft:totem_of_undying[custom_data={nw_menu:103},custom_name={text:"Totem of Undying",color:"white",italic:false},lore=[[{text:"Price: 1500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.11 with minecraft:elytra[custom_data={nw_menu:104},custom_name={text:"Elytra",color:"white",italic:false},lore=[[{text:"Price: 5000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.12 with minecraft:iron_golem_spawn_egg[custom_data={nw_menu:105},custom_name={text:"Iron Golem Egg",color:"white",italic:false},lore=[[{text:"Price: 2000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.13 with minecraft:netherite_scrap[custom_data={nw_menu:120},custom_name={text:"Netherite Scrap",color:"white",italic:false},lore=[[{text:"Price: 600 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 38400 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.14 with minecraft:netherite_upgrade_smithing_template[custom_data={nw_menu:121},custom_name={text:"Netherite Upgrade Template",color:"white",italic:false},lore=[[{text:"Price: 1500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.15 with minecraft:trident[custom_data={nw_menu:124},custom_name={text:"Trident",color:"white",italic:false},lore=[[{text:"Price: 2000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.16 with minecraft:beacon[custom_data={nw_menu:125},custom_name={text:"Beacon",color:"white",italic:false},lore=[[{text:"Price: 8000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.17 with minecraft:air
item replace block -1 64 -5 container.18 with minecraft:air
item replace block -1 64 -5 container.19 with minecraft:air
item replace block -1 64 -5 container.20 with minecraft:air
item replace block -1 64 -5 container.21 with minecraft:air
item replace block -1 64 -5 container.22 with minecraft:air
item replace block -1 64 -5 container.23 with minecraft:air
item replace block -1 64 -5 container.24 with minecraft:air
item replace block -1 64 -5 container.25 with minecraft:air
item replace block -1 64 -5 container.26 with minecraft:air
item replace block 0 64 -5 container.0 with minecraft:air
item replace block 0 64 -5 container.1 with minecraft:air
item replace block 0 64 -5 container.2 with minecraft:air
item replace block 0 64 -5 container.3 with minecraft:air
item replace block 0 64 -5 container.4 with minecraft:air
item replace block 0 64 -5 container.5 with minecraft:air
item replace block 0 64 -5 container.6 with minecraft:air
item replace block 0 64 -5 container.7 with minecraft:air
item replace block 0 64 -5 container.8 with minecraft:air
item replace block 0 64 -5 container.9 with minecraft:air
item replace block 0 64 -5 container.10 with minecraft:air
item replace block 0 64 -5 container.11 with minecraft:air
item replace block 0 64 -5 container.12 with minecraft:air
item replace block 0 64 -5 container.13 with minecraft:air
item replace block 0 64 -5 container.14 with minecraft:air
item replace block 0 64 -5 container.15 with minecraft:air
item replace block 0 64 -5 container.16 with minecraft:air
item replace block 0 64 -5 container.17 with minecraft:air
item replace block 0 64 -5 container.18 with minecraft:air
item replace block 0 64 -5 container.19 with minecraft:air
item replace block 0 64 -5 container.20 with minecraft:air
item replace block 0 64 -5 container.21 with minecraft:air
item replace block 0 64 -5 container.22 with minecraft:air
item replace block 0 64 -5 container.23 with minecraft:air
item replace block 0 64 -5 container.24 with minecraft:air
item replace block 0 64 -5 container.25 with minecraft:air
item replace block 0 64 -5 container.26 with minecraft:arrow[custom_data={nw_menu:9001},custom_name={text:"Next page",color:"yellow",italic:false}]
