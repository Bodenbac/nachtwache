tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"The chest on the left: buy. Click for one, shift-click for a stack. The barrel on the right: sell, put goods in, coins go to the account. I do not take tools.","color":"gray"}]
tellraw @s [{"text":"●","color":"white"},{"text":" Coins: ","color":"gold"},{"score":{"name":"#konto","objective":"nw.konto"},"color":"yellow"}]
