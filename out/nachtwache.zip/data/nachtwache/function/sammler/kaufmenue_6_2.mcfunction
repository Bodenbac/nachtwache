item replace block -1 64 -5 container.0 with minecraft:stone[custom_data={nw_menu:9001},custom_name={text:"Building Blocks",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.1 with minecraft:iron_ingot[enchantment_glint_override=true,custom_data={nw_menu:9002},custom_name={text:"Minerals & Drops",color:"yellow",italic:false},lore=[{text:"Open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.2 with minecraft:bread[custom_data={nw_menu:9003},custom_name={text:"Food & Farming",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.3 with minecraft:redstone[custom_data={nw_menu:9004},custom_name={text:"Tools & Redstone",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.4 with minecraft:brewing_stand[custom_data={nw_menu:9005},custom_name={text:"Brewing & Magic",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.5 with minecraft:enchanted_book[custom_data={nw_menu:9006},custom_name={text:"Enchanted Books",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.6 with minecraft:nether_star[custom_data={nw_menu:9007},custom_name={text:"Special",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.7 with minecraft:air
item replace block -1 64 -5 container.8 with minecraft:air
item replace block -1 64 -5 container.9 with minecraft:iron_ingot[custom_data={nw_menu:29},custom_name={text:"Iron Ingot",color:"white",italic:false},lore=[[{text:"Price: 50 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 3200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.10 with minecraft:coal[custom_data={nw_menu:130},custom_name={text:"Coal",color:"white",italic:false},lore=[[{text:"Price: 15 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 960 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.11 with minecraft:diamond[custom_data={nw_menu:131},custom_name={text:"Diamond",color:"white",italic:false},lore=[[{text:"Price: 1000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 64000 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.12 with minecraft:bone[custom_data={nw_menu:141},custom_name={text:"Bone",color:"white",italic:false},lore=[[{text:"Price: 35 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 2240 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.13 with minecraft:leather[custom_data={nw_menu:46},custom_name={text:"Leather",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1920 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.14 with minecraft:string[custom_data={nw_menu:47},custom_name={text:"String",color:"white",italic:false},lore=[[{text:"Price: 10 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 640 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.15 with minecraft:gold_ingot[custom_data={nw_menu:61},custom_name={text:"Gold Ingot",color:"white",italic:false},lore=[[{text:"Price: 100 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 6400 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.16 with minecraft:lapis_lazuli[custom_data={nw_menu:65},custom_name={text:"Lapis Lazuli",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1280 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.17 with minecraft:slime_ball[custom_data={nw_menu:74},custom_name={text:"Slimeball",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1920 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.18 with minecraft:copper_ingot[custom_data={nw_menu:80},custom_name={text:"Copper Ingot",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1280 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.19 with minecraft:amethyst_shard[custom_data={nw_menu:81},custom_name={text:"Amethyst Shard",color:"white",italic:false},lore=[[{text:"Price: 40 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 2560 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.20 with minecraft:quartz[custom_data={nw_menu:82},custom_name={text:"Quartz",color:"white",italic:false},lore=[[{text:"Price: 25 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1600 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.21 with minecraft:phantom_membrane[custom_data={nw_menu:111},custom_name={text:"Phantom Membrane",color:"white",italic:false},lore=[[{text:"Price: 150 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 9600 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.22 with minecraft:shulker_shell[custom_data={nw_menu:112},custom_name={text:"Shulker Shell",color:"white",italic:false},lore=[[{text:"Price: 800 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 51200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.23 with minecraft:air
item replace block -1 64 -5 container.24 with minecraft:air
item replace block -1 64 -5 container.25 with minecraft:air
item replace block -1 64 -5 container.26 with minecraft:air
item replace block 0 64 -5 container.0 with minecraft:air
item replace block 0 64 -5 container.1 with minecraft:air
item replace block 0 64 -5 container.2 with minecraft:air
item replace block 0 64 -5 container.3 with minecraft:air
item replace block 0 64 -5 container.4 with minecraft:air
item replace block 0 64 -5 container.5 with minecraft:air
item replace block 0 64 -5 container.6 with minecraft:air
item replace block 0 64 -5 container.7 with minecraft:air
item replace block 0 64 -5 container.8 with minecraft:air
item replace block 0 64 -5 container.9 with minecraft:air
item replace block 0 64 -5 container.10 with minecraft:air
item replace block 0 64 -5 container.11 with minecraft:air
item replace block 0 64 -5 container.12 with minecraft:air
item replace block 0 64 -5 container.13 with minecraft:air
item replace block 0 64 -5 container.14 with minecraft:air
item replace block 0 64 -5 container.15 with minecraft:air
item replace block 0 64 -5 container.16 with minecraft:air
item replace block 0 64 -5 container.17 with minecraft:air
item replace block 0 64 -5 container.18 with minecraft:air
item replace block 0 64 -5 container.19 with minecraft:air
item replace block 0 64 -5 container.20 with minecraft:air
item replace block 0 64 -5 container.21 with minecraft:air
item replace block 0 64 -5 container.22 with minecraft:air
item replace block 0 64 -5 container.23 with minecraft:air
item replace block 0 64 -5 container.24 with minecraft:air
item replace block 0 64 -5 container.25 with minecraft:air
item replace block 0 64 -5 container.26 with minecraft:air
