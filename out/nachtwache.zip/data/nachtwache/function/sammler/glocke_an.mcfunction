scoreboard players set #glocke nw.upgrade 1
tellraw @a [{"text":"The watch bell is active. It rings when something steps onto the road.","color":"gold"}]
