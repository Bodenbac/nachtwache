item replace block -7 64 -10 container.0 with minecraft:stone[custom_data={nw_menu:9001},custom_name={text:"Building Blocks",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.1 with minecraft:iron_ingot[custom_data={nw_menu:9002},custom_name={text:"Minerals & Drops",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.2 with minecraft:rotten_flesh[custom_data={nw_menu:9003},custom_name={text:"Mob Drops",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.3 with minecraft:bread[custom_data={nw_menu:9004},custom_name={text:"Food",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.4 with minecraft:redstone[custom_data={nw_menu:9005},custom_name={text:"Tools & Redstone",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.5 with minecraft:brewing_stand[custom_data={nw_menu:9006},custom_name={text:"Brewing & Magic",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.6 with minecraft:enchanted_book[custom_data={nw_menu:9007},custom_name={text:"Enchanted Books",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.7 with minecraft:nether_star[enchantment_glint_override=true,custom_data={nw_menu:9008},custom_name={text:"Special",color:"yellow",italic:false},lore=[{text:"Open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.8 with minecraft:air
item replace block -7 64 -10 container.9 with minecraft:soul_lantern[item_model="nachtwache:lantern",custom_data={nw_menu:30},custom_name={text:"Collector Lantern",color:"white",italic:false},lore=[{text:"Place it on the road or on your island.",color:"gray",italic:false},{text:"Enemies within 8 blocks are slowed.",color:"gray",italic:false},{text:"Burns for three nights, then goes out.",color:"gray",italic:false},[{text:"Price: 300 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.10 with minecraft:paper[item_model="nachtwache:contract",custom_data={nw_menu:31},custom_name={text:"Bounty Contract",color:"white",italic:false},lore=[{text:"Tonight: double bounty, wave 50% bigger.",color:"gray",italic:false},{text:"One contract at a time. Signed by daylight only.",color:"gray",italic:false},[{text:"Price: 150 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.11 with minecraft:red_dye[item_model="nachtwache:life",custom_data={nw_menu:34},custom_name={text:"One more Life",color:"white",italic:false},lore=[{text:"Repairs the beacon by one heart.",color:"gray",italic:false},{text:"Buy before the wave, not during it.",color:"gray",italic:false},[{text:"Price: 1500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.12 with minecraft:zombie_spawn_egg[item_model="nachtwache:archer",custom_data={nw_menu:48},custom_name={text:"Bogi the Archer",color:"white",italic:false},lore=[[{text:"Price: 7500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.13 with minecraft:zombie_spawn_egg[item_model="nachtwache:dwarf",custom_data={nw_menu:49},custom_name={text:"Fraggle the Dwarf",color:"white",italic:false},lore=[[{text:"Price: 10000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.14 with minecraft:amethyst_shard[item_model="nachtwache:focus",custom_data={nw_menu:32},custom_name={text:"Source Focus",color:"white",italic:false},lore=[{text:"Right-click: the Source pays double for 10 minutes.",color:"gray",italic:false},{text:"Burns up when used.",color:"gray",italic:false},[{text:"Price: 800 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 16 for 12800 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.15 with minecraft:carved_pumpkin[item_model="nachtwache:decoy",custom_data={nw_menu:33},custom_name={text:"Decoy Totem",color:"white",italic:false},lore=[{text:"Right-click: puts up a decoy where you stand.",color:"gray",italic:false},{text:"Enemies go for it instead of you until it breaks.",color:"gray",italic:false},[{text:"Price: 600 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 16 for 9600 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.16 with minecraft:echo_shard[custom_data={nw_menu:184},custom_name={text:"Reaper Skull",color:"white",italic:false},lore=[[{text:"Price: 700 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 16 for 11200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.17 with minecraft:zombie_spawn_egg[item_model="nachtwache:generator",custom_data={nw_menu:35},custom_name={text:"Source Generator",color:"white",italic:false},lore=[[{text:"Price: 20000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.18 with minecraft:totem_of_undying[custom_data={nw_menu:103},custom_name={text:"Totem of Undying",color:"white",italic:false},lore=[[{text:"Price: 1500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.19 with minecraft:elytra[custom_data={nw_menu:104},custom_name={text:"Elytra",color:"white",italic:false},lore=[[{text:"Price: 5000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.20 with minecraft:iron_golem_spawn_egg[custom_data={nw_menu:105},custom_name={text:"Iron Golem Egg",color:"white",italic:false},lore=[[{text:"Price: 2000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.21 with minecraft:wither_skeleton_skull[custom_data={nw_menu:114},custom_name={text:"Wither Skeleton Skull",color:"white",italic:false},lore=[[{text:"Price: 1500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 96000 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.22 with minecraft:heart_of_the_sea[custom_data={nw_menu:116},custom_name={text:"Heart of the Sea",color:"white",italic:false},lore=[[{text:"Price: 2500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.23 with minecraft:air
item replace block -7 64 -10 container.24 with minecraft:air
item replace block -7 64 -10 container.25 with minecraft:air
item replace block -7 64 -10 container.26 with minecraft:air
item replace block -6 64 -10 container.0 with minecraft:air
item replace block -6 64 -10 container.1 with minecraft:air
item replace block -6 64 -10 container.2 with minecraft:air
item replace block -6 64 -10 container.3 with minecraft:air
item replace block -6 64 -10 container.4 with minecraft:air
item replace block -6 64 -10 container.5 with minecraft:air
item replace block -6 64 -10 container.6 with minecraft:air
item replace block -6 64 -10 container.7 with minecraft:air
item replace block -6 64 -10 container.8 with minecraft:air
item replace block -6 64 -10 container.9 with minecraft:air
item replace block -6 64 -10 container.10 with minecraft:air
item replace block -6 64 -10 container.11 with minecraft:air
item replace block -6 64 -10 container.12 with minecraft:air
item replace block -6 64 -10 container.13 with minecraft:air
item replace block -6 64 -10 container.14 with minecraft:air
item replace block -6 64 -10 container.15 with minecraft:air
item replace block -6 64 -10 container.16 with minecraft:air
item replace block -6 64 -10 container.17 with minecraft:air
item replace block -6 64 -10 container.18 with minecraft:air
item replace block -6 64 -10 container.19 with minecraft:air
item replace block -6 64 -10 container.20 with minecraft:air
item replace block -6 64 -10 container.21 with minecraft:air
item replace block -6 64 -10 container.22 with minecraft:air
item replace block -6 64 -10 container.23 with minecraft:air
item replace block -6 64 -10 container.24 with minecraft:air
item replace block -6 64 -10 container.25 with minecraft:air
item replace block -6 64 -10 container.26 with minecraft:air
