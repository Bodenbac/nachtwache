tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Come back with 10 levels of experience.","color":"gray"}]
playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
