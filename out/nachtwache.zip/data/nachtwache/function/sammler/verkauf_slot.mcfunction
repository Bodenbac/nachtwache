$execute store result score #n nw.tmp run data get block -5 64 -10 Items[{Slot:$(slot)b}].count
$data modify storage nachtwache:tmp id set string block -5 64 -10 Items[{Slot:$(slot)b}].id 10
scoreboard players set #w nw.tmp2 0
function nachtwache:sammler/preis with storage nachtwache:tmp
execute if score #w nw.tmp2 matches ..0 run return 0
scoreboard players operation #gain nw.tmp = #n nw.tmp
scoreboard players operation #gain nw.tmp *= #w nw.tmp2
scoreboard players set #pz nw.tmp2 100
scoreboard players operation #gain nw.tmp *= #pz nw.tmp2
scoreboard players operation #gain nw.tmp /= #100 nw.const
execute if score #gain nw.tmp matches ..0 run return 0
scoreboard players operation #konto nw.konto += #gain nw.tmp
scoreboard players operation #verdient nw.verdient += #gain nw.tmp
$item replace block -5 64 -10 container.$(slot) with minecraft:air
playsound minecraft:entity.villager.trade neutral @a[distance=..12] -5 64 -10 0.7 1
title @a[distance=..12] actionbar [{"text":"Sold: +","color":"gold"},{"score":{"name":"#gain","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"gold"},{"text":"●","color":"white"}]
