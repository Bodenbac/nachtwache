scoreboard players set #anz nw.tmp 1
execute if items entity @s container.* *[custom_data~{nw_menu:49}] run scoreboard players set #anz nw.tmp 1
clear @s *[custom_data~{nw_menu:49}]
scoreboard players set #preis nw.tmp 10000
scoreboard players operation #preis nw.tmp *= #anz nw.tmp
execute if score #konto nw.konto < #preis nw.tmp run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" needed, ","color":"gray"},{"score":{"name":"#konto","objective":"nw.konto"},"color":"gold"},{"text":" on the account.","color":"gray"}]
execute if score #konto nw.konto < #preis nw.tmp run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
execute if score #konto nw.konto < #preis nw.tmp run return 0
scoreboard players operation #konto nw.konto -= #preis nw.tmp
execute store result storage nachtwache:tmp n int 1 run scoreboard players get #anz nw.tmp
data modify storage nachtwache:tmp item set value 'minecraft:zombie_spawn_egg[item_model="nachtwache:dwarf",custom_name={text:"Fraggle",color:"aqua",italic:false},custom_data={nw_zwerg:1b,lvl:0,bp:0},entity_data={id:"minecraft:marker",Tags:["nw.zwerg_neu","nw.lvl0","nw.bp0"]},lore=[{text:"Place him next to a Source Generator, on solid ground.",color:"gray",italic:false},{text:"He mines the generator right in front of him. Four dwarves fit around one.",color:"gray",italic:false},{text:"Right-click: open his pack, buy speed and space, sell everything.",color:"gray",italic:false},{text:"Speed: one block every 15 s (level 0)",color:"aqua",italic:false},{text:"Pack: 6 slots (1 rows)",color:"aqua",italic:false}]]'
function nachtwache:sammler/geben with storage nachtwache:tmp
playsound minecraft:entity.villager.yes neutral @s ~ ~ ~ 1 0.9
title @s actionbar [{"text":"Bought: ","color":"green"},{"score":{"name":"#anz","objective":"nw.tmp"},"color":"white"},{"text":" Fraggle the Dwarf  (-","color":"green"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"green"},{"text":"●","color":"white"},{"text":")","color":"green"}]
execute store result score #r nw.tmp2 run random value 1..4
execute if score #r nw.tmp2 matches 1 run function nachtwache:sammler/spruch/kauf
