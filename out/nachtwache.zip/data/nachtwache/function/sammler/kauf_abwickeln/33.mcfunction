scoreboard players set #anz nw.tmp 1
execute if items entity @s container.* *[custom_data~{nw_menu:33}] run scoreboard players set #anz nw.tmp 16
clear @s *[custom_data~{nw_menu:33}]
scoreboard players set #preis nw.tmp 600
scoreboard players operation #preis nw.tmp *= #anz nw.tmp
execute if score #konto nw.konto < #preis nw.tmp run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" needed, ","color":"gray"},{"score":{"name":"#konto","objective":"nw.konto"},"color":"gold"},{"text":" on the account.","color":"gray"}]
execute if score #konto nw.konto < #preis nw.tmp run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
execute if score #konto nw.konto < #preis nw.tmp run return 0
scoreboard players operation #konto nw.konto -= #preis nw.tmp
execute store result storage nachtwache:tmp n int 1 run scoreboard players get #anz nw.tmp
data modify storage nachtwache:tmp item set value 'minecraft:carved_pumpkin[item_model="nachtwache:decoy",custom_name={text:"Decoy Totem",color:"gold",italic:false},custom_data={nw_decoy:1b},consumable={consume_seconds:0.6f,animation:"drink",sound:"minecraft:block.amethyst_block.chime",has_consume_particles:false},max_stack_size=16,lore=[{text:"Right-click: puts up a decoy where you stand.",color:"gray",italic:false},{text:"Enemies go for it instead of you until it breaks.",color:"gray",italic:false}]]'
function nachtwache:sammler/geben with storage nachtwache:tmp
playsound minecraft:entity.villager.yes neutral @s ~ ~ ~ 1 0.9
title @s actionbar [{"text":"Bought: ","color":"green"},{"score":{"name":"#anz","objective":"nw.tmp"},"color":"white"},{"text":" Decoy Totem  (-","color":"green"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"green"},{"text":"●","color":"white"},{"text":")","color":"green"}]
execute store result score #r nw.tmp2 run random value 1..4
execute if score #r nw.tmp2 matches 1 run function nachtwache:sammler/spruch/kauf
