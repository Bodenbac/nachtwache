scoreboard players set #anz nw.tmp 1
execute if items entity @s container.* *[custom_data~{nw_menu:34}] run scoreboard players set #anz nw.tmp 1
clear @s *[custom_data~{nw_menu:34}]
scoreboard players set #preis nw.tmp 1500
scoreboard players operation #preis nw.tmp *= #anz nw.tmp
execute if score #konto nw.konto < #preis nw.tmp run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" needed, ","color":"gray"},{"score":{"name":"#konto","objective":"nw.konto"},"color":"gold"},{"text":" on the account.","color":"gray"}]
execute if score #konto nw.konto < #preis nw.tmp run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
execute if score #konto nw.konto < #preis nw.tmp run return 0
scoreboard players operation #konto nw.konto -= #preis nw.tmp
execute store result storage nachtwache:tmp n int 1 run scoreboard players get #anz nw.tmp
execute if score #leben nw.leben matches 20.. run scoreboard players add #konto nw.konto 1500
execute if score #leben nw.leben matches 20.. run return run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"The beacon is already whole.","color":"gray"}]
scoreboard players add #leben nw.leben 1
function nachtwache:beacon/anzeige
particle minecraft:heart 0.5 65.6 4.5 0.4 0.5 0.4 0 12
tellraw @a [{"text":"The beacon burns brighter. Lives: ","color":"red"},{"score":{"name":"#leben","objective":"nw.leben"},"color":"white"}]
playsound minecraft:entity.villager.yes neutral @s ~ ~ ~ 1 0.9
title @s actionbar [{"text":"Bought: ","color":"green"},{"score":{"name":"#anz","objective":"nw.tmp"},"color":"white"},{"text":" One more Life  (-","color":"green"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"green"},{"text":"●","color":"white"},{"text":")","color":"green"}]
execute store result score #r nw.tmp2 run random value 1..4
execute if score #r nw.tmp2 matches 1 run function nachtwache:sammler/spruch/kauf
