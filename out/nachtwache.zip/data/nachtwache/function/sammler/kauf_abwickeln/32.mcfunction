scoreboard players set #anz nw.tmp 1
execute if items entity @s container.* *[custom_data~{nw_menu:32}] run scoreboard players set #anz nw.tmp 16
clear @s *[custom_data~{nw_menu:32}]
scoreboard players operation #preis nw.tmp = #phase nw.phase
scoreboard players set #fpreis nw.tmp2 500
scoreboard players operation #preis nw.tmp *= #fpreis nw.tmp2
scoreboard players operation #preis nw.tmp *= #anz nw.tmp
execute if score #konto nw.konto < #preis nw.tmp run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" needed, ","color":"gray"},{"score":{"name":"#konto","objective":"nw.konto"},"color":"gold"},{"text":" on the account.","color":"gray"}]
execute if score #konto nw.konto < #preis nw.tmp run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
execute if score #konto nw.konto < #preis nw.tmp run return 0
scoreboard players operation #konto nw.konto -= #preis nw.tmp
execute store result storage nachtwache:tmp n int 1 run scoreboard players get #anz nw.tmp
data modify storage nachtwache:tmp item set value 'minecraft:amethyst_shard[item_model="nachtwache:focus",custom_name={text:"Source Focus",color:"light_purple",italic:false},custom_data={nw_focus:1b},consumable={consume_seconds:0.6f,animation:"drink",sound:"minecraft:block.amethyst_block.chime",has_consume_particles:false},max_stack_size=16,lore=[{text:"Right-click: the Source pays double.",color:"gray",italic:false},{text:"How long is a gamble: 10 to 180 seconds.",color:"gray",italic:false},{text:"Price goes up with the Source tier.",color:"dark_gray",italic:false},{text:"Burns up when used.",color:"gray",italic:false}]]'
function nachtwache:sammler/geben with storage nachtwache:tmp
playsound minecraft:entity.villager.yes neutral @s ~ ~ ~ 1 0.9
title @s actionbar [{"text":"Bought: ","color":"green"},{"score":{"name":"#anz","objective":"nw.tmp"},"color":"white"},{"text":" Source Focus  (-","color":"green"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"green"},{"text":"●","color":"white"},{"text":")","color":"green"}]
execute store result score #r nw.tmp2 run random value 1..4
execute if score #r nw.tmp2 matches 1 run function nachtwache:sammler/spruch/kauf
