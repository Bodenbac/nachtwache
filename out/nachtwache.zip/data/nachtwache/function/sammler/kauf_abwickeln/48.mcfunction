scoreboard players set #anz nw.tmp 1
execute if items entity @s container.* *[custom_data~{nw_menu:48}] run scoreboard players set #anz nw.tmp 1
clear @s *[custom_data~{nw_menu:48}]
scoreboard players set #preis nw.tmp 7500
scoreboard players operation #preis nw.tmp *= #anz nw.tmp
execute if score #konto nw.konto < #preis nw.tmp run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" needed, ","color":"gray"},{"score":{"name":"#konto","objective":"nw.konto"},"color":"gold"},{"text":" on the account.","color":"gray"}]
execute if score #konto nw.konto < #preis nw.tmp run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
execute if score #konto nw.konto < #preis nw.tmp run return 0
scoreboard players operation #konto nw.konto -= #preis nw.tmp
execute store result storage nachtwache:tmp n int 1 run scoreboard players get #anz nw.tmp
data modify storage nachtwache:tmp item set value 'minecraft:zombie_spawn_egg[item_model="nachtwache:archer",custom_name={text:"Bogi",color:"green",italic:false},custom_data={nw_bogi:1b},entity_data={id:"minecraft:marker",Tags:["nw.bogi_neu"],data:{sp:0,st:0,mu:0,fl:0,inf:0,kb:0,rg:0}},lore=[{text:"Put him anywhere on your island, he shoots what comes close.",color:"gray",italic:false},{text:"Right-click: his row of slots. Arrows go left, upgrades are on the right.",color:"gray",italic:false},{text:"No arrows, no shots. Break him: he jumps back into your inventory.",color:"gray",italic:false}]]'
function nachtwache:sammler/geben with storage nachtwache:tmp
playsound minecraft:entity.villager.yes neutral @s ~ ~ ~ 1 0.9
title @s actionbar [{"text":"Bought: ","color":"green"},{"score":{"name":"#anz","objective":"nw.tmp"},"color":"white"},{"text":" Bogi the Archer  (-","color":"green"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"green"},{"text":"●","color":"white"},{"text":")","color":"green"}]
execute store result score #r nw.tmp2 run random value 1..4
execute if score #r nw.tmp2 matches 1 run function nachtwache:sammler/spruch/kauf
