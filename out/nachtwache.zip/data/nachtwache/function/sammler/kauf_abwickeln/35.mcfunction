scoreboard players set #anz nw.tmp 1
execute if items entity @s container.* *[custom_data~{nw_menu:35}] run scoreboard players set #anz nw.tmp 1
clear @s *[custom_data~{nw_menu:35}]
scoreboard players set #preis nw.tmp 20000
scoreboard players operation #preis nw.tmp *= #anz nw.tmp
execute if score #konto nw.konto < #preis nw.tmp run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" needed, ","color":"gray"},{"score":{"name":"#konto","objective":"nw.konto"},"color":"gold"},{"text":" on the account.","color":"gray"}]
execute if score #konto nw.konto < #preis nw.tmp run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
execute if score #konto nw.konto < #preis nw.tmp run return 0
scoreboard players operation #konto nw.konto -= #preis nw.tmp
execute store result storage nachtwache:tmp n int 1 run scoreboard players get #anz nw.tmp
data modify storage nachtwache:tmp item set value 'minecraft:zombie_spawn_egg[item_model="nachtwache:generator",custom_name={text:"Source Generator",color:"light_purple",italic:false},custom_data={nw_gen:1b},entity_data={id:"minecraft:marker",Tags:["nw.gen_neu"]},lore=[{text:"Put it down anywhere on your island.",color:"gray",italic:false},{text:"Mine it for blocks and coins, right-click to see what it gives.",color:"gray",italic:false},{text:"Every generator counts towards the same tier.",color:"gray",italic:false},[{text:"Tier follows the Source",color:"light_purple",italic:false}]]]'
function nachtwache:sammler/geben with storage nachtwache:tmp
playsound minecraft:entity.villager.yes neutral @s ~ ~ ~ 1 0.9
title @s actionbar [{"text":"Bought: ","color":"green"},{"score":{"name":"#anz","objective":"nw.tmp"},"color":"white"},{"text":" Source Generator  (-","color":"green"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" ","color":"green"},{"text":"●","color":"white"},{"text":")","color":"green"}]
execute store result score #r nw.tmp2 run random value 1..4
execute if score #r nw.tmp2 matches 1 run function nachtwache:sammler/spruch/kauf
