clear @s *[custom_data~{nw_menu:31}]
execute if score #status nw.status matches 1 run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Contracts are signed by daylight. Come back in the morning.","color":"gray"}]
execute if score #status nw.status matches 1 run return run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
execute if score #kontrakt nw.upgrade matches 1.. run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"One contract at a time. Tonight is already spoken for.","color":"gray"}]
execute if score #kontrakt nw.upgrade matches 1.. run return run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
scoreboard players set #preis nw.tmp 150
execute if score #konto nw.konto < #preis nw.tmp run tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"Not enough coins. ","color":"gray"},{"score":{"name":"#preis","objective":"nw.tmp"},"color":"gold"},{"text":" needed.","color":"gray"}]
execute if score #konto nw.konto < #preis nw.tmp run return run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1
scoreboard players operation #konto nw.konto -= #preis nw.tmp
scoreboard players set #kontrakt nw.upgrade 1
playsound minecraft:item.book.page_turn neutral @a ~ ~ ~ 1 0.8
tellraw @a [{"text":"[The Collector] ","color":"dark_red"},{"text":"A bounty contract is signed. Tonight: double bounty, and I send more of them. ","color":"gold"},{"text":"★","color":"white"}]
function nachtwache:uhr/anzeige
