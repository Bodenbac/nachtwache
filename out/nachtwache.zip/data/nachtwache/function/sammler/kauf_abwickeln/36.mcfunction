clear @s *[custom_data~{nw_menu:36}]
execute unless entity @s[level=10..] run return run function nachtwache:sammler/zu_wenig_level
xp add @s -10 levels
give @s minecraft:tripwire_hook[item_model="nachtwache:key",custom_name={text:"Key",color:"gold",italic:false},custom_data={nw_key:1b},consumable={consume_seconds:0.6f,animation:"drink",sound:"minecraft:block.amethyst_block.chime",has_consume_particles:false},max_stack_size=16,lore=[{text:"Right-click: the Collector spins the wheel.",color:"gray",italic:false},{text:"You win a crate. Colour decides what is inside.",color:"gray",italic:false},{text:"Costs 10 player levels, not coins.",color:"dark_gray",italic:false}]]
playsound minecraft:block.chain.place master @s ~ ~ ~ 1 1.4
tellraw @s [{"text":"[The Collector] ","color":"dark_red"},{"text":"A key. What is behind the door is your problem.","color":"gray"}]
