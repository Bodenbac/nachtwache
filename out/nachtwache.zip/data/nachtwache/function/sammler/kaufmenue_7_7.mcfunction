item replace block -1 64 -5 container.0 with minecraft:tuff[custom_data={nw_menu:9001},custom_name={text:"Starter",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.1 with minecraft:green_concrete[custom_data={nw_menu:9002},custom_name={text:"Tier 2",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.2 with minecraft:blue_concrete[custom_data={nw_menu:9003},custom_name={text:"Tier 3",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.3 with minecraft:air
item replace block -1 64 -5 container.4 with minecraft:yellow_concrete[custom_data={nw_menu:9005},custom_name={text:"Tier 5",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.5 with minecraft:air
item replace block -1 64 -5 container.6 with minecraft:black_concrete[enchantment_glint_override=true,custom_data={nw_menu:9007},custom_name={text:"Tier 7",color:"yellow",italic:false},lore=[{text:"Open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.7 with minecraft:air
item replace block -1 64 -5 container.8 with minecraft:enchanted_book[custom_data={nw_menu:9008},custom_name={text:"Books",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.9 with minecraft:netherite_scrap[custom_data={nw_menu:120},custom_name={text:"Netherite Scrap",color:"white",italic:false},lore=[[{text:"Price: 600 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 38400 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.10 with minecraft:netherite_upgrade_smithing_template[custom_data={nw_menu:121},custom_name={text:"Netherite Upgrade Template",color:"white",italic:false},lore=[[{text:"Price: 1500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.11 with minecraft:trident[custom_data={nw_menu:124},custom_name={text:"Trident",color:"white",italic:false},lore=[[{text:"Price: 2000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.12 with minecraft:beacon[custom_data={nw_menu:125},custom_name={text:"Beacon",color:"white",italic:false},lore=[[{text:"Price: 8000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.13 with minecraft:air
item replace block -1 64 -5 container.14 with minecraft:air
item replace block -1 64 -5 container.15 with minecraft:air
item replace block -1 64 -5 container.16 with minecraft:air
item replace block -1 64 -5 container.17 with minecraft:air
item replace block -1 64 -5 container.18 with minecraft:air
item replace block -1 64 -5 container.19 with minecraft:air
item replace block -1 64 -5 container.20 with minecraft:air
item replace block -1 64 -5 container.21 with minecraft:air
item replace block -1 64 -5 container.22 with minecraft:air
item replace block -1 64 -5 container.23 with minecraft:air
item replace block -1 64 -5 container.24 with minecraft:air
item replace block -1 64 -5 container.25 with minecraft:air
item replace block -1 64 -5 container.26 with minecraft:air
item replace block 0 64 -5 container.0 with minecraft:air
item replace block 0 64 -5 container.1 with minecraft:air
item replace block 0 64 -5 container.2 with minecraft:air
item replace block 0 64 -5 container.3 with minecraft:air
item replace block 0 64 -5 container.4 with minecraft:air
item replace block 0 64 -5 container.5 with minecraft:air
item replace block 0 64 -5 container.6 with minecraft:air
item replace block 0 64 -5 container.7 with minecraft:air
item replace block 0 64 -5 container.8 with minecraft:air
item replace block 0 64 -5 container.9 with minecraft:air
item replace block 0 64 -5 container.10 with minecraft:air
item replace block 0 64 -5 container.11 with minecraft:air
item replace block 0 64 -5 container.12 with minecraft:air
item replace block 0 64 -5 container.13 with minecraft:air
item replace block 0 64 -5 container.14 with minecraft:air
item replace block 0 64 -5 container.15 with minecraft:air
item replace block 0 64 -5 container.16 with minecraft:air
item replace block 0 64 -5 container.17 with minecraft:air
item replace block 0 64 -5 container.18 with minecraft:air
item replace block 0 64 -5 container.19 with minecraft:air
item replace block 0 64 -5 container.20 with minecraft:air
item replace block 0 64 -5 container.21 with minecraft:air
item replace block 0 64 -5 container.22 with minecraft:air
item replace block 0 64 -5 container.23 with minecraft:air
item replace block 0 64 -5 container.24 with minecraft:air
item replace block 0 64 -5 container.25 with minecraft:air
item replace block 0 64 -5 container.26 with minecraft:air
