clear @a[x=-7,y=64,z=-10,distance=..8] *[custom_data~{nw_menu:9006}]
function nachtwache:sammler/ench/zurueck
scoreboard players set #seite nw.status 6
playsound minecraft:ui.button.click master @a[x=-7,y=64,z=-10,distance=..8] ~ ~ ~ 0.5 1.4
function nachtwache:sammler/kaufmenue
