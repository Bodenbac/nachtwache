clear @a[x=-1,y=64,z=-5,distance=..8] *[custom_data~{nw_menu:9003}]
scoreboard players set #seite nw.status 3
playsound minecraft:ui.button.click master @a[x=-1,y=64,z=-5,distance=..8] ~ ~ ~ 0.5 1.4
function nachtwache:sammler/kaufmenue
