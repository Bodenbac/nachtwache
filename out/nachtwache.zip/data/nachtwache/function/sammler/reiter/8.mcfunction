clear @a[x=-7,y=64,z=-10,distance=..8] *[custom_data~{nw_menu:9008}]
scoreboard players set #seite nw.status 8
playsound minecraft:ui.button.click master @a[x=-7,y=64,z=-10,distance=..8] ~ ~ ~ 0.5 1.4
function nachtwache:sammler/kaufmenue
