item replace block -1 64 -5 container.0 with minecraft:tuff[custom_data={nw_menu:9001},custom_name={text:"Starter",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.1 with minecraft:green_concrete[custom_data={nw_menu:9002},custom_name={text:"Tier 2",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.2 with minecraft:blue_concrete[custom_data={nw_menu:9003},custom_name={text:"Tier 3",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.3 with minecraft:budding_amethyst[enchantment_glint_override=true,custom_data={nw_menu:9004},custom_name={text:"Tier 4",color:"yellow",italic:false},lore=[{text:"Open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.4 with minecraft:yellow_concrete[custom_data={nw_menu:9005},custom_name={text:"Tier 5",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.5 with minecraft:orange_concrete[custom_data={nw_menu:9006},custom_name={text:"Tier 6",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.6 with minecraft:air
item replace block -1 64 -5 container.7 with minecraft:air
item replace block -1 64 -5 container.8 with minecraft:enchanted_book[custom_data={nw_menu:9008},custom_name={text:"Books",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -1 64 -5 container.9 with minecraft:copper_ingot[custom_data={nw_menu:80},custom_name={text:"Copper Ingot",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1280 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.10 with minecraft:amethyst_shard[custom_data={nw_menu:81},custom_name={text:"Amethyst Shard",color:"white",italic:false},lore=[[{text:"Price: 40 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 2560 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.11 with minecraft:quartz[custom_data={nw_menu:82},custom_name={text:"Quartz",color:"white",italic:false},lore=[[{text:"Price: 25 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1600 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.12 with minecraft:glowstone_dust[custom_data={nw_menu:83},custom_name={text:"Glowstone Dust",color:"white",italic:false},lore=[[{text:"Price: 30 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1920 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.13 with minecraft:blaze_rod[custom_data={nw_menu:84},custom_name={text:"Blaze Rod",color:"white",italic:false},lore=[[{text:"Price: 120 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 7680 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.14 with minecraft:nether_wart[custom_data={nw_menu:85},custom_name={text:"Nether Wart",color:"white",italic:false},lore=[[{text:"Price: 60 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 3840 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.15 with minecraft:honeycomb[custom_data={nw_menu:86},custom_name={text:"Honeycomb",color:"white",italic:false},lore=[[{text:"Price: 40 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 2560 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.16 with minecraft:sea_lantern[custom_data={nw_menu:87},custom_name={text:"Sea Lantern",color:"white",italic:false},lore=[[{text:"Price: 120 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 7680 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.17 with minecraft:sponge[custom_data={nw_menu:88},custom_name={text:"Sponge",color:"white",italic:false},lore=[[{text:"Price: 300 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 19200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.18 with minecraft:name_tag[custom_data={nw_menu:89},custom_name={text:"Name Tag",color:"white",italic:false},lore=[[{text:"Price: 200 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.19 with minecraft:saddle[custom_data={nw_menu:90},custom_name={text:"Saddle",color:"white",italic:false},lore=[[{text:"Price: 300 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.20 with minecraft:air
item replace block -1 64 -5 container.21 with minecraft:air
item replace block -1 64 -5 container.22 with minecraft:air
item replace block -1 64 -5 container.23 with minecraft:air
item replace block -1 64 -5 container.24 with minecraft:air
item replace block -1 64 -5 container.25 with minecraft:air
item replace block -1 64 -5 container.26 with minecraft:air
item replace block 0 64 -5 container.0 with minecraft:air
item replace block 0 64 -5 container.1 with minecraft:air
item replace block 0 64 -5 container.2 with minecraft:air
item replace block 0 64 -5 container.3 with minecraft:air
item replace block 0 64 -5 container.4 with minecraft:air
item replace block 0 64 -5 container.5 with minecraft:air
item replace block 0 64 -5 container.6 with minecraft:air
item replace block 0 64 -5 container.7 with minecraft:air
item replace block 0 64 -5 container.8 with minecraft:air
item replace block 0 64 -5 container.9 with minecraft:air
item replace block 0 64 -5 container.10 with minecraft:air
item replace block 0 64 -5 container.11 with minecraft:air
item replace block 0 64 -5 container.12 with minecraft:air
item replace block 0 64 -5 container.13 with minecraft:air
item replace block 0 64 -5 container.14 with minecraft:air
item replace block 0 64 -5 container.15 with minecraft:air
item replace block 0 64 -5 container.16 with minecraft:air
item replace block 0 64 -5 container.17 with minecraft:air
item replace block 0 64 -5 container.18 with minecraft:air
item replace block 0 64 -5 container.19 with minecraft:air
item replace block 0 64 -5 container.20 with minecraft:air
item replace block 0 64 -5 container.21 with minecraft:air
item replace block 0 64 -5 container.22 with minecraft:air
item replace block 0 64 -5 container.23 with minecraft:air
item replace block 0 64 -5 container.24 with minecraft:air
item replace block 0 64 -5 container.25 with minecraft:air
item replace block 0 64 -5 container.26 with minecraft:air
