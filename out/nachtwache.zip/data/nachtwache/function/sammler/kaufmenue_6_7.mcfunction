item replace block -7 64 -10 container.0 with minecraft:stone[item_model="nachtwache:reiter_blocks_aus",custom_data={nw_menu:9001},custom_name={text:"Building Blocks",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.1 with minecraft:iron_ingot[item_model="nachtwache:reiter_minerals_aus",custom_data={nw_menu:9002},custom_name={text:"Minerals & Drops",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.2 with minecraft:rotten_flesh[item_model="nachtwache:reiter_mob_aus",custom_data={nw_menu:9003},custom_name={text:"Mob Drops",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.3 with minecraft:bread[item_model="nachtwache:reiter_food_aus",custom_data={nw_menu:9004},custom_name={text:"Food",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.4 with minecraft:iron_pickaxe[item_model="nachtwache:reiter_tools_aus",custom_data={nw_menu:9005},custom_name={text:"Tools",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.5 with minecraft:redstone[item_model="nachtwache:reiter_util_aus",custom_data={nw_menu:9006},custom_name={text:"Utility",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.6 with minecraft:brewing_stand[item_model="nachtwache:reiter_brew_an",enchantment_glint_override=true,custom_data={nw_menu:9007},custom_name={text:"Brewing & Magic",color:"yellow",italic:false},lore=[{text:"Open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.7 with minecraft:enchanted_book[item_model="nachtwache:reiter_books_aus",custom_data={nw_menu:9008},custom_name={text:"Enchanted Books",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.8 with minecraft:nether_star[item_model="nachtwache:reiter_special_aus",custom_data={nw_menu:9009},custom_name={text:"Special",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.9 with minecraft:enchanting_table[custom_data={nw_menu:63},custom_name={text:"Enchanting Table",color:"white",italic:false},lore=[[{text:"Price: 4000 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.10 with minecraft:potion[potion_contents={potion:"minecraft:strong_healing"},custom_data={nw_menu:67},custom_name={text:"Potion of Healing II",color:"white",italic:false},lore=[[{text:"Price: 150 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.11 with minecraft:potion[potion_contents={potion:"minecraft:strength"},custom_data={nw_menu:68},custom_name={text:"Potion of Strength",color:"white",italic:false},lore=[[{text:"Price: 200 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.12 with minecraft:potion[potion_contents={potion:"minecraft:long_night_vision"},custom_data={nw_menu:69},custom_name={text:"Potion of Night Vision (long)",color:"white",italic:false},lore=[[{text:"Price: 100 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -7 64 -10 container.13 with minecraft:blaze_rod[custom_data={nw_menu:84},custom_name={text:"Blaze Rod",color:"white",italic:false},lore=[[{text:"Price: 120 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 7680 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.14 with minecraft:nether_wart[custom_data={nw_menu:85},custom_name={text:"Nether Wart",color:"white",italic:false},lore=[[{text:"Price: 60 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 3840 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.15 with minecraft:experience_bottle[custom_data={nw_menu:101},custom_name={text:"Bottle o' Enchanting",color:"white",italic:false},lore=[[{text:"Price: 50 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 3200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.16 with minecraft:ghast_tear[custom_data={nw_menu:110},custom_name={text:"Ghast Tear",color:"white",italic:false},lore=[[{text:"Price: 300 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 19200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.17 with minecraft:dragon_breath[custom_data={nw_menu:113},custom_name={text:"Dragon's Breath",color:"white",italic:false},lore=[[{text:"Price: 400 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 25600 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.18 with minecraft:air
item replace block -7 64 -10 container.19 with minecraft:air
item replace block -7 64 -10 container.20 with minecraft:air
item replace block -7 64 -10 container.21 with minecraft:air
item replace block -7 64 -10 container.22 with minecraft:air
item replace block -7 64 -10 container.23 with minecraft:air
item replace block -7 64 -10 container.24 with minecraft:air
item replace block -7 64 -10 container.25 with minecraft:air
item replace block -7 64 -10 container.26 with minecraft:air
item replace block -6 64 -10 container.0 with minecraft:air
item replace block -6 64 -10 container.1 with minecraft:air
item replace block -6 64 -10 container.2 with minecraft:air
item replace block -6 64 -10 container.3 with minecraft:air
item replace block -6 64 -10 container.4 with minecraft:air
item replace block -6 64 -10 container.5 with minecraft:air
item replace block -6 64 -10 container.6 with minecraft:air
item replace block -6 64 -10 container.7 with minecraft:air
item replace block -6 64 -10 container.8 with minecraft:air
item replace block -6 64 -10 container.9 with minecraft:air
item replace block -6 64 -10 container.10 with minecraft:air
item replace block -6 64 -10 container.11 with minecraft:air
item replace block -6 64 -10 container.12 with minecraft:air
item replace block -6 64 -10 container.13 with minecraft:air
item replace block -6 64 -10 container.14 with minecraft:air
item replace block -6 64 -10 container.15 with minecraft:air
item replace block -6 64 -10 container.16 with minecraft:air
item replace block -6 64 -10 container.17 with minecraft:air
item replace block -6 64 -10 container.18 with minecraft:air
item replace block -6 64 -10 container.19 with minecraft:air
item replace block -6 64 -10 container.20 with minecraft:air
item replace block -6 64 -10 container.21 with minecraft:air
item replace block -6 64 -10 container.22 with minecraft:air
item replace block -6 64 -10 container.23 with minecraft:air
item replace block -6 64 -10 container.24 with minecraft:air
item replace block -6 64 -10 container.25 with minecraft:air
item replace block -6 64 -10 container.26 with minecraft:air
