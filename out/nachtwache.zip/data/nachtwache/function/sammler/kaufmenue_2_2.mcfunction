item replace block -1 64 -5 container.0 with minecraft:cooked_beef[custom_data={nw_menu:45},custom_name={text:"Steak",color:"white",italic:false},lore=[[{text:"Price: 8 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 512 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.1 with minecraft:leather[custom_data={nw_menu:46},custom_name={text:"Leather",color:"white",italic:false},lore=[[{text:"Price: 6 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 384 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.2 with minecraft:string[custom_data={nw_menu:47},custom_name={text:"String",color:"white",italic:false},lore=[[{text:"Price: 4 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 256 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -1 64 -5 container.3 with minecraft:chest[item_model="nachtwache:kit",custom_data={nw_menu:48},custom_name={text:"Lava Moat Kit",color:"white",italic:false},lore=[[{text:"Price: 140 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false}]]
item replace block -1 64 -5 container.4 with minecraft:air
item replace block -1 64 -5 container.5 with minecraft:air
item replace block -1 64 -5 container.6 with minecraft:air
item replace block -1 64 -5 container.7 with minecraft:air
item replace block -1 64 -5 container.8 with minecraft:air
item replace block -1 64 -5 container.9 with minecraft:air
item replace block -1 64 -5 container.10 with minecraft:air
item replace block -1 64 -5 container.11 with minecraft:air
item replace block -1 64 -5 container.12 with minecraft:air
item replace block -1 64 -5 container.13 with minecraft:air
item replace block -1 64 -5 container.14 with minecraft:air
item replace block -1 64 -5 container.15 with minecraft:air
item replace block -1 64 -5 container.16 with minecraft:air
item replace block -1 64 -5 container.17 with minecraft:air
item replace block -1 64 -5 container.18 with minecraft:air
item replace block -1 64 -5 container.19 with minecraft:air
item replace block -1 64 -5 container.20 with minecraft:air
item replace block -1 64 -5 container.21 with minecraft:air
item replace block -1 64 -5 container.22 with minecraft:air
item replace block -1 64 -5 container.23 with minecraft:air
item replace block -1 64 -5 container.24 with minecraft:air
item replace block -1 64 -5 container.25 with minecraft:air
item replace block -1 64 -5 container.26 with minecraft:air
item replace block 0 64 -5 container.0 with minecraft:air
item replace block 0 64 -5 container.1 with minecraft:air
item replace block 0 64 -5 container.2 with minecraft:air
item replace block 0 64 -5 container.3 with minecraft:air
item replace block 0 64 -5 container.4 with minecraft:air
item replace block 0 64 -5 container.5 with minecraft:air
item replace block 0 64 -5 container.6 with minecraft:air
item replace block 0 64 -5 container.7 with minecraft:air
item replace block 0 64 -5 container.8 with minecraft:air
item replace block 0 64 -5 container.9 with minecraft:air
item replace block 0 64 -5 container.10 with minecraft:air
item replace block 0 64 -5 container.11 with minecraft:air
item replace block 0 64 -5 container.12 with minecraft:air
item replace block 0 64 -5 container.13 with minecraft:air
item replace block 0 64 -5 container.14 with minecraft:air
item replace block 0 64 -5 container.15 with minecraft:air
item replace block 0 64 -5 container.16 with minecraft:air
item replace block 0 64 -5 container.17 with minecraft:air
item replace block 0 64 -5 container.18 with minecraft:air
item replace block 0 64 -5 container.19 with minecraft:air
item replace block 0 64 -5 container.20 with minecraft:air
item replace block 0 64 -5 container.21 with minecraft:air
item replace block 0 64 -5 container.22 with minecraft:air
item replace block 0 64 -5 container.23 with minecraft:air
item replace block 0 64 -5 container.24 with minecraft:air
item replace block 0 64 -5 container.25 with minecraft:air
item replace block 0 64 -5 container.26 with minecraft:arrow[custom_data={nw_menu:9001},custom_name={text:"Next page",color:"yellow",italic:false}]
