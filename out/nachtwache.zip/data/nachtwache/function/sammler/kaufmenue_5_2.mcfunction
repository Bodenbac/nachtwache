item replace block -7 64 -10 container.0 with minecraft:stone[item_model="nachtwache:reiter_blocks_aus",custom_data={nw_menu:9001},custom_name={text:"Building Blocks",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.1 with minecraft:iron_ingot[item_model="nachtwache:reiter_minerals_an",enchantment_glint_override=true,custom_data={nw_menu:9002},custom_name={text:"Minerals & Drops",color:"yellow",italic:false},lore=[{text:"Open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.2 with minecraft:rotten_flesh[item_model="nachtwache:reiter_mob_aus",custom_data={nw_menu:9003},custom_name={text:"Mob Drops",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.3 with minecraft:bread[item_model="nachtwache:reiter_food_aus",custom_data={nw_menu:9004},custom_name={text:"Food",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.4 with minecraft:iron_pickaxe[item_model="nachtwache:reiter_tools_aus",custom_data={nw_menu:9005},custom_name={text:"Tools",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.5 with minecraft:redstone[item_model="nachtwache:reiter_util_aus",custom_data={nw_menu:9006},custom_name={text:"Utility",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.6 with minecraft:brewing_stand[item_model="nachtwache:reiter_brew_aus",custom_data={nw_menu:9007},custom_name={text:"Brewing & Magic",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.7 with minecraft:enchanted_book[item_model="nachtwache:reiter_books_aus",custom_data={nw_menu:9008},custom_name={text:"Enchanted Books",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.8 with minecraft:nether_star[item_model="nachtwache:reiter_special_aus",custom_data={nw_menu:9009},custom_name={text:"Special",color:"yellow",italic:false},lore=[{text:"Click to open",color:"gray",italic:false}]]
item replace block -7 64 -10 container.9 with minecraft:coal[custom_data={nw_menu:28},custom_name={text:"Coal",color:"white",italic:false},lore=[[{text:"Price: 15 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 960 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.10 with minecraft:copper_ingot[custom_data={nw_menu:80},custom_name={text:"Copper Ingot",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1280 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.11 with minecraft:iron_ingot[custom_data={nw_menu:29},custom_name={text:"Iron Ingot",color:"white",italic:false},lore=[[{text:"Price: 50 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 3200 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.12 with minecraft:gold_ingot[custom_data={nw_menu:61},custom_name={text:"Gold Ingot",color:"white",italic:false},lore=[[{text:"Price: 100 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 6400 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.13 with minecraft:lapis_lazuli[custom_data={nw_menu:65},custom_name={text:"Lapis Lazuli",color:"white",italic:false},lore=[[{text:"Price: 20 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 1280 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.14 with minecraft:redstone[custom_data={nw_menu:42},custom_name={text:"Redstone",color:"white",italic:false},lore=[[{text:"Price: 10 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 640 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.15 with minecraft:diamond[custom_data={nw_menu:131},custom_name={text:"Diamond",color:"white",italic:false},lore=[[{text:"Price: 500 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 32000 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.16 with minecraft:emerald[custom_data={nw_menu:300},custom_name={text:"Emerald",color:"white",italic:false},lore=[[{text:"Price: 250 ",color:"gold",italic:false},{text:"●",color:"white",italic:false}],{text:"Click: buy 1",color:"gray",italic:false},[{text:"Shift-click: buy 64 for 16000 ",color:"gray",italic:false},{text:"●",color:"white",italic:false}]]]
item replace block -7 64 -10 container.17 with minecraft:air
item replace block -7 64 -10 container.18 with minecraft:air
item replace block -7 64 -10 container.19 with minecraft:air
item replace block -7 64 -10 container.20 with minecraft:air
item replace block -7 64 -10 container.21 with minecraft:air
item replace block -7 64 -10 container.22 with minecraft:air
item replace block -7 64 -10 container.23 with minecraft:air
item replace block -7 64 -10 container.24 with minecraft:air
item replace block -7 64 -10 container.25 with minecraft:air
item replace block -7 64 -10 container.26 with minecraft:air
item replace block -6 64 -10 container.0 with minecraft:air
item replace block -6 64 -10 container.1 with minecraft:air
item replace block -6 64 -10 container.2 with minecraft:air
item replace block -6 64 -10 container.3 with minecraft:air
item replace block -6 64 -10 container.4 with minecraft:air
item replace block -6 64 -10 container.5 with minecraft:air
item replace block -6 64 -10 container.6 with minecraft:air
item replace block -6 64 -10 container.7 with minecraft:air
item replace block -6 64 -10 container.8 with minecraft:air
item replace block -6 64 -10 container.9 with minecraft:air
item replace block -6 64 -10 container.10 with minecraft:air
item replace block -6 64 -10 container.11 with minecraft:air
item replace block -6 64 -10 container.12 with minecraft:air
item replace block -6 64 -10 container.13 with minecraft:air
item replace block -6 64 -10 container.14 with minecraft:air
item replace block -6 64 -10 container.15 with minecraft:air
item replace block -6 64 -10 container.16 with minecraft:air
item replace block -6 64 -10 container.17 with minecraft:air
item replace block -6 64 -10 container.18 with minecraft:air
item replace block -6 64 -10 container.19 with minecraft:air
item replace block -6 64 -10 container.20 with minecraft:air
item replace block -6 64 -10 container.21 with minecraft:air
item replace block -6 64 -10 container.22 with minecraft:air
item replace block -6 64 -10 container.23 with minecraft:air
item replace block -6 64 -10 container.24 with minecraft:air
item replace block -6 64 -10 container.25 with minecraft:air
item replace block -6 64 -10 container.26 with minecraft:air
