execute as @e[tag=nw.sammler] if data entity @s interaction on target run function nachtwache:sammler/hinweis
execute as @e[tag=nw.sammler] if data entity @s interaction run data remove entity @s interaction
execute as @e[tag=nw.sammler] if data entity @s attack run data remove entity @s attack
execute if score #glocke nw.upgrade matches 0 if score #m20 nw.tmp matches 7 as @a if items entity @s container.* minecraft:bell[custom_data~{nw_glocke:1b}] run function nachtwache:sammler/glocke_an
