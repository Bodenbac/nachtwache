function nachtwache:admin/reset
