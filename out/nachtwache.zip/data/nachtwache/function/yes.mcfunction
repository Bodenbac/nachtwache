function nachtwache:admin/reset_ja
